<?php
include_once "conexionbd.php";
include_once __DIR__ . "/../Logica/Usuarios.php";

class UsuarioBD extends Conexion
{
    public function AgregarUsuario() { 
        // Método vacío por ahora
    }

    /**
     * Login de usuario
     */
    public function Login($ci, $password)
    {
        $con = $this->getConexion();
        $sql = "SELECT * FROM usuarios WHERE ci = ? AND pass = ?";
        $stmt = $con->prepare($sql);
        
        if (!$stmt) {
            error_log("Error preparando consulta de login: " . $con->error);
            return null;
        }
        
        $stmt->bind_param("is", $ci, $password);
        
        if (!$stmt->execute()) {
            error_log("Error ejecutando login: " . $stmt->error);
            return null;
        }
        
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            $fila = $resultado->fetch_assoc();
            $usuario = new Usuarios();
            
            $this->mapearUsuarioDesdeFila($usuario, $fila);
            
            return $usuario;
        }
        
        return null;
    }

    /**
     * Verificar contraseña actual
     */
    public function VerificarPassword($correo, $password_actual) {
        $con = $this->getConexion();
        $sql = "SELECT pass FROM usuarios WHERE correo = ?";
        $stmt = $con->prepare($sql);
        
        if (!$stmt) {
            error_log("Error preparando verificación de contraseña: " . $con->error);
            return false;
        }
        
        $stmt->bind_param("s", $correo);
        
        if (!$stmt->execute()) {
            error_log("Error ejecutando verificación de contraseña: " . $stmt->error);
            return false;
        }
        
        $resultado = $stmt->get_result();
        
        if ($fila = $resultado->fetch_assoc()) {
            // Comparar directamente (asumiendo que las contraseñas no están encriptadas)
            return $password_actual === $fila['pass'];
        }
        
        return false;
    }

    /**
     * Registro de nuevo usuario
     */
    public function Registro($ci, $nombre, $email, $telefono, $password)
    {
        $con = $this->getConexion();

        // Verificar si ya existe el usuario
        if ($this->usuarioExiste($ci, $email)) {
            return false;
        }

        // Insertar nuevo usuario
        $sql = "INSERT INTO usuarios (ci, nombre, correo, tel, pass) 
                VALUES (?, ?, ?, ?, ?)";
        $stmt = $con->prepare($sql);
        
        if (!$stmt) {
            error_log("Error preparando registro: " . $con->error);
            return false;
        }
        
        $stmt->bind_param("issss", $ci, $nombre, $email, $telefono, $password);
        $success = $stmt->execute();
        
        if (!$success) {
            error_log("Error ejecutando registro: " . $stmt->error);
        }
        
        return $success;
    }

    /**
     * Mostrar todos los usuarios
     */
    public function MostrarUsuarios()
    {
        $con = $this->getConexion();
        $sql = "SELECT * FROM usuarios ORDER BY nombre";
        $stmt = $con->prepare($sql);
        
        if (!$stmt || !$stmt->execute()) {
            error_log("Error obteniendo usuarios: " . $con->error);
            return [];
        }
        
        $resultado = $stmt->get_result();
        $listaUsuario = [];

        while ($fila = $resultado->fetch_assoc()) {
            $usuario = new Usuarios();
            $this->mapearUsuarioDesdeFila($usuario, $fila);
            $listaUsuario[] = $usuario;
        }
        
        return $listaUsuario;
    }

    /**
     * Obtener usuario por correo
     */
    public function ObtenerUsuarioPorCorreo($correo)
    {
        $con = $this->getConexion();
        $sql = "SELECT * FROM usuarios WHERE correo = ?";
        $stmt = $con->prepare($sql);
        
        if (!$stmt) {
            return null;
        }
        
        $stmt->bind_param("s", $correo);
        
        if (!$stmt->execute()) {
            return null;
        }
        
        $resultado = $stmt->get_result();
        
        if ($fila = $resultado->fetch_assoc()) {
            $usuario = new Usuarios();
            $this->mapearUsuarioDesdeFila($usuario, $fila);
            return $usuario;
        }
        
        return null;
    }

    public function ActualizarUsuarioConFoto($email_actual, $nombre, $telefono, $password = null, $foto = null, $nuevo_email = null, $tipo = null, $estado = null)
    {
        $con = $this->getConexion();

        // Construir query dinámicamente
        $sql = "UPDATE usuarios SET nombre = ?, tel = ?";
        $types = "ss";
        $params = [$nombre, $telefono];

        // Agregar campos opcionales
        if (!empty($nuevo_email)) {
            $sql .= ", correo = ?";
            $types .= "s";
            $params[] = $nuevo_email;
        }

        if (!empty($password)) {
            $sql .= ", pass = ?";
            $types .= "s";
            $params[] = $password;
        }

        if (!empty($foto)) {
            $sql .= ", foto = ?";
            $types .= "s";
            $params[] = $foto;
        }

        if (!empty($tipo)) {
            $sql .= ", tipo = ?";
            $types .= "s";
            $params[] = $tipo;
        }

        if (!empty($estado)) {
            $sql .= ", estado = ?";
            $types .= "s";
            $params[] = $estado;
        }

        // WHERE clause
        $sql .= " WHERE correo = ?";
        $types .= "s";
        $params[] = $email_actual;

        $stmt = $con->prepare($sql);
        if (!$stmt) {
            error_log("Error en prepare: " . $con->error);
            return false;
        }

        // Bind parameters
        $bind_params = [$types];
        foreach ($params as &$param) {
            $bind_params[] = &$param;
        }

        call_user_func_array([$stmt, 'bind_param'], $bind_params);

        $success = $stmt->execute();
        
        if (!$success) {
            error_log("Error ejecutando actualización: " . $stmt->error);
        }

        return $success;
    }

    /**
     * Cambiar estado a inactivo
     */
    public function CambiarEstado($ci) {
        return $this->cambiarEstadoUsuario($ci, 'inactivo');
    }

    /**
     * Cambiar estado a activo
     */
    public function CambiarEstadoActivo($ci) {
        return $this->cambiarEstadoUsuario($ci, 'activo');
    }

    // ========== MÉTODOS PRIVADOS ==========

    /**
     * Verificar si usuario existe
     */
    private function usuarioExiste($ci, $email)
    {
        $con = $this->getConexion();
        $sql = "SELECT ci FROM usuarios WHERE ci = ? OR correo = ?";
        $stmt = $con->prepare($sql);
        
        if (!$stmt) {
            return false;
        }
        
        $stmt->bind_param("is", $ci, $email);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        return $resultado->num_rows > 0;
    }

    /**
     * Mapear datos de fila a objeto Usuario
     */
    private function mapearUsuarioDesdeFila($usuario, $fila)
    {
        $usuario->setCi($fila['ci']);
        $usuario->setNombre($fila['nombre']);
        $usuario->setEmail($fila['correo']);
        $usuario->setTelefono($fila['tel']);
        $usuario->setPassword($fila['pass']);
        $usuario->setTipo($fila['tipo']);
        $usuario->setEstado($fila['estado']);
        $usuario->setFoto($fila['foto'] ?? null);
    }

    /**
     * Cambiar estado de usuario
     */
    private function cambiarEstadoUsuario($ci, $estado)
    {
        $con = $this->getConexion();
        $sql = "UPDATE usuarios SET estado = ? WHERE ci = ?";
        $stmt = $con->prepare($sql);
    
        if (!$stmt) {
            return ["ok" => false, "error" => $con->error];
        }
    
        $stmt->bind_param("si", $estado, $ci);
        $ok = $stmt->execute();
    
        if ($ok) {
            return ["ok" => true, "nuevoEstado" => $estado];
        } else {
            return ["ok" => false, "error" => $stmt->error];
        }
    }

    
}
?>