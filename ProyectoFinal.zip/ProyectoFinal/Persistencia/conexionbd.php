<?php
/**
 * Clase para gestionar la conexión a la base de datos
 */
class Conexion
{
    private $servidor = "localhost";
    private $usuario = "root";
    private $pass = "admin";
    private $bd = "ProyectoFinal";
    private $conexion;

    /**
     * Constructor que establece la conexión
     */
    public function __construct()
    {
        try {
            $this->conexion = new mysqli($this->servidor, $this->usuario, $this->pass, $this->bd);
            
            if ($this->conexion->connect_error) {
                throw new Exception("Error de conexión: " . $this->conexion->connect_error);
            }
            
            // Establecer charset
            $this->conexion->set_charset("utf8mb4");
            
        } catch (Exception $e) {
            error_log($e->getMessage());
            die("Error al conectar con la base de datos. Por favor, intente más tarde.");
        }
    }

    /**
     * Obtener la conexión activa
     */
    public function getConexion()
    {
        return $this->conexion;
    }

    /**
     * Cerrar la conexión
     */
    public function desconectar()
    {
        if ($this->conexion) {
            $this->conexion->close();
        }
    }

    /**
     * Destructor - cierra la conexión automáticamente
     */
    public function __destruct()
    {
        $this->desconectar();
    }
}
?>