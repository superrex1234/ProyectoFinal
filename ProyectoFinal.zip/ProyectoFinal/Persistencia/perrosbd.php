<?php
include_once "conexionbd.php";
include_once __DIR__ . '/../Logica/Perros.php';

class perrosBD extends conexion
{
    // =============================================
    // MÉTODOS PARA MOSTRAR MASCOTAS
    // =============================================
    
    public function MostrarPerros()
    {
        $con = $this->getConexion();
        $sql = "SELECT * FROM mascotas WHERE especie='perro'";
        $stmt = $con->prepare($sql);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $listaPerros = [];
        while ($fila = $resultado->fetch_assoc()) {
            $perro = new Perros();
            $perro->setIdPerro($fila['id']);
            $perro->setNombrePerro($fila['nombre']);
            $perro->setRazaPerro($fila['raza']);
            $perro->setEdadPerro($fila['edad']);
            $perro->setSexoPerro($fila['sexo']);
            $perro->setEstadoPerro($fila['estado']);
            $perro->setFotoPerro($fila['foto']);
            $listaPerros[] = $perro;
        }
        return $listaPerros;
    }

    public function MostrarGatos()
    {
        $con = $this->getConexion();
        $sql = "SELECT * FROM mascotas WHERE especie='gato'";
        $stmt = $con->prepare($sql);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $listaGatos = [];
        while ($fila = $resultado->fetch_assoc()) {
            $gato = new Perros();
            $gato->setIdGatos($fila['id']);
            $gato->setNombreGatos($fila['nombre']);
            $gato->setRazaGatos($fila['raza']);
            $gato->setEdadGatos($fila['edad']);
            $gato->setSexoGatos($fila['sexo']);
            $gato->setEstadoGatos($fila['estado']);
            $gato->setFotoGatos($fila['foto']);
            $listaGatos[] = $gato;
        }
        return $listaGatos;
    }

    public function MostrarOtros()
    {
        $con = $this->getConexion();
        $sql = "SELECT * FROM mascotas WHERE especie='otro'";
        $stmt = $con->prepare($sql);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $listaOtros = [];
        while ($fila = $resultado->fetch_assoc()) {
            $otro = new Perros();
            $otro->setIdOtros($fila['id']);
            $otro->setNombreOtros($fila['nombre']);
            $otro->setRazaOtros($fila['raza']);
            $otro->setEdadOtros($fila['edad']);
            $otro->setSexoOtros($fila['sexo']);
            $otro->setEstadoOtros($fila['estado']);
            $otro->setFotoOtros($fila['foto']);
            $listaOtros[] = $otro;
        }
        return $listaOtros;
    }

    // =============================================
    // MÉTODOS PARA MOSTRAR MASCOTAS DISPONIBLES
    // =============================================

    public function MostrarPerrosDisponibles()
    {
        $con = $this->getConexion();
        $sql = "SELECT * FROM mascotas WHERE especie='perro' AND estado='disponible'";
        $stmt = $con->prepare($sql);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $listaPerros = [];
        while ($fila = $resultado->fetch_assoc()) {
            $perro = new Perros();
            $perro->setIdPerro($fila['id']);
            $perro->setNombrePerro($fila['nombre']);
            $perro->setRazaPerro($fila['raza']);
            $perro->setEdadPerro($fila['edad']);
            $perro->setSexoPerro($fila['sexo']);
            $perro->setEstadoPerro($fila['estado']);
            $perro->setFotoPerro($fila['foto']);
            $listaPerros[] = $perro;
        }
        return $listaPerros;
    }

    public function MostrarGatosDisponibles()
    {
        $con = $this->getConexion();
        $sql = "SELECT * FROM mascotas WHERE especie='gato' AND estado='disponible'";
        $stmt = $con->prepare($sql);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $listaGatos = [];
        while ($fila = $resultado->fetch_assoc()) {
            $gato = new Perros();
            $gato->setIdGatos($fila['id']);
            $gato->setNombreGatos($fila['nombre']);
            $gato->setRazaGatos($fila['raza']);
            $gato->setEdadGatos($fila['edad']);
            $gato->setSexoGatos($fila['sexo']);
            $gato->setEstadoGatos($fila['estado']);
            $gato->setFotoGatos($fila['foto']);
            $listaGatos[] = $gato;
        }
        return $listaGatos;
    }

    public function MostrarOtrosDisponibles()
    {
        $con = $this->getConexion();
        $sql = "SELECT * FROM mascotas WHERE especie='otro' AND estado='disponible'";
        $stmt = $con->prepare($sql);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $listaOtros = [];
        while ($fila = $resultado->fetch_assoc()) {
            $otro = new Perros();
            $otro->setIdOtros($fila['id']);
            $otro->setNombreOtros($fila['nombre']);
            $otro->setRazaOtros($fila['raza']);
            $otro->setEdadOtros($fila['edad']);
            $otro->setSexoOtros($fila['sexo']);
            $otro->setEstadoOtros($fila['estado']);
            $otro->setFotoOtros($fila['foto']);
            $listaOtros[] = $otro;
        }
        return $listaOtros;
    }

    // =============================================
    // MÉTODOS PARA OBTENER INFORMACIÓN ESPECÍFICA
    // =============================================

    public function ObtenerMascotaPorId($id) {
        $con = $this->getConexion();
        $sql = "SELECT * FROM mascotas WHERE id = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        return $resultado->fetch_assoc();
    }

    public function obtenerCaracteristicasMascota($id) {
        $con = $this->getConexion();
        $sql = "SELECT caracteristicas FROM mascotas WHERE id = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        if ($fila = $resultado->fetch_assoc()) {
            return $fila['caracteristicas'];
        }
        
        return 'Sin características definidas';
    }

    // =============================================
    // MÉTODOS PARA GESTIÓN DE ESTADOS
    // =============================================

    public function CambiarEstadoAdoptado($id, $especie = null) {
        $con = $this->getConexion();
        
        if ($especie) {
            $sql = "UPDATE mascotas SET estado = 'adoptado' WHERE id = ? AND especie = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("is", $id, $especie);
        } else {
            $sql = "UPDATE mascotas SET estado = 'adoptado' WHERE id = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("i", $id);
        }
        
        $resultado = $stmt->execute();
        
        if ($resultado) {
            $this->RegistrarAdopcionAutomatica($id);
        }
        
        return $resultado;
    }

    public function CambiarEstadoDisponible($id, $especie = null) {
        $con = $this->getConexion();
        
        if ($especie) {
            $sql = "UPDATE mascotas SET estado = 'disponible' WHERE id = ? AND especie = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("is", $id, $especie);
        } else {
            $sql = "UPDATE mascotas SET estado = 'disponible' WHERE id = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("i", $id);
        }
        
        return $stmt->execute();
    }

    public function CambiarEstadoNoDisponible($id, $especie = null) {
        $con = $this->getConexion();
        
        if ($especie) {
            $sql = "UPDATE mascotas SET estado = 'no_disponible' WHERE id = ? AND especie = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("is", $id, $especie);
        } else {
            $sql = "UPDATE mascotas SET estado = 'no_disponible' WHERE id = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("i", $id);
        }
        
        return $stmt->execute();
    }

    // =============================================
    // MÉTODOS PARA SOLICITUDES (ACTUALIZADOS)
    // =============================================

    /**
     * Obtener información de contacto para una solicitud específica
     */
    public function obtenerInfoContactoSolicitud($solicitud_id) {
        $con = $this->getConexion();
        $sql = "SELECT s.*, u.nombre as usuario_nombre, u.correo, u.tel as telefono_usuario, 
                       m.nombre as mascota_nombre, m.especie
                FROM solicitudes s 
                JOIN usuarios u ON s.usuario_ci = u.ci 
                JOIN mascotas m ON s.mascota_id = m.id 
                WHERE s.id = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("i", $solicitud_id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        return $resultado->fetch_assoc();
    }

    /**
     * Marcar contacto realizado y guardar mensaje del admin
     */
    public function marcarContactoRealizado($solicitud_id, $notas_contacto = '', $mensaje_admin = '') {
        $con = $this->getConexion();
        $sql = "UPDATE solicitudes SET contacto_realizado = TRUE, fecha_contacto = NOW(), notas_contacto = ?, mensaje_admin = ? WHERE id = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("ssi", $notas_contacto, $mensaje_admin, $solicitud_id);
        return $stmt->execute();
    }

    /**
     * Modificar el método cambiarEstadoSolicitud para incluir fecha_aprobacion
     */
    public function cambiarEstadoSolicitud($solicitud_id, $nuevo_estado) {
        $con = $this->getConexion();
        
        if ($nuevo_estado === 'aprobada') {
            $sql = "UPDATE solicitudes SET estado = ?, fecha_aprobacion = NOW() WHERE id = ?";
        } else {
            $sql = "UPDATE solicitudes SET estado = ? WHERE id = ?";
        }
        
        $stmt = $con->prepare($sql);
        $stmt->bind_param("si", $nuevo_estado, $solicitud_id);
        return $stmt->execute();
    }

    /**
     * Obtener solicitudes por usuario (actualizado para incluir nuevos campos)
     */
    public function ObtenerSolicitudesPorUsuario($usuario_ci) {
        $con = $this->getConexion();
        $sql = "SELECT s.*, m.nombre as mascota_nombre, m.especie, m.raza, m.foto, m.edad, m.sexo 
                FROM solicitudes s 
                JOIN mascotas m ON s.mascota_id = m.id 
                WHERE s.usuario_ci = ? 
                ORDER BY s.fecha_solicitud DESC";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("i", $usuario_ci);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $solicitudes = [];
        while ($fila = $resultado->fetch_assoc()) {
            $solicitudes[] = $fila;
        }
        return $solicitudes;
    }

    public function ObtenerTodasLasSolicitudes() {
        $con = $this->getConexion();
        $sql = "SELECT s.*, u.nombre as usuario_nombre, u.correo, u.tel as usuario_telefono,
                       m.nombre as mascota_nombre, m.especie, m.raza, m.foto, m.edad, m.sexo 
                FROM solicitudes s 
                JOIN usuarios u ON s.usuario_ci = u.ci 
                JOIN mascotas m ON s.mascota_id = m.id 
                ORDER BY s.fecha_solicitud DESC";
        $stmt = $con->prepare($sql);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $solicitudes = [];
        while ($fila = $resultado->fetch_assoc()) {
            $solicitudes[] = $fila;
        }
        return $solicitudes;
    }

    public function AgregarSolicitud($usuario_ci, $mascota_id, $telefono, $razon)
    {
        $con = $this->getConexion();
        $sql = "INSERT INTO solicitudes (usuario_ci, mascota_id, telefono, razon, fecha_solicitud, estado) 
                VALUES (?, ?, ?, ?, NOW(), 'pendiente')";
        $stmt = $con->prepare($sql);

        if (!$stmt) {
            error_log("Error preparando consulta: " . $con->error);
            return false;
        }

        $stmt->bind_param("iiss", $usuario_ci, $mascota_id, $telefono, $razon);

        if ($stmt->execute()) {
            error_log("Solicitud agregada - Usuario: $usuario_ci, Mascota: $mascota_id");
            return true;
        } else {
            error_log("Error ejecutando consulta: " . $stmt->error);
            return false;
        }
    }

    public function VerificarSolicitudExistente($usuario_ci, $mascota_id) {
        $con = $this->getConexion();
        $sql = "SELECT id FROM solicitudes WHERE usuario_ci = ? AND mascota_id = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("ii", $usuario_ci, $mascota_id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        return $resultado->num_rows > 0;
    }

    public function eliminarSolicitud($solicitud_id)
    {
        $con = $this->getConexion();
        $sql = "DELETE FROM solicitudes WHERE id = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("i", $solicitud_id);
        return $stmt->execute();
    }

    // =============================================
    // MÉTODOS PARA REGISTROS DE ADOPCIÓN
    // =============================================

    public function MostrarRegistrosAdopciones()
    {
        $con = $this->getConexion();
        $sql = "SELECT * FROM registros_adopciones ORDER BY fecha_adopcion DESC";
        $stmt = $con->prepare($sql);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $registros = [];
        while ($fila = $resultado->fetch_assoc()) {
            $registros[] = $fila;
        }
        return $registros;
    }

    private function RegistrarAdopcionAutomatica($mascota_id) {
        $con = $this->getConexion();
        
        // Obtener datos de la mascota
        $sql = "SELECT * FROM mascotas WHERE id = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("i", $mascota_id);
        $stmt->execute();
        $mascota = $stmt->get_result()->fetch_assoc();
        
        if ($mascota) {
            // Registrar en la tabla de adopciones
            $sql_insert = "INSERT INTO registros_adopciones 
                          (mascota_id, nombre_mascota, especie, raza, edad, sexo, foto, adoptado_por, telefono_adoptante, fecha_adopcion) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, 'Sistema', 'No especificado', NOW())";
            $stmt_insert = $con->prepare($sql_insert);
            $stmt_insert->bind_param("issssss", 
                $mascota['id'],
                $mascota['nombre'],
                $mascota['especie'],
                $mascota['raza'],
                $mascota['edad'],
                $mascota['sexo'],
                $mascota['foto']
            );
            
            return $stmt_insert->execute();
        }
        
        return false;
    }

    // =============================================
    // MÉTODOS PARA ACTUALIZAR INFORMACIÓN
    // =============================================

    public function ActualizarInfoPerros($IdPerro, $NombrePerro, $RazaPerro, $EdadPerro, $SexoPerro, $CaracteristicasPerros, $FotoPerro = null) {
        $con = $this->getConexion();
        
        if ($FotoPerro) {
            $sql = "UPDATE mascotas SET nombre = ?, raza = ?, edad = ?, sexo = ?, caracteristicas = ?, foto = ? WHERE id = ? AND especie = 'perro'";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("ssssssi", $NombrePerro, $RazaPerro, $EdadPerro, $SexoPerro, $CaracteristicasPerros, $FotoPerro, $IdPerro);
        } else {
            $sql = "UPDATE mascotas SET nombre = ?, raza = ?, edad = ?, sexo = ?, caracteristicas = ? WHERE id = ? AND especie = 'perro'";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("sssssi", $NombrePerro, $RazaPerro, $EdadPerro, $SexoPerro, $CaracteristicasPerros, $IdPerro);
        }
        
        $resultado = $stmt->execute();
        
        if ($resultado) {
            error_log("Perro actualizado correctamente - ID: $IdPerro");
        } else {
            error_log("Error al actualizar perro: " . $stmt->error);
        }
        
        return $resultado;
    }

    public function ActualizarInfoGatos($IdGatos, $NombreGatos, $RazaGatos, $EdadGatos, $SexoGatos, $CaracteristicasGatos, $FotoGatos = null) {
        $con = $this->getConexion();
        
        if ($FotoGatos) {
            $sql = "UPDATE mascotas SET nombre = ?, raza = ?, edad = ?, sexo = ?, caracteristicas = ?, foto = ? WHERE id = ? AND especie = 'gato'";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("ssssssi", $NombreGatos, $RazaGatos, $EdadGatos, $SexoGatos, $CaracteristicasGatos, $FotoGatos, $IdGatos);
        } else {
            $sql = "UPDATE mascotas SET nombre = ?, raza = ?, edad = ?, sexo = ?, caracteristicas = ? WHERE id = ? AND especie = 'gato'";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("sssssi", $NombreGatos, $RazaGatos, $EdadGatos, $SexoGatos, $CaracteristicasGatos, $IdGatos);
        }
        
        $resultado = $stmt->execute();
        
        if ($resultado) {
            error_log("Gato actualizado correctamente - ID: $IdGatos");
        } else {
            error_log("Error al actualizar gato: " . $stmt->error);
        }
        
        return $resultado;
    }

    public function ActualizarInfoOtros($IdOtros, $NombreOtros, $RazaOtros, $EdadOtros, $SexoOtros, $CaracteristicasOtros, $FotoOtros = null) {
        $con = $this->getConexion();
        
        if ($FotoOtros) {
            $sql = "UPDATE mascotas SET nombre = ?, raza = ?, edad = ?, sexo = ?, caracteristicas = ?, foto = ? WHERE id = ? AND especie = 'otro'";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("ssssssi", $NombreOtros, $RazaOtros, $EdadOtros, $SexoOtros, $CaracteristicasOtros, $FotoOtros, $IdOtros);
        } else {
            $sql = "UPDATE mascotas SET nombre = ?, raza = ?, edad = ?, sexo = ?, caracteristicas = ? WHERE id = ? AND especie = 'otro'";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("sssssi", $NombreOtros, $RazaOtros, $EdadOtros, $SexoOtros, $CaracteristicasOtros, $IdOtros);
        }
        
        $resultado = $stmt->execute();
        
        if ($resultado) {
            error_log("Otro animal actualizado correctamente - ID: $IdOtros");
        } else {
            error_log("Error al actualizar otro animal: " . $stmt->error);
        }
        
        return $resultado;
    }

    // =============================================
    // MÉTODOS PARA AGREGAR MASCOTAS
    // =============================================

    public function AgregarPerro($nombre, $especie, $raza, $edad, $sexo, $foto = null) {
        $con = $this->getConexion();
        $estado = 'disponible';
        
        $sql = "INSERT INTO mascotas (nombre, especie, raza, edad, sexo, estado, foto) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("sssssss", $nombre, $especie, $raza, $edad, $sexo, $estado, $foto);
        
        if ($stmt->execute()) {
            error_log("Animal agregado correctamente - Nombre: $nombre, Especie: $especie");
            return true;
        } else {
            error_log("Error al agregar animal: " . $stmt->error);
            return false;
        }
    }

    public function AgregarGato($nombre, $especie, $raza, $edad, $sexo, $foto = null) {
        $con = $this->getConexion();
        $estado = 'disponible';
        
        $sql = "INSERT INTO mascotas (nombre, especie, raza, edad, sexo, estado, foto) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("sssssss", $nombre, $especie, $raza, $edad, $sexo, $estado, $foto);
        
        return $stmt->execute();
    }

    public function AgregarOtro($nombre, $especie, $raza, $edad, $sexo, $foto = null) {
        $con = $this->getConexion();
        $estado = 'disponible';
        
        $sql = "INSERT INTO mascotas (nombre, especie, raza, edad, sexo, estado, foto) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("sssssss", $nombre, $especie, $raza, $edad, $sexo, $estado, $foto);
        
        return $stmt->execute();
    }

    // =============================================
    // MÉTODOS PARA ACTUALIZAR MASCOTAS
    // =============================================

    public function actualizarPerro($id, $nombre, $raza, $edad, $sexo, $estado, $foto = null) {
        $con = $this->getConexion();
        
        if ($foto) {
            $sql = "UPDATE mascotas SET nombre = ?, raza = ?, edad = ?, sexo = ?, estado = ?, foto = ? WHERE id = ? AND especie = 'perro'";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("ssssssi", $nombre, $raza, $edad, $sexo, $estado, $foto, $id);
        } else {
            $sql = "UPDATE mascotas SET nombre = ?, raza = ?, edad = ?, sexo = ?, estado = ? WHERE id = ? AND especie = 'perro'";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("sssssi", $nombre, $raza, $edad, $sexo, $estado, $id);
        }
        
        return $stmt->execute();
    }

    public function actualizarGato($id, $nombre, $raza, $edad, $sexo, $estado, $foto = null) {
        $con = $this->getConexion();
        
        if ($foto) {
            $sql = "UPDATE mascotas SET nombre = ?, raza = ?, edad = ?, sexo = ?, estado = ?, foto = ? WHERE id = ? AND especie = 'gato'";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("ssssssi", $nombre, $raza, $edad, $sexo, $estado, $foto, $id);
        } else {
            $sql = "UPDATE mascotas SET nombre = ?, raza = ?, edad = ?, sexo = ?, estado = ? WHERE id = ? AND especie = 'gato'";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("sssssi", $nombre, $raza, $edad, $sexo, $estado, $id);
        }
        
        return $stmt->execute();
    }

    public function actualizarOtro($id, $nombre, $raza, $edad, $sexo, $estado, $foto = null) {
        $con = $this->getConexion();
        
        if ($foto) {
            $sql = "UPDATE mascotas SET nombre = ?, raza = ?, edad = ?, sexo = ?, estado = ?, foto = ? WHERE id = ? AND especie = 'otro'";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("ssssssi", $nombre, $raza, $edad, $sexo, $estado, $foto, $id);
        } else {
            $sql = "UPDATE mascotas SET nombre = ?, raza = ?, edad = ?, sexo = ?, estado = ? WHERE id = ? AND especie = 'otro'";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("sssssi", $nombre, $raza, $edad, $sexo, $estado, $id);
        }
        
        return $stmt->execute();
    }
}
?>