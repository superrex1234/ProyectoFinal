// =====================
// GESTIÓN DE ANIMALES - AJAX
// =====================

class GestorAnimales {
    constructor() {
        this.init();
    }

    init() {
        this.setupEventListeners();
    }

    setupEventListeners() {
        document.body.addEventListener("click", async (e) => {
            const boton = e.target.closest("[data-accion]");
            if (!boton) return;
            e.preventDefault();

            const accion = boton.dataset.accion;
            const id = boton.dataset.id;

            console.log("🔍 Botón clickeado:", { accion, id });

            if (this.esAccionAnimal(accion)) {
                await this.ejecutarAccionAnimal(accion, id, boton);
            }
        });
    }

    esAccionAnimal(accion) {
        const accionesAnimales = [
            "btn-inhabilitar-perros", "btn-reincorporar-perros", 
            "btn-inhabilitar-gato", "btn-reincorporar-gato",
            "btn-inhabilitar-otros", "btn-reincorporar-otros"
        ];
        return accionesAnimales.includes(accion);
    }

    async ejecutarAccionAnimal(accion, id, boton) {
        const config = this.obtenerConfiguracionAccion(accion);
        
        if (!config) {
            this.mostrarAlerta("Acción de animal no válida", "error");
            return;
        }

        console.log("🐾 Enviando petición animal:", { accion, url: config.url, id });

        try {
            // Mostrar estado de carga
            this.mostrarCarga(boton);

            const response = await this.enviarPeticionAnimal(config.url, id);
            const data = await this.procesarRespuestaAnimal(response);

            if (data.exito) {
                this.actualizarInterfazAnimal(data, boton, id, config.especie);
                this.mostrarMensajeExito(accion, data.mensaje);
            } else {
                this.mostrarAlerta(data.mensaje || "Error al actualizar el estado", "error");
            }

        } catch (error) {
            console.error("❌ Error animal:", error);
            this.mostrarAlerta(`Error de conexión: ${error.message}`, "error");
        } finally {
            this.ocultarCarga(boton);
        }
    }

  obtenerConfiguracionAccion(accion) {
    const mapaAcciones = {
        'btn-reincorporar-perros': { 
            url: './Presentacion/CambiarEstados/ActivarPerros.php', 
            especie: 'perro'
        },
        'btn-inhabilitar-perros': { 
            url: './Presentacion/CambiarEstados/InhabilitarPerros.php', 
            especie: 'perro'
        },
        'btn-reincorporar-gato': { 
            url: './Presentacion/CambiarEstados/ActivarGatos.php', 
            especie: 'gato'
        },
        'btn-inhabilitar-gato': { 
            url: './Presentacion/CambiarEstados/InhabilitarGatos.php', 
            especie: 'gato'
        },
        'btn-reincorporar-otros': { 
            url: './Presentacion/CambiarEstados/ActivarOtros.php', 
            especie: 'otro'
        },
        'btn-inhabilitar-otros': { 
            url: './Presentacion/CambiarEstados/InhabilitarOtros.php', 
            especie: 'otro'
        }
    };

    return mapaAcciones[accion];
}

    async enviarPeticionAnimal(url, id) {
        const urlConCache = url + '?t=' + Date.now();
        
        const response = await fetch(urlConCache, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: new URLSearchParams({ id: id })
        });

        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status} ${response.statusText}`);
        }

        return response;
    }

    async procesarRespuestaAnimal(response) {
        const responseText = await response.text();
        console.log("📝 Respuesta completa:", responseText);

        const cleanResponse = this.limpiarRespuesta(responseText);
        console.log("🧹 Respuesta limpia:", cleanResponse);

        try {
            return JSON.parse(cleanResponse);
        } catch (jsonError) {
            console.error("❌ Error parseando JSON:", jsonError);
            const jsonMatch = cleanResponse.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                return JSON.parse(jsonMatch[0]);
            } else {
                throw new Error("No se pudo extraer JSON válido de la respuesta");
            }
        }
    }

    limpiarRespuesta(texto) {
        let clean = texto.trim();
        
        if (clean.startsWith('`')) clean = clean.substring(1);
        if (clean.endsWith('`')) clean = clean.substring(0, clean.length - 1);
        
        clean = clean.replace(/^[^\{]*/, '');
        
        return clean;
    }

    mostrarCarga(boton) {
        boton.classList.add('processing');
        boton.disabled = true;
    }

    ocultarCarga(boton) {
        boton.classList.remove('processing');
        boton.disabled = false;
    }

    actualizarInterfazAnimal(data, boton, id, especie) {
        console.log("🔍 DEBUG - Datos recibidos:", data);
        console.log("🔍 DEBUG - Especie:", especie);
        
        const fila = boton.closest("tr");
        if (!fila) {
            console.error("No se encontró la fila del animal");
            return;
        }

        const tdEstado = fila.querySelector("td:nth-child(6)");
        const tdAcciones = fila.querySelector(".animal-actions");

        // Actualizar estado
        if (tdEstado) {
            tdEstado.innerHTML = this.crearBadgeEstado(data.nuevoEstado);
            console.log("✅ Estado actualizado a:", data.nuevoEstado);
        }

        // Actualizar botones
        if (tdAcciones) {
            tdAcciones.innerHTML = this.crearBotonAnimal(data.nuevoEstado, id, especie);
            console.log("🔄 Botones actualizados");
        }

        console.log("✅ Interfaz actualizada correctamente");
    }

    crearBadgeEstado(estado) {
        return `<span class="status-badge ${estado}">${estado}</span>`;
    }

    crearBotonAnimal(estado, id, especie) {
    const tipoEspecie = this.obtenerTipoEspecie(especie);
    
    if (estado === "adoptado") {
        return `
            <button type="button" 
                    data-accion="btn-reincorporar-${tipoEspecie}" 
                    data-id="${id}" 
                    class="btn-admin btn-activar"
                    title="Marcar como disponible">
                ✅ Disponible
            </button>
        `;
    } else {
        return `
            <button type="button" 
                    data-accion="btn-inhabilitar-${tipoEspecie}" 
                    data-id="${id}"
                    class="btn-admin btn-inhabilitar"
                    title="Marcar como adoptado">
                🏠 Adoptado
            </button>
        `;
    }
}
    obtenerTipoEspecie(especie) {
        const tipos = {
            'perro': 'perros',
            'gato': 'gato',
            'otro': 'otros'
        };
        return tipos[especie] || especie;
    }

    mostrarMensajeExito(accion, mensaje) {
        if (accion.includes('inhabilitar')) {
            this.mostrarAlerta('Animal marcado como adoptado y registrado en el historial ✅', "success");
        } else {
            this.mostrarAlerta(mensaje, "success");
        }
    }

    mostrarAlerta(mensaje, tipo) {
        const alertasExistentes = document.querySelectorAll('.alerta-temporal');
        alertasExistentes.forEach(alerta => alerta.remove());

        const alerta = document.createElement('div');
        alerta.className = `alerta-temporal ${tipo}`;
        alerta.textContent = mensaje;
        
        alerta.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            z-index: 10000;
            background-color: ${tipo === 'success' ? '#4CAF50' : '#f44336'};
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        `;
        
        document.body.appendChild(alerta);
        
        setTimeout(() => {
            if (alerta.parentElement) {
                alerta.parentElement.removeChild(alerta);
            }
        }, 4000);
    }
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    new GestorAnimales();
});