// MODAL ANIMALES - JavaScript con AJAX y actualización instantánea
class ModalAnimales {
    constructor() {
        this.modal = document.getElementById('modalEditarAnimal');
        this.form = document.getElementById('formEditarAnimal');
        this.btnCancelar = document.getElementById('btnCancelar');
        this.btnCerrar = document.querySelector('.modal-animal-close');
        this.btnGuardar = document.getElementById('btnGuardar');
        this.loadingSpinner = this.btnGuardar.querySelector('.loading-spinner');
        this.btnText = this.btnGuardar.querySelector('.btn-text');
        
        this.init();
    }

    init() {
        // Event listeners
        this.btnCancelar.addEventListener('click', () => this.cerrar());
        this.btnCerrar.addEventListener('click', () => this.cerrar());
        
        // Cerrar modal al hacer click fuera
        this.modal.addEventListener('click', (e) => {
            if (e.target === this.modal) {
                this.cerrar();
            }
        });

        // Enviar formulario
        this.form.addEventListener('submit', (e) => this.enviarFormulario(e));

        // Event listeners para botones editar
        this.inicializarBotonesEditar();

        // Mostrar alertas PHP si existen
        this.mostrarAlertasPHP();

        // Cerrar modal con ESC
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.modal.style.display === 'block') {
                this.cerrar();
            }
        });
    }

    inicializarBotonesEditar() {
        // Remover event listeners existentes para evitar duplicados
        document.querySelectorAll('.btn-editar').forEach(btn => {
            btn.replaceWith(btn.cloneNode(true));
        });
        
        // Agregar event listeners a los botones nuevos
        document.querySelectorAll('.btn-editar').forEach(btn => {
            btn.addEventListener('click', () => {
                const datos = {
                    id: btn.dataset.id,
                    tipo: btn.dataset.tipo,
                    nombre: btn.dataset.nombre,
                    raza: btn.dataset.raza,
                    edad: btn.dataset.edad,
                    sexo: btn.dataset.sexo,
                    estado: btn.dataset.estado,
                    foto: btn.dataset.foto
                };
                this.abrir(datos);
            });
        });
    }

    abrir(datos) {
        console.log('Abriendo modal con datos:', datos);
        
        // Llenar formulario con datos
        document.getElementById('edit_animal_id').value = datos.id;
        document.getElementById('edit_animal_tipo').value = datos.tipo;
        document.getElementById('edit_nombre').value = datos.nombre;
        document.getElementById('edit_raza').value = datos.raza || '';
        document.getElementById('edit_edad').value = datos.edad || '';
        document.getElementById('edit_sexo').value = datos.sexo || 'macho';
        document.getElementById('edit_estado').value = datos.estado || 'disponible';
        document.getElementById('edit_especie').value = datos.tipo;
        document.getElementById('edit_foto_actual').value = datos.foto || '';
        
        // Mostrar foto actual
        this.mostrarFotoActual(datos.foto);
        
        // Mostrar modal
        this.modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
        
        // Animación de entrada
        setTimeout(() => {
            this.modal.classList.add('modal-open');
        }, 10);
    }

    mostrarFotoActual(foto) {
        const preview = document.getElementById('preview_foto_actual');
        const texto = document.getElementById('texto_foto_actual');
        
        if (foto && foto !== 'null' && foto !== '') {
            preview.src = './Fotoss/' + foto;
            preview.style.display = 'block';
            texto.textContent = foto;
            texto.style.display = 'none';
        } else {
            preview.style.display = 'none';
            texto.textContent = 'No hay foto disponible';
            texto.style.display = 'block';
        }
    }

    cerrar() {
        this.modal.classList.remove('modal-open');
        
        setTimeout(() => {
            this.modal.style.display = 'none';
            document.body.style.overflow = 'auto';
            this.form.reset();
        }, 300);
    }

    async enviarFormulario(e) {
        e.preventDefault();
        
        const formData = new FormData(this.form);
        const textoOriginal = this.btnText.textContent;
        
        // DEBUG: Mostrar datos del formulario
        console.log('Datos del formulario:');
        for (let [key, value] of formData.entries()) {
            if (key === 'foto') {
                console.log(key + ': ' + (value.name || 'No file'));
            } else {
                console.log(key + ': ' + value);
            }
        }
        
        try {
            // Mostrar loading
            this.btnGuardar.disabled = true;
            this.loadingSpinner.style.display = 'block';
            this.btnText.textContent = 'Guardando...';

            console.log('Enviando datos al servidor...');
            
            const respuesta = await fetch('actualizar_animal.php', {
                method: 'POST',
                body: formData
            });

            const textoRespuesta = await respuesta.text();
            console.log('Respuesta completa del servidor:', textoRespuesta);
            
            this.procesarRespuesta(textoRespuesta);

        } catch (error) {
            console.error('Error de conexión:', error);
            this.mostrarError('Error de conexión: ' + error.message);
        } finally {
            // Restaurar botón
            this.btnGuardar.disabled = false;
            this.loadingSpinner.style.display = 'none';
            this.btnText.textContent = textoOriginal;
        }
    }

    procesarRespuesta(respuestaTexto) {
        console.log('Respuesta del servidor:', respuestaTexto);
        
        let jsonTexto = respuestaTexto.trim();
        
        // Limpiar BOM si existe
        if (jsonTexto.charCodeAt(0) === 0xFEFF) {
            jsonTexto = jsonTexto.substring(1);
        }
        
        // Extraer JSON si hay contenido alrededor
        const inicio = jsonTexto.indexOf('{');
        const fin = jsonTexto.lastIndexOf('}') + 1;
        
        if (inicio !== -1 && fin !== -1) {
            jsonTexto = jsonTexto.substring(inicio, fin);
        }
        
        let resultado;
        try {
            resultado = JSON.parse(jsonTexto);
        } catch (parseError) {
            console.error('Error parseando JSON:', parseError);
            this.mostrarError('Error: Respuesta inválida del servidor');
            return;
        }

        if (resultado.success) {
            this.mostrarAlerta('✅ ' + resultado.message, 'success');
            this.cerrar();
            
            // ACTUALIZAR SOLO LA FILA MODIFICADA - SIN RECARGAR PÁGINA
            this.actualizarFilaEnTabla(resultado.datos);
            
        } else {
            this.mostrarError('❌ ' + resultado.message);
        }
    }

    // FUNCIÓN MEJORADA: Actualizar solo la fila modificada instantáneamente
    actualizarFilaEnTabla(datosAnimal) {
        console.log('🔄 Actualizando fila con datos:', datosAnimal);
        
        // Buscar el botón editar que tiene este ID
        const botonesEditar = document.querySelectorAll('.btn-editar');
        let fila = null;
        let botonEditar = null;
        
        for (let boton of botonesEditar) {
            if (boton.dataset.id === datosAnimal.id) {
                fila = boton.closest('tr');
                botonEditar = boton;
                break;
            }
        }
        
        if (!fila) {
            console.error('❌ No se encontró la fila para actualizar');
            this.mostrarAlerta('✅ Animal actualizado', 'success');
            return;
        }
        
        const celdas = fila.querySelectorAll('td');
        
        // 1. Actualizar FOTO (celda 0)
        const contenedorFoto = celdas[0];
        if (datosAnimal.foto && datosAnimal.foto !== 'null') {
            const imgExistente = contenedorFoto.querySelector('.animal-img');
            const placeholder = contenedorFoto.querySelector('.photo-placeholder');
            
            if (imgExistente) {
                // Actualizar imagen existente
                imgExistente.src = `./Fotoss/${datosAnimal.foto}`;
                imgExistente.alt = `Foto de ${datosAnimal.nombre}`;
            } else if (placeholder) {
                // Reemplazar placeholder por imagen
                placeholder.outerHTML = `<img src="./Fotoss/${datosAnimal.foto}" 
                                             alt="Foto de ${datosAnimal.nombre}" 
                                             class="animal-img">`;
            } else {
                // Crear nueva imagen
                contenedorFoto.innerHTML = `<img src="./Fotoss/${datosAnimal.foto}" 
                                               alt="Foto de ${datosAnimal.nombre}" 
                                               class="animal-img">`;
            }
        } else {
            // Si no hay foto, mostrar placeholder
            contenedorFoto.innerHTML = `<div class="photo-placeholder">${this.getIconoPorTipo(datosAnimal.tipo)}</div>`;
        }
        
        // 2. Actualizar NOMBRE (celda 1)
        if (celdas[1].querySelector('.animal-name')) {
            celdas[1].querySelector('.animal-name').textContent = datosAnimal.nombre;
        } else {
            celdas[1].innerHTML = `<span class="animal-name">${datosAnimal.nombre}</span>`;
        }
        
        // 3. Actualizar RAZA (celda 2)
        celdas[2].textContent = datosAnimal.raza || '-';
        
        // 4. Actualizar EDAD (celda 3)
        celdas[3].textContent = datosAnimal.edad || '-';
        
        // 5. Actualizar SEXO (celda 4)
        const sexoBadge = celdas[4].querySelector('.sex-badge');
        if (sexoBadge) {
            sexoBadge.textContent = datosAnimal.sexo;
            sexoBadge.className = `sex-badge ${datosAnimal.sexo.toLowerCase()}`;
        } else {
            celdas[4].innerHTML = `<span class="sex-badge ${datosAnimal.sexo.toLowerCase()}">${datosAnimal.sexo}</span>`;
        }
        
        // 6. Actualizar ESTADO (celda 5)
        const estadoBadge = celdas[5].querySelector('.status-badge');
        if (estadoBadge) {
            estadoBadge.textContent = datosAnimal.estado;
            estadoBadge.className = `status-badge ${datosAnimal.estado}`;
        } else {
            celdas[5].innerHTML = `<span class="status-badge ${datosAnimal.estado}">${datosAnimal.estado}</span>`;
        }
        
        // 7. Actualizar BOTÓN DE ESTADO (celda 6)
        this.actualizarBotonEstado(celdas[6], datosAnimal);
        
        // 8. Actualizar DATOS DEL BOTÓN EDITAR (celda 7)
        if (botonEditar) {
            botonEditar.dataset.nombre = datosAnimal.nombre;
            botonEditar.dataset.raza = datosAnimal.raza || '';
            botonEditar.dataset.edad = datosAnimal.edad || '';
            botonEditar.dataset.sexo = datosAnimal.sexo;
            botonEditar.dataset.estado = datosAnimal.estado;
            botonEditar.dataset.foto = datosAnimal.foto || '';
        }
        
        // Efecto visual de actualización
        this.aplicarEfectoActualizacion(fila);
        
        console.log('✅ Fila actualizada instantáneamente');
    }

    // Función para actualizar el botón de cambiar estado
    actualizarBotonEstado(celdaAcciones, datosAnimal) {
        if (datosAnimal.estado === 'adoptado') {
            celdaAcciones.innerHTML = `
                <button type="button" 
                        data-accion="btn-reincorporar-${datosAnimal.tipo}" 
                        data-id="${datosAnimal.id}" 
                        class="btn-admin btn-activar"
                        title="Marcar como disponible">
                    ✅ Disponible
                </button>
            `;
        } else {
            celdaAcciones.innerHTML = `
                <button type="button" 
                        data-accion="btn-inhabilitar-${datosAnimal.tipo}" 
                        data-id="${datosAnimal.id}" 
                        class="btn-admin btn-inhabilitar"
                        title="Marcar como adoptado">
                    🏠 Adoptado
                </button>
            `;
        }
        
        // Agregar event listener al nuevo botón
        const nuevoBoton = celdaAcciones.querySelector('.btn-admin');
        if (nuevoBoton) {
            nuevoBoton.addEventListener('click', (e) => {
                e.preventDefault();
                this.mostrarAlerta('ℹ️ Usa el botón "Editar" para cambiar el estado', 'success');
            });
        }
    }

    // Función para obtener icono según tipo de animal
    getIconoPorTipo(tipo) {
        const iconos = {
            'perro': '🐕',
            'gato': '🐈',
            'otro': '🐾'
        };
        return iconos[tipo] || '🐾';
    }

    // Función para efecto visual de actualización
    aplicarEfectoActualizacion(fila) {
        // Agregar clase de animación
        fila.style.transition = 'all 0.5s ease';
        fila.style.backgroundColor = 'rgba(76, 175, 80, 0.1)';
        
        // Efecto de "pulse"
        fila.animate([
            { transform: 'scale(1)', backgroundColor: 'rgba(76, 175, 80, 0.1)' },
            { transform: 'scale(1.02)', backgroundColor: 'rgba(76, 175, 80, 0.2)' },
            { transform: 'scale(1)', backgroundColor: 'rgba(76, 175, 80, 0.1)' }
        ], {
            duration: 800,
            easing: 'ease-in-out'
        });
        
        // Quitar el color de fondo después de la animación
        setTimeout(() => {
            fila.style.backgroundColor = '';
        }, 2000);
    }

    mostrarAlerta(mensaje, tipo) {
        // Eliminar alertas existentes
        const alertasExistentes = document.querySelectorAll('.alerta-temporal');
        alertasExistentes.forEach(alerta => alerta.remove());

        const alerta = document.createElement('div');
        alerta.className = `alerta-temporal ${tipo}`;
        alerta.textContent = mensaje;
        
        document.body.appendChild(alerta);
        
        setTimeout(() => {
            if (alerta.parentElement) {
                alerta.parentElement.removeChild(alerta);
            }
        }, 4000);
    }

    mostrarError(mensaje) {
        this.mostrarAlerta(mensaje, 'error');
    }

    mostrarAlertasPHP() {
        if (isset($alerta))
            setTimeout(() => {
                this.mostrarAlerta('<?= $alerta['+mensaje+'] ?>', '<?= $alerta['+tipo+'] ?>');
            }, 500);
        endif;
    }
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    new ModalAnimales();
});