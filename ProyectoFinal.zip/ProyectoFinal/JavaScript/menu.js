/**
 * Gestor de menú desplegable
 */
class GestorMenu {
    constructor() {
        this.menuBtn = document.getElementById('menuBtn');
        this.menuContent = document.getElementById('menuContent');
        this.init();
    }

    init() {
        if (this.menuBtn && this.menuContent) {
            this.setupEventListeners();
        }
    }

    setupEventListeners() {
        // Toggle menu al hacer click
        this.menuBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.toggleMenu();
        });

        // Cerrar menu al hacer click fuera
        window.addEventListener('click', (e) => {
            if (!this.menuBtn.contains(e.target) && !this.menuContent.contains(e.target)) {
                this.cerrarMenu();
            }
        });

        // Cerrar menu con ESC
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.cerrarMenu();
            }
        });
    }

    toggleMenu() {
        this.menuContent.classList.toggle('show');
    }

    cerrarMenu() {
        this.menuContent.classList.remove('show');
    }
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    new GestorMenu();
});