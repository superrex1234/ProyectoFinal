// Función para mostrar/ocultar contraseña
function togglePasswordVisibility(inputId, toggleId) {
    const passwordInput = document.getElementById(inputId);
    const toggleButton = document.getElementById(toggleId);
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleButton.textContent = 'Ocultar';
        toggleButton.classList.add('active');
    } else {
        passwordInput.type = 'password';
        toggleButton.textContent = 'Mostrar';
        toggleButton.classList.remove('active');
    }
}

// Inicializar cuando el DOM esté cargado
document.addEventListener('DOMContentLoaded', function() {
    // Agregar botones de mostrar/ocultar contraseña si existen los campos
    const passwordFields = document.querySelectorAll('input[type="password"]');
    
    passwordFields.forEach(field => {
        // Verificar si ya tiene el contenedor
        if (!field.parentNode.classList.contains('password-container')) {
            const container = document.createElement('div');
            container.className = 'password-container';
            
            // Envolver el campo de contraseña en un contenedor
            field.parentNode.insertBefore(container, field);
            container.appendChild(field);
            
            // Crear botón de mostrar/ocultar
            const toggleButton = document.createElement('button');
            toggleButton.type = 'button';
            toggleButton.className = 'password-toggle';
            toggleButton.textContent = 'Mostrar';
            toggleButton.id = `toggle-${field.id}`;
            
            // Agregar evento al botón
            toggleButton.addEventListener('click', function() {
                togglePasswordVisibility(field.id, this.id);
            });
            
            container.appendChild(toggleButton);
        }
    });
});