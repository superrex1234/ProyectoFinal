document.addEventListener("DOMContentLoaded", () => {
    const alerta = document.getElementById("alerta");
  
    if (alerta) {
      alerta.classList.add("mostrar");
  
   
    }
  });
  
  function cerrarAlerta() {
    const alerta = document.getElementById("alerta");
    if (!alerta) return;
  
    alerta.style.opacity = 0;
    alerta.style.pointerEvents = "none";
    setTimeout(() => alerta.remove(), 300);
  }
  