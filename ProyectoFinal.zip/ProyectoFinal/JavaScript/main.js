class GestorUsuarios {
    constructor() {
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupSearch();
    }

    setupEventListeners() {
        // Escuchar clicks en botones de acción
        document.body.addEventListener("click", async (e) => {
            const boton = e.target.closest("[data-accion]");
            if (!boton) return;
            e.preventDefault();

            const accion = boton.dataset.accion;
            const id = boton.dataset.id;

            if (this.esAccionUsuario(accion)) {
                await this.ejecutarAccionUsuario(accion, id, boton);
            }
        });
    }

    esAccionUsuario(accion) {
        return ["inhabilitar-usuario", "activar-usuario"].includes(accion);
    }

    async ejecutarAccionUsuario(accion, id, boton) {
    const url = this.obtenerUrlAccion(accion);
    
    if (!url) {
        this.mostrarAlerta("Acción no válida", "error");
        return;
    }

    console.log("🔍 Enviando petición:", { accion, url, id });

    try {
        // Mostrar loading en el botón
        const textoOriginal = boton.innerHTML;
        boton.innerHTML = '⏳ Procesando...';
        boton.disabled = true;
        boton.classList.add('processing');

        const response = await this.enviarPeticion(url, id);
        const data = await this.procesarRespuesta(response);

        if (data.exito) {
            this.actualizarInterfazUsuario(data, boton, id);
            this.mostrarAlerta(data.mensaje, "success");
        } else {
            this.mostrarAlerta(data.mensaje || "Error en la operación", "error");
        }

    } catch (error) {
        console.error("❌ Error completo:", error);
        this.mostrarAlerta(`Error: ${error.message}`, "error");
    } finally {
        // Restaurar botón
        boton.innerHTML = textoOriginal;
        boton.disabled = false;
        boton.classList.remove('processing');
    }
}

    obtenerUrlAccion(accion) {
        const urls = {
            'inhabilitar-usuario': './Presentacion/CambiarEstados/InhabilitarUsuario.php',
            'activar-usuario': './Presentacion/CambiarEstados/ActivarUsuario.php'
        };
        return urls[accion];
    }

    async enviarPeticion(url, id) {
        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: new URLSearchParams({ id: id })
        });

        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status} ${response.statusText}`);
        }

        return response;
    }

    async procesarRespuesta(response) {
        const responseText = await response.text();
        console.log("📝 Respuesta completa:", responseText);

        // Limpiar respuesta
        let cleanResponse = this.limpiarRespuesta(responseText);
        console.log("🧹 Respuesta limpia:", cleanResponse);

        try {
            return JSON.parse(cleanResponse);
        } catch (jsonError) {
            console.error("❌ Error parseando JSON:", jsonError);
            const jsonMatch = cleanResponse.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                return JSON.parse(jsonMatch[0]);
            } else {
                throw new Error("No se pudo extraer JSON válido de la respuesta");
            }
        }
    }

    limpiarRespuesta(texto) {
        let clean = texto.trim();
        
        // Eliminar backticks
        if (clean.startsWith('`')) clean = clean.substring(1);
        if (clean.endsWith('`')) clean = clean.substring(0, clean.length - 1);
        
        // Eliminar caracteres no JSON al inicio
        clean = clean.replace(/^[^\{]*/, '');
        
        return clean;
    }

    actualizarInterfazUsuario(data, boton, id) {
        console.log("🔍 DEBUG - Datos recibidos:", data);
        
        const fila = boton.closest("tr");
        if (!fila) {
            console.error("No se encontró la fila del usuario");
            return;
        }

        const tdEstado = fila.querySelector("[data-tipo='estado']");
        const tdAcciones = fila.querySelector("[data-tipo='acciones']");

        // Actualizar estado
        if (tdEstado) {
            tdEstado.innerHTML = this.crearBadgeEstado(data.nuevoEstado);
            console.log("✅ Estado actualizado a:", data.nuevoEstado);
        }

        // Actualizar botones
        if (tdAcciones) {
            tdAcciones.innerHTML = this.crearBotonAccion(data.nuevoEstado, id);
            console.log("🔄 Botón actualizado");
        }

        this.reaplicarEventListeners(tdAcciones);
    }

    crearBadgeEstado(estado) {
        return `<span class="status-badge ${estado}">${estado}</span>`;
    }

    crearBotonAccion(estado, id) {
        if (estado === "activo") {
            return `
                <button type="button"
                        data-accion="inhabilitar-usuario"
                        data-id="${id}"
                        class="btn-admin btn-inhabilitar"
                        title="Inhabilitar usuario">
                    🚫 Inhabilitar
                </button>
            `;
        } else {
            return `
                <button type="button"
                        data-accion="activar-usuario"
                        data-id="${id}"
                        class="btn-admin btn-activar"
                        title="Activar usuario">
                    ✅ Activar
                </button>
            `;
        }
    }

    reaplicarEventListeners(container) {
        const nuevoBoton = container?.querySelector('.btn-admin');
        if (nuevoBoton) {
            nuevoBoton.addEventListener('click', function() {
                this.classList.add('processing');
                setTimeout(() => {
                    this.classList.remove('processing');
                }, 2000);
            });
            console.log("✅ Event listener aplicado al nuevo botón");
        }
    }

    setupSearch() {
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.filtrarUsuarios(e.target.value.toLowerCase());
            });
        }
    }

    filtrarUsuarios(termino) {
        const rows = document.querySelectorAll('.user-row');
        
        rows.forEach(row => {
            const searchData = row.getAttribute('data-search');
            if (searchData.includes(termino)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    mostrarAlerta(mensaje, tipo) {
        // Eliminar alertas existentes
        const alertasExistentes = document.querySelectorAll('.alerta-temporal');
        alertasExistentes.forEach(alerta => alerta.remove());

        // Crear nueva alerta
        const alerta = document.createElement("div");
        alerta.className = `alerta-temporal ${tipo}`;
        alerta.textContent = mensaje;
        
        alerta.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            z-index: 10000;
            background-color: ${tipo === 'success' ? '#4CAF50' : '#f44336'};
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        `;
        
        document.body.appendChild(alerta);
        
        // Auto-eliminar después de 4 segundos
        setTimeout(() => {
            if (alerta.parentElement) {
                alerta.parentElement.removeChild(alerta);
            }
        }, 4000);
    }
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    new GestorUsuarios();
});