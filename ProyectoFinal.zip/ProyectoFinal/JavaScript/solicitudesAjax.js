// =====================
// GESTIÓN DE SOLICITUDES - AJAX
// =====================

class GestorSolicitudes {
    constructor() {
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupSearch();
        this.setupContactoModal();
    }

    setupEventListeners() {
        // Escuchar cambios en los select de estado
        document.body.addEventListener("change", async (e) => {
            const select = e.target.closest('.select-estado');
            if (select) {
                e.preventDefault();
                await this.cambiarEstadoSolicitud(select);
            }
        });

        // Escuchar clicks en botones de eliminar
        document.body.addEventListener("click", async (e) => {
            const boton = e.target.closest('.btn-eliminar');
            if (boton) {
                e.preventDefault();
                await this.eliminarSolicitud(boton);
            }
        });

        // Escuchar clicks en botones de contacto
        document.body.addEventListener("click", async (e) => {
            const boton = e.target.closest('.btn-contactar');
            if (boton) {
                e.preventDefault();
                await this.contactarUsuario(boton);
            }
        });
    }

    setupContactoModal() {
        // Crear modal de contacto si no existe
        if (!document.getElementById('modalContacto')) {
            const modalHTML = `
                <div id="modalContacto" class="modal-contacto">
                    <div class="modal-contacto-content">
                        <div class="modal-contacto-header">
                            <h3>Contactar Usuario</h3>
                            <button type="button" class="close-contacto">&times;</button>
                        </div>
                        <div class="modal-contacto-body">
                            <div id="infoContacto" class="info-contacto">
                                <!-- Información se cargará dinámicamente -->
                            </div>
                            <div class="form-group-contacto">
                                <label for="notasContacto">Notas internas (solo para admin):</label>
                                <textarea id="notasContacto" placeholder="Notas privadas para registro interno..."></textarea>
                            </div>
                            <div class="form-group-contacto">
                                <label for="mensajeAdmin">Mensaje para el usuario (se mostrará en sus solicitudes):</label>
                                <textarea id="mensajeAdmin" placeholder="Ej: ¡Felicidades! Tu solicitud ha sido aprobada. Por favor contáctanos para coordinar la visita..."></textarea>
                            </div>
                        </div>
                        <div class="modal-contacto-actions">
                            <button type="button" class="btn-cerrar-contacto">Cancelar</button>
                            <button type="button" class="btn-confirmar-contacto">Confirmar Contacto</button>
                        </div>
                    </div>
                </div>
            `;
            document.body.insertAdjacentHTML('beforeend', modalHTML);
            
            // Event listeners para el modal
            this.setupModalEventListeners();
        }
    }

    setupModalEventListeners() {
        const modal = document.getElementById('modalContacto');
        const closeBtn = modal.querySelector('.close-contacto');
        const cancelBtn = modal.querySelector('.btn-cerrar-contacto');
        const confirmBtn = modal.querySelector('.btn-confirmar-contacto');
        
        [closeBtn, cancelBtn].forEach(btn => {
            btn.addEventListener('click', () => this.cerrarModalContacto());
        });
        
        confirmBtn.addEventListener('click', () => this.confirmarContacto());
        
        // Cerrar modal al hacer click fuera
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                this.cerrarModalContacto();
            }
        });
    }

    async cambiarEstadoSolicitud(selectElement) {
        const solicitudId = selectElement.getAttribute('data-solicitud-id');
        const nuevoEstado = selectElement.value;

        console.log("🔍 Cambiando estado de solicitud:", { solicitudId, nuevoEstado });

        if (!solicitudId || !nuevoEstado) {
            this.mostrarAlerta("Datos incompletos", "error");
            return;
        }

        try {
            // Mostrar estado de carga
            this.mostrarCarga(selectElement);

            const response = await this.enviarPeticionSolicitud('./Presentacion/CambiarEstados/CambiarEstadoSolicitud.php', {
                solicitud_id: solicitudId,
                nuevo_estado: nuevoEstado
            });

            const data = await this.procesarRespuestaSolicitud(response);

            if (data.exito) {
                this.actualizarInterfazSolicitud(data, selectElement, nuevoEstado);
                this.mostrarAlerta('Estado actualizado correctamente ✅', "success");
                this.actualizarEstadisticas();
            } else {
                this.mostrarAlerta(data.mensaje || "Error al actualizar el estado", "error");
                // Revertir el cambio en el select
                this.revertirEstadoSelect(selectElement, data.estadoAnterior);
            }

        } catch (error) {
            console.error("❌ Error al cambiar estado:", error);
            this.mostrarAlerta(`Error de conexión: ${error.message}`, "error");
            this.revertirEstadoSelect(selectElement);
        } finally {
            this.ocultarCarga(selectElement);
        }
    }

    async eliminarSolicitud(boton) {
        const solicitudId = boton.getAttribute('data-solicitud-id');
        
        if (!solicitudId) {
            this.mostrarAlerta("ID de solicitud no encontrado", "error");
            return;
        }

        // Confirmación antes de eliminar
        if (!confirm('¿Estás seguro de que quieres eliminar esta solicitud?')) {
            return;
        }

        console.log("🗑️ Eliminando solicitud:", solicitudId);

        try {
            this.mostrarCarga(boton);

            const response = await this.enviarPeticionSolicitud('./Presentacion/CambiarEstados/EliminarSolicitud.php', {
                solicitud_id: solicitudId
            });

            const data = await this.procesarRespuestaSolicitud(response);

            if (data.exito) {
                this.eliminarFilaSolicitud(boton);
                this.mostrarAlerta('Solicitud eliminada correctamente ✅', "success");
                this.actualizarEstadisticas();
            } else {
                this.mostrarAlerta(data.mensaje || "Error al eliminar la solicitud", "error");
            }

        } catch (error) {
            console.error("❌ Error al eliminar:", error);
            this.mostrarAlerta(`Error de conexión: ${error.message}`, "error");
        } finally {
            this.ocultarCarga(boton);
        }
    }

    async contactarUsuario(boton) {
        const solicitudId = boton.getAttribute('data-solicitud-id');
        
        if (!solicitudId) {
            this.mostrarAlerta("ID de solicitud no encontrado", "error");
            return;
        }
        
        try {
            this.mostrarCarga(boton);
            
            // Obtener información de la solicitud
            const response = await fetch(`./Presentacion/CambiarEstados/ObtenerInfoSolicitud.php?solicitud_id=${solicitudId}&t=${Date.now()}`);
            
            if (!response.ok) {
                throw new Error(`Error HTTP: ${response.status}`);
            }
            
            const data = await response.json();
            
            if (data.exito) {
                this.mostrarModalContacto(data.info, solicitudId);
            } else {
                this.mostrarAlerta(data.mensaje || "Error al obtener información", "error");
            }
            
        } catch (error) {
            console.error("❌ Error al obtener información:", error);
            this.mostrarAlerta(`Error de conexión: ${error.message}`, "error");
        } finally {
            this.ocultarCarga(boton);
        }
    }

    mostrarModalContacto(info, solicitudId) {
        this.setupContactoModal();
        
        const modal = document.getElementById('modalContacto');
        const infoContainer = document.getElementById('infoContacto');
        
        // Llenar información de contacto
        infoContainer.innerHTML = `
            <div class="info-item">
                <span class="info-label">Usuario:</span>
                <span class="info-value">${info.usuario}</span>
            </div>
            <div class="info-item">
                <span class="info-label">Email:</span>
                <span class="info-value">${info.email}</span>
            </div>
            <div class="info-item">
                <span class="info-label">Teléfono:</span>
                <span class="info-value">${info.telefono}</span>
            </div>
            <div class="info-item">
                <span class="info-label">Mascota:</span>
                <span class="info-value">${info.mascota}</span>
            </div>
        `;
        
        // Guardar ID de solicitud en el modal
        modal.setAttribute('data-solicitud-id', solicitudId);
        
        // Mostrar modal
        modal.classList.add('show');
        document.getElementById('mensajeAdmin').focus();
    }

    cerrarModalContacto() {
        const modal = document.getElementById('modalContacto');
        modal.classList.remove('show');
        document.getElementById('notasContacto').value = '';
        document.getElementById('mensajeAdmin').value = '';
    }

    async confirmarContacto() {
        const modal = document.getElementById('modalContacto');
        const solicitudId = modal.getAttribute('data-solicitud-id');
        const notasContacto = document.getElementById('notasContacto').value;
        const mensajeAdmin = document.getElementById('mensajeAdmin').value;
        const confirmBtn = modal.querySelector('.btn-confirmar-contacto');
        
        if (!solicitudId) {
            this.mostrarAlerta("Error: ID de solicitud no encontrado", "error");
            return;
        }
        
        // Validar que haya un mensaje para el usuario
        if (!mensajeAdmin.trim()) {
            this.mostrarAlerta("Por favor escribe un mensaje para el usuario", "error");
            document.getElementById('mensajeAdmin').focus();
            return;
        }
        
        try {
            this.mostrarCarga(confirmBtn);
            confirmBtn.disabled = true;
            
            const response = await this.enviarPeticionSolicitud('./Presentacion/CambiarEstados/ContactarUsuario.php', {
                solicitud_id: solicitudId,
                notas_contacto: notasContacto,
                mensaje_admin: mensajeAdmin
            });
            
            const data = await this.procesarRespuestaSolicitud(response);
            
            if (data.exito) {
                this.mostrarAlerta('Contacto registrado correctamente ✅', "success");
                this.cerrarModalContacto();
                this.actualizarInterfazContacto(solicitudId);
            } else {
                this.mostrarAlerta(data.mensaje || "Error al registrar contacto", "error");
            }
            
        } catch (error) {
            console.error("❌ Error al registrar contacto:", error);
            this.mostrarAlerta(`Error de conexión: ${error.message}`, "error");
        } finally {
            this.ocultarCarga(confirmBtn);
            confirmBtn.disabled = false;
        }
    }

    actualizarInterfazContacto(solicitudId) {
        const fila = document.querySelector(`.btn-contactar[data-solicitud-id="${solicitudId}"]`).closest('tr');
        if (fila) {
            const btnContactar = fila.querySelector('.btn-contactar');
            if (btnContactar) {
                btnContactar.classList.add('contactado');
                btnContactar.innerHTML = '✅ Contactado';
                btnContactar.disabled = true;
            }
            
            // Agregar badge de contactado
            const statusCell = fila.querySelector('.solicitud-status');
            if (statusCell) {
                const contactBadge = document.createElement('div');
                contactBadge.className = 'contact-badge contactado';
                contactBadge.textContent = 'Contactado';
                statusCell.appendChild(contactBadge);
            }
        }
    }

    async enviarPeticionSolicitud(url, datos) {
        const urlConCache = url + '?t=' + Date.now();
        
        console.log("📤 Enviando petición a:", urlConCache, "con datos:", datos);
        
        const response = await fetch(urlConCache, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: new URLSearchParams(datos)
        });

        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status} ${response.statusText}`);
        }

        return response;
    }

    async procesarRespuestaSolicitud(response) {
        const responseText = await response.text();
        console.log("📝 Respuesta completa:", responseText);

        const cleanResponse = this.limpiarRespuesta(responseText);
        console.log("🧹 Respuesta limpia:", cleanResponse);

        try {
            return JSON.parse(cleanResponse);
        } catch (jsonError) {
            console.error("❌ Error parseando JSON:", jsonError);
            // Intentar extraer JSON si está rodeado de texto
            const jsonMatch = cleanResponse.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                return JSON.parse(jsonMatch[0]);
            } else {
                // Si no es JSON válido, crear un objeto de error
                return {
                    exito: false,
                    mensaje: "Respuesta del servidor no válida: " + cleanResponse
                };
            }
        }
    }

    limpiarRespuesta(texto) {
        if (!texto) return '{}';
        
        let clean = texto.trim();
        
        // Eliminar backticks si existen
        if (clean.startsWith('`')) clean = clean.substring(1);
        if (clean.endsWith('`')) clean = clean.substring(0, clean.length - 1);
        
        // Buscar el primer { y el último }
        const firstBrace = clean.indexOf('{');
        const lastBrace = clean.lastIndexOf('}');
        
        if (firstBrace !== -1 && lastBrace !== -1) {
            clean = clean.substring(firstBrace, lastBrace + 1);
        }
        
        return clean;
    }

    mostrarCarga(elemento) {
        elemento.classList.add('processing');
        elemento.disabled = true;
        
        // Agregar spinner para selects
        if (elemento.classList.contains('select-estado')) {
            const spinner = document.createElement('span');
            spinner.className = 'select-spinner';
            spinner.innerHTML = '⏳';
            spinner.style.marginLeft = '5px';
            elemento.parentNode.appendChild(spinner);
        }
    }

    ocultarCarga(elemento) {
        elemento.classList.remove('processing');
        elemento.disabled = false;
        
        // Remover spinner si existe
        const spinner = elemento.parentNode.querySelector('.select-spinner');
        if (spinner) {
            spinner.remove();
        }
    }

    actualizarInterfazSolicitud(data, selectElement, nuevoEstado) {
        console.log("🔍 DEBUG - Datos recibidos:", data);
        
        const fila = selectElement.closest("tr");
        if (!fila) {
            console.error("No se encontró la fila de la solicitud");
            return;
        }

        // Actualizar badge de estado
        const tdEstado = fila.querySelector(".solicitud-status");
        if (tdEstado) {
            const badge = tdEstado.querySelector('.status-badge');
            if (badge) {
                badge.className = `status-badge estado-${nuevoEstado.toLowerCase()}`;
                badge.textContent = this.capitalizarEstado(nuevoEstado);
            }
            console.log("✅ Estado actualizado a:", nuevoEstado);
        }

        // Mostrar/ocultar botón de contacto según el estado
        this.actualizarBotonContacto(fila, nuevoEstado);

        console.log("✅ Interfaz actualizada correctamente");
    }

    actualizarBotonContacto(fila, nuevoEstado) {
        const btnContactar = fila.querySelector('.btn-contactar');
        if (btnContactar) {
            if (nuevoEstado === 'aprobada') {
                btnContactar.style.display = 'block';
            } else {
                btnContactar.style.display = 'none';
            }
        }
    }

    revertirEstadoSelect(selectElement, estadoAnterior = null) {
        if (selectElement && estadoAnterior) {
            selectElement.value = estadoAnterior;
        } else {
            // Si no hay estado anterior, recargar la página
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        }
    }

    eliminarFilaSolicitud(boton) {
        const fila = boton.closest("tr");
        if (fila) {
            // Animación de desvanecimiento
            fila.style.transition = 'all 0.3s ease';
            fila.style.opacity = '0';
            fila.style.transform = 'translateX(-100%)';
            
            setTimeout(() => {
                fila.remove();
                this.verificarTablaVacia();
            }, 300);
        }
    }

    verificarTablaVacia() {
        const tabla = document.querySelector('.solicitudes-table tbody');
        const filas = tabla.querySelectorAll('tr.solicitud-row');
        
        if (filas.length === 0) {
            this.mostrarEstadoVacio();
        }
    }

    mostrarEstadoVacio() {
        const tbody = document.querySelector('.solicitudes-table tbody');
        tbody.innerHTML = `
            <tr class="no-solicitudes">
                <td colspan="8">
                    <div class="empty-state">
                        <div class="empty-icon">📋</div>
                        <h3>No hay solicitudes aún</h3>
                        <p>No se han recibido solicitudes de adopción.</p>
                    </div>
                </td>
            </tr>
        `;
    }

    capitalizarEstado(estado) {
        return estado.charAt(0).toUpperCase() + estado.slice(1);
    }

    actualizarEstadisticas() {
        // Recargar la página para actualizar estadísticas
        setTimeout(() => {
            window.location.reload();
        }, 2000);
    }

    setupSearch() {
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.filtrarSolicitudes(e.target.value.toLowerCase());
            });
        }
    }

    filtrarSolicitudes(termino) {
        const rows = document.querySelectorAll('.solicitud-row');
        
        rows.forEach(row => {
            const searchData = row.getAttribute('data-search');
            if (searchData && searchData.includes(termino)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    mostrarAlerta(mensaje, tipo) {
        // Eliminar alertas existentes
        const alertasExistentes = document.querySelectorAll('.alerta-temporal');
        alertasExistentes.forEach(alerta => alerta.remove());

        // Crear nueva alerta
        const alerta = document.createElement('div');
        alerta.className = `alerta-temporal ${tipo}`;
        alerta.textContent = mensaje;
        
        // Estilos para la alerta
        Object.assign(alerta.style, {
            position: 'fixed',
            top: '20px',
            right: '20px',
            padding: '15px 20px',
            borderRadius: '5px',
            color: 'white',
            fontWeight: 'bold',
            zIndex: '10000',
            backgroundColor: tipo === 'success' ? '#4CAF50' : '#f44336',
            boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
            animation: 'slideIn 0.3s ease'
        });
        
        document.body.appendChild(alerta);
        
        // Auto-eliminar después de 4 segundos
        setTimeout(() => {
            if (alerta.parentElement) {
                alerta.parentElement.removeChild(alerta);
            }
        }, 4000);
    }

    // Método para debug
    debug() {
        console.log("🔍 Debug GestorSolicitudes:");
        console.log("Selects encontrados:", document.querySelectorAll('.select-estado').length);
        console.log("Botones eliminar:", document.querySelectorAll('.btn-eliminar').length);
        console.log("Botones contactar:", document.querySelectorAll('.btn-contactar').length);
        console.log("Filas de solicitudes:", document.querySelectorAll('.solicitud-row').length);
    }
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    const gestor = new GestorSolicitudes();
    gestor.debug(); // Debug inicial
    
    // También exponer globalmente para debugging
    window.gestorSolicitudes = gestor;
});

// Estilo CSS para la animación
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    .select-estado.processing {
        opacity: 0.7;
        background-color: #f0f0f0;
    }
    
    .btn-eliminar.processing {
        opacity: 0.7;
        background-color: #8B0000 !important;
    }
    
    .btn-contactar.processing {
        opacity: 0.7;
        background-color: #1976D2 !important;
    }
    
    .select-spinner {
        display: inline-block;
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
`;
document.head.appendChild(style);