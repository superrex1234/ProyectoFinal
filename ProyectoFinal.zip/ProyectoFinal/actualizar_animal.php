<?php
session_start();

if (!isset($_SESSION['ci']) || $_SESSION['tipo'] !== 'admin') {
    echo '{"success":false,"message":"No autorizado"}';
    exit;
}

// Incluir dependencias - CORREGIR RUTAS
include_once "./Logica/Perros.php";
include_once "./Persistencia/perrosbd.php";
include_once "./Presentacion/funcionImagen.php"; // Esta está bien si está en Presentacion

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo '{"success":false,"message":"Método no permitido"}';
    exit;
}

if (!isset($_POST['id']) || !isset($_POST['tipo']) || !isset($_POST['nombre'])) {
    echo '{"success":false,"message":"Datos incompletos"}';
    exit;
}

$id = $_POST['id'];
$tipo = $_POST['tipo'];
$nombre = $_POST['nombre'];
$raza = $_POST['raza'] ?? '';
$edad = $_POST['edad'] ?? '';
$sexo = $_POST['sexo'] ?? 'macho';
$estado = $_POST['estado'] ?? 'disponible';
$foto_actual = $_POST['foto_actual'] ?? '';

$perrosBD = new perrosBD();
$resultado = false;
$foto = $foto_actual;

// DEBUG: Verificar si la función CargarImagen existe
if (!function_exists('CargarImagen')) {
    error_log("❌ ERROR: La función CargarImagen no existe");
    echo '{"success":false,"message":"Error: Función de carga de imágenes no disponible"}';
    exit;
}

// Procesar nueva imagen si se subió
if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
    error_log("📸 Procesando nueva imagen...");
    
    $foto = CargarImagen($_FILES['foto']);
    
    if ($foto) {
        error_log("✅ Nueva imagen guardada: " . $foto);
        
        // Eliminar imagen anterior si existe y es diferente
        if ($foto_actual && $foto_actual !== $foto && $foto_actual !== 'null') {
            $ruta_anterior = "./Fotoss/" . $foto_actual;
            if (file_exists($ruta_anterior) && is_file($ruta_anterior)) {
                if (unlink($ruta_anterior)) {
                    error_log("🗑️ Imagen anterior eliminada: " . $foto_actual);
                } else {
                    error_log("⚠️ No se pudo eliminar imagen anterior: " . $foto_actual);
                }
            }
        }
    } else {
        error_log("❌ Error al procesar nueva imagen");
        // Mantener la foto actual si hay error
        $foto = $foto_actual;
    }
} else {
    error_log("ℹ️ No se subió nueva imagen. Error code: " . ($_FILES['foto']['error'] ?? 'N/A'));
    $foto = $foto_actual;
}

error_log("💾 Foto final a guardar en BD: " . $foto);

// Actualizar según el tipo de animal
switch($tipo) {
    case 'perro':
        // Probar diferentes nombres de métodos
        if (method_exists($perrosBD, 'actualizarPerro')) {
            $resultado = $perrosBD->actualizarPerro($id, $nombre, $raza, $edad, $sexo, $estado, $foto);
            error_log("🔧 Usando método: actualizarPerro");
        } elseif (method_exists($perrosBD, 'ActualizarPerro')) {
            $resultado = $perrosBD->ActualizarPerro($id, $nombre, $raza, $edad, $sexo, $estado, $foto);
            error_log("🔧 Usando método: ActualizarPerro");
        } else {
            error_log("❌ Método para actualizar perros no disponible");
            echo '{"success":false,"message":"Método para actualizar perros no disponible"}';
            exit;
        }
        break;
        
    case 'gato':
        if (method_exists($perrosBD, 'actualizarGato')) {
            $resultado = $perrosBD->actualizarGato($id, $nombre, $raza, $edad, $sexo, $estado, $foto);
            error_log("🔧 Usando método: actualizarGato");
        } elseif (method_exists($perrosBD, 'ActualizarGato')) {
            $resultado = $perrosBD->ActualizarGato($id, $nombre, $raza, $edad, $sexo, $estado, $foto);
            error_log("🔧 Usando método: ActualizarGato");
        } else {
            error_log("❌ Método para actualizar gatos no disponible");
            echo '{"success":false,"message":"Método para actualizar gatos no disponible"}';
            exit;
        }
        break;
        
    case 'otro':
        if (method_exists($perrosBD, 'actualizarOtro')) {
            $resultado = $perrosBD->actualizarOtro($id, $nombre, $raza, $edad, $sexo, $estado, $foto);
            error_log("🔧 Usando método: actualizarOtro");
        } elseif (method_exists($perrosBD, 'ActualizarOtro')) {
            $resultado = $perrosBD->ActualizarOtro($id, $nombre, $raza, $edad, $sexo, $estado, $foto);
            error_log("🔧 Usando método: ActualizarOtro");
        } else {
            error_log("❌ Método para actualizar otros animales no disponible");
            echo '{"success":false,"message":"Método para actualizar otros animales no disponible"}';
            exit;
        }
        break;
        
    default:
        error_log("❌ Tipo de animal no válido: " . $tipo);
        echo '{"success":false,"message":"Tipo de animal no válido"}';
        exit;
}

if ($resultado) {
    error_log("✅ Animal actualizado correctamente en BD");
    echo json_encode([
        'success' => true, 
        'message' => 'Animal actualizado correctamente',
        'datos' => [
            'id' => $id,
            'tipo' => $tipo,
            'nombre' => $nombre,
            'raza' => $raza,
            'edad' => $edad,
            'sexo' => $sexo,
            'estado' => $estado,
            'foto' => $foto
        ]
    ]);
} else {
    error_log("❌ Error al actualizar animal en BD");
    echo '{"success":false,"message":"Error al actualizar el animal en la base de datos"}';
}
?>