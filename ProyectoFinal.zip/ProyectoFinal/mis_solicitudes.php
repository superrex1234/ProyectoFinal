<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['ci'])) {
    header("Location: Formulario/FormularioLogin.php");
    exit;
}

include_once __DIR__ . "/Persistencia/perrosbd.php";
$animalesBD = new perrosbd();

// Obtener las solicitudes del usuario actual
$solicitudes = $animalesBD->ObtenerSolicitudesPorUsuario($_SESSION['ci']);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Solicitudes de Adopción</title>
    <link rel="stylesheet" href="./Estilos/mis_solicitudes.css">
    <link
        href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500&family=Roboto:wght@400;500&display=swap"
        rel="stylesheet">
</head>
<body>
    <header>
        <div class="header-container">
            <a href="index.php" class="logo">Patitas Unidas</a>
            <a href="index.php" class="btn-volver">← Volver al Inicio</a>
        </div>
    </header>

    <div class="container">
        <div class="header">
            <h1>Mis Solicitudes de Adopción</h1>
            <p>Revisa el estado de todas tus solicitudes</p>
        </div>

        <div class="content">
            <!-- Estadísticas -->
            <div class="stats">
                <div class="stat-card">
                    <h3><?= count($solicitudes) ?></h3>
                    <p>Total de Solicitudes</p>
                </div>
                <div class="stat-card">
                    <h3><?= count(array_filter($solicitudes, fn($s) => $s['estado'] === 'pendiente')) ?></h3>
                    <p>Pendientes</p>
                </div>
                <div class="stat-card">
                    <h3><?= count(array_filter($solicitudes, fn($s) => $s['estado'] === 'aprobada')) ?></h3>
                    <p>Aprobadas</p>
                </div>
                <div class="stat-card">
                    <h3><?= count(array_filter($solicitudes, fn($s) => $s['estado'] === 'rechazada')) ?></h3>
                    <p>Rechazadas</p>
                </div>
            </div>

            <!-- Lista de Solicitudes -->
            <div class="solicitudes-grid">
                <?php if (count($solicitudes) > 0): ?>
                    <?php foreach ($solicitudes as $solicitud): ?>
                        <div class="solicitud-card">
                            <div class="solicitud-header">
                                <div class="mascota-info">
                                    <?php if (!empty($solicitud['foto'])): ?>
                                        <img src="./Fotoss/<?= htmlspecialchars($solicitud['foto']) ?>" 
                                             alt="<?= htmlspecialchars($solicitud['mascota_nombre']) ?>" 
                                             class="mascota-img">
                                    <?php else: ?>
                                        <div class="mascota-img" style="background: #e2e8f0; display: flex; align-items: center; justify-content: center; color: #64748b;">
                                            🐾
                                        </div>
                                    <?php endif; ?>
                                    <div class="mascota-details">
                                        <h3><?= htmlspecialchars($solicitud['mascota_nombre']) ?></h3>
                                        <p><?= htmlspecialchars(ucfirst($solicitud['especie'])) ?> • <?= htmlspecialchars($solicitud['raza']) ?> • <?= htmlspecialchars($solicitud['edad']) ?></p>
                                    </div>
                                </div>
                                <span class="status-badge status-<?= $solicitud['estado'] ?>">
                                    <?= ucfirst($solicitud['estado']) ?>
                                </span>
                            </div>

                            <div class="solicitud-details">
                                <div class="detail-row">
                                    <span class="detail-label">Fecha de Solicitud:</span>
                                    <span><?= date('d/m/Y H:i', strtotime($solicitud['fecha_solicitud'])) ?></span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">Teléfono de Contacto:</span>
                                    <span><?= htmlspecialchars($solicitud['telefono']) ?></span>
                                </div>
                            </div>

                            <div class="razon-completa">
                                <strong>Mi mensaje:</strong>
                                <p><?= nl2br(htmlspecialchars($solicitud['razon'])) ?></p>
                            </div>

                            <?php if (!empty($solicitud['mensaje_admin'])): ?>
                                <div class="mensaje-admin">
                                    <strong>📨 Mensaje del administrador:</strong>
                                    <p><?= nl2br(htmlspecialchars($solicitud['mensaje_admin'])) ?></p>
                                    <?php if (!empty($solicitud['fecha_contacto'])): ?>
                                        <small class="fecha-mensaje">
                                            Enviado el: <?= date('d/m/Y H:i', strtotime($solicitud['fecha_contacto'])) ?>
                                        </small>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <h3>No tienes solicitudes de adopción</h3>
                        <p>Cuando hagas solicitudes de adopción, aparecerán aquí.</p>
                        <a href="index.php">
                            Ver Animales Disponibles
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>