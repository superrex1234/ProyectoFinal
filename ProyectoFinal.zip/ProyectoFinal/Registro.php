<?php
session_start();
// Verificar acceso de administrador
if ($_SESSION['tipo'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

include_once "./Persistencia/perrosbd.php";

$perrosBD = new perrosbd();
$registros = $perrosBD->MostrarRegistrosAdopciones();

// Procesar edición de adopción
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['editar_adopcion'])) {
    $id = $_POST['id'];
    $adoptado_por = $_POST['adoptado_por'];
    $telefono_adoptante = $_POST['telefono_adoptante'];
    
    if ($perrosBD->ActualizarInformacionAdopcion($id, $adoptado_por, $telefono_adoptante)) {
        $mensaje_exito = "Información de adopción actualizada correctamente";
        // Recargar los registros
        $registros = $perrosBD->MostrarRegistrosAdopciones();
    } else {
        $mensaje_error = "Error al actualizar la información";
    }
}

// Estadísticas
$totalAdopciones = count($registros);
$adopcionesEsteMes = 0;
$adopcionesEstaSemana = 0;
$mesActual = date('Y-m');
$semanaActual = date('Y-W');


?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./Estilos/Registros.css">
    <link rel="stylesheet" href="./Estilos/PanelMascotas.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <title>Registro de Adopciones - Patitas Unidas</title>
    <script src="./JavaScript/menu.js"></script>
</head>
<body>
    <!-- Header elegante -->
    <header class="admin-header">
        <div class="header-container">
            <div class="header-title">
                <h1>Panel de Administración</h1>
                <p class="subtitle">Registro de Adopciones</p>
            </div>
            
            <!-- Menú desplegable mejorado -->
            <div class="menu-desplegable">
                <button id="menuBtn" class="menu-toggle">
                    <span class="menu-icon">&#9776;</span>
                    <span class="menu-text">Menú</span>
                </button>
                <div id="menuContent" class="menu-content">
                    <div class="menu-header">
                        <h3>Menú Principal</h3>
                    </div>
                    <ul class="menu-list">
                        <li class="menu-item">
                            <a href="./index.php" class="menu-link">
                                <span class="menu-icon">🏠</span>
                                <span class="menu-text">Inicio</span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="./PanelAdmin.php" class="menu-link">
                                <span class="menu-icon">🐾</span>
                                <span class="menu-text">Animales</span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="./PanelAdminUsuario.php" class="menu-link">
                                <span class="menu-icon">👥</span>
                                <span class="menu-text">Usuarios</span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="./Solicitudes.php" class="menu-link">
                                <span class="menu-icon">📋</span>
                                <span class="menu-text">Solicitudes</span>
                            </a>
                        </li>
                        <li class="menu-divider"></li>
                        <li class="menu-item">
                            <a href="./Formulario/cerrar_sesion.php" class="menu-link logout">
                                <span class="menu-icon">🚪</span>
                                <span class="menu-text">Cerrar Sesión</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </header>

    <br>
    <br>

    <div class="admin-container">
        <!-- Mensajes de éxito/error -->
        <?php if (isset($mensaje_exito)): ?>
            <div class="mensaje-exito"><?= $mensaje_exito ?></div>
        <?php endif; ?>
        
        <?php if (isset($mensaje_error)): ?>
            <div class="mensaje-error"><?= $mensaje_error ?></div>
        <?php endif; ?>

        <!-- Panel de estadísticas -->
        <div class="stats-panel">
            
            
            <div class="stat-card">
                <div class="stat-icon success">✅</div>
                <div class="stat-info">
                    <h3><?= $totalAdopciones ?></h3>
                    <p>Completadas</p>
                </div>
            </div>
        </div>

        <main class="main-content">
            

            <?php if (empty($registros)): ?>
                <div class="empty-state">
                    <div class="empty-icon">🏠</div>
                    <h3>No hay adopciones registradas aún</h3>
                    <p>Cuando marques animales como adoptados, aparecerán aquí en el historial.</p>
                    <a href="./PanelAdmin.php" class="btn-primary">
                        <span class="btn-icon">🐾</span>
                        Gestionar Mascotas
                    </a>
                </div>
            <?php else: ?>
                <div class="registros-grid">
                    <?php foreach ($registros as $registro): 
                        $fechaAdopcion = new DateTime($registro['fecha_adopcion']);
                        $hoy = new DateTime();
                        $diferencia = $hoy->diff($fechaAdopcion);
                        $esReciente = $diferencia->days <= 7;
                    ?>
                    <div class="adopcion-card <?= $esReciente ? 'reciente' : '' ?>">
                        <div class="card-header">
                            <div class="mascota-info">
                                <div class="mascota-avatar">
                                    <?php if ($registro['foto']): ?>
                                        <img src="./Fotoss/<?= htmlspecialchars($registro['foto']) ?>" 
                                             alt="<?= htmlspecialchars($registro['nombre_mascota']) ?>" 
                                             class="mascota-img"
                                             onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAiIGhlaWdodD0iODAiIHZpZXdCb3g9IjAgMCA4MCA4MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjgwIiBoZWlnaHQ9IjgwIiByeD0iNDAiIGZpbGw9IiMzYTM1MzUiLz4KPHBhdGggZD0iTTQwIDQ0QzQ0LjQxODMgNDQgNDggNDAuNDE4MyA0OCAzNkM0OCAzMS41ODE3IDQ0LjQxODMgMjggNDAgMjhDMzUuNTgxNyAyOCAzMiAzMS41ODE3IDMyIDM2QzMyIDQwLjQxODMgMzUuNTgxNyA0NCA0MCA0NFoiIGZpbGw9IiM2ZDZmNzIiLz4KPHBhdGggZD0iTTU2IDU0QzU2IDQ5LjUxMDQgNDguODM0OCA0NiA0MCA0NkMzMS4xNjUyIDQ2IDI0IDQ5LjUxMDQgMjQgNTRWNjJDMjQgNjMuMTA0NiAyNC44OTU0IDY0IDI2IDY0SDU0QzU1LjEwNDYgNjQgNTYgNjMuMTA0NiA1NiA2MloiIGZpbGw9IiM2ZDZmNzIiLz4KPC9zdmc+'">
                                    <?php else: ?>
                                        <div class="mascota-placeholder">
                                            <?= $registro['especie'] === 'perro' ? '🐕' : ($registro['especie'] === 'gato' ? '🐈' : '🐾') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="mascota-details">
                                    <h3 class="mascota-nombre"><?= htmlspecialchars($registro['nombre_mascota']) ?></h3>
                                    <div class="mascota-meta">
                                        <span class="badge especie <?= htmlspecialchars($registro['especie']) ?>">
                                            <?= ucfirst($registro['especie']) ?>
                                        </span>
                                        <span class="badge sexo <?= htmlspecialchars($registro['sexo']) ?>">
                                            <?= ucfirst($registro['sexo']) ?>
                                        </span>
                                        <span class="badge edad">
                                            <?= htmlspecialchars($registro['edad']) ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="adopcion-meta">
                                <?php if ($esReciente): ?>
                                    <span class="badge nuevo">NUEVO</span>
                                <?php endif; ?>
                                <div class="fecha-adopcion">
                                    <span class="fecha"><?= date('d/m/Y', strtotime($registro['fecha_adopcion'])) ?></span>
                                    <span class="hora"><?= date('H:i', strtotime($registro['fecha_adopcion'])) ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="card-content">
                            <div class="info-grid">
                                <div class="info-item">
                                    <label>Raza:</label>
                                    <span><?= htmlspecialchars($registro['raza'] ?: 'No especificada') ?></span>
                                </div>
                                
                                <div class="info-item">
                                    <label>ID Mascota:</label>
                                    <span class="mascota-id">#<?= $registro['mascota_id'] ?></span>
                                </div>
                                
                                
                                    
                                
                                
                                
                            </div>
                        </div>

                        <div class="card-footer">
                            <div class="adopcion-status">
                                <span class="status-badge completada">
                                    <span class="status-icon">✅</span>
                                    Adopción Completada
                                </span>
                            </div>
                            <div class="card-actions">
                                
                                
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>