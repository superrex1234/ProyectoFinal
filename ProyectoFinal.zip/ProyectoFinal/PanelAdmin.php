<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['ci'])) {
    header("Location: index.php");
    exit;
}

// Verificar si el usuario es admin
if ($_SESSION['tipo'] !== 'admin') {
    header("Location: index.php");
    exit;
}

// Incluir dependencias
include_once "./Logica/Perros.php";
include_once "./Persistencia/perrosbd.php";
include_once "./Presentacion/funcionImagen.php";

$perrosBD = new perrosBD();

// PROCESAR FORMULARIO - ANTES de cualquier salida HTML
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nombre'])) {
    $nombre = $_POST['nombre'];
    $especie = $_POST['especie'];
    $raza = $_POST['raza'];
    $edad = $_POST['edad'];
    $sexo = $_POST['sexo'];
    
    // Procesar imagen
    $foto = null;
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $foto = CargarImagen($_FILES['foto']);
    }
    
    // Insertar en la base de datos según la especie
    $resultado = false;
    switch($especie) {
        case 'perro':
            $resultado = $perrosBD->AgregarPerro($nombre, $especie, $raza, $edad, $sexo, $foto);
            break;
        case 'gato':
            $resultado = $perrosBD->AgregarGato($nombre, $especie, $raza, $edad, $sexo, $foto);
            break;
        case 'otro':
            $resultado = $perrosBD->AgregarOtro($nombre, $especie, $raza, $edad, $sexo, $foto);
            break;
    }
    
    if ($resultado) {
        $_SESSION['alerta'] = [
            'tipo' => 'success',
            'mensaje' => 'Animal agregado correctamente'
        ];
    } else {
        $_SESSION['alerta'] = [
            'tipo' => 'error',
            'mensaje' => 'Error al agregar el animal'
        ];
    }
    
    // REDIRIGIR a la misma página para evitar reenvío
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Mostrar alerta si existe
if (isset($_SESSION['alerta'])) {
    $alerta = $_SESSION['alerta'];
    unset($_SESSION['alerta']); // Limpiar después de mostrar
}

// Obtener estadísticas
$listaPerros = $perrosBD->MostrarPerros();
$listaGatos = $perrosBD->MostrarGatos();
$listaOtros = $perrosBD->MostrarOtros();

$totalAnimales = count($listaPerros) + count($listaGatos) + count($listaOtros);
$animalesDisponibles = 0;
$animalesAdoptados = 0;

// Contar animales disponibles y adoptados
foreach ($listaPerros as $animal) {
    if ($animal->getEstadoPerro() === 'disponible') $animalesDisponibles++;
    else $animalesAdoptados++;
}
foreach ($listaGatos as $animal) {
    if ($animal->getEstadoGatos() === 'disponible') $animalesDisponibles++;
    else $animalesAdoptados++;
}
foreach ($listaOtros as $animal) {
    if ($animal->getEstadoOtros() === 'disponible') $animalesDisponibles++;
    else $animalesAdoptados++;
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./Estilos/PanelMascota.css"> 
    <link rel="stylesheet" href="./Estilos/modal-animales.css"> 
    
    <title>Panel Admin - Patitas Unidas</title>
    <script src="./JavaScript/menu.js"></script>
    <script src="JavaScript/mainAnimales.js?v=<?= time() ?>"></script>
</head>
<body>
    <!-- Header elegante -->
<header class="admin-header">
  <div class="header-container">
    <div class="header-title">
      <h1>Panel de Administración</h1>
      <p class="subtitle">Gestión de Animales</p>
    </div>

    <!-- Menú desplegable mejorado -->
    <div class="menu-desplegable">
      <button id="menuBtn" class="menu-toggle">
        <span class="menu-icon">&#9776;</span>
        <span class="menu-text">Menú</span>
      </button>

      <div id="menuContent" class="menu-content">
        <div class="menu-header">
          <h3>Menú Principal</h3>
        </div>
        <ul class="menu-list">
          <li class="menu-item">
            <a href="./index.php" class="menu-link">
              <span class="menu-icon">🏠</span>
              <span class="menu-text">Inicio</span>
            </a>
          </li>

          <li class="menu-item">
            <a href="./PanelAdminUsuario.php" class="menu-link">
              <span class="menu-icon">👥</span>
              <span class="menu-text">Usuarios</span>
            </a>
          </li>

          <li class="menu-item">
            <a href="./Solicitudes.php" class="menu-link">
              <span class="menu-icon">📋</span>
              <span class="menu-text">Solicitudes</span>
            </a>
          </li>

          <li class="menu-item">
              <a href="Registro.php" class="menu-link">
                <span class="menu-icon">🚪</span>
                <span class="menu-text">Registros de Adopciones</span>
              </a>
            </li>

          <li class="menu-divider"></li>
        </ul>
      </div>
    </div>
  </div>
</header>

    <div class="admin-container">
        <!-- Panel de estadísticas -->
        <div class="stats-panel">
            <div class="stat-card">
                <div class="stat-icon total">🐾</div>
                <div class="stat-info">
                    <h3><?= $totalAnimales ?></h3>
                    <p>Total Animales</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon available">✅</div>
                <div class="stat-info">
                    <h3><?= $animalesDisponibles ?></h3>
                    <p>Disponibles</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon adopted">🏠</div>
                <div class="stat-info">
                    <h3><?= $animalesAdoptados ?></h3>
                    <p>Adoptados</p>
                </div>
            </div>
        </div>

        <!-- Formulario para agregar animales -->
        <div class="form-section">
            <div class="section-header">
                <h2>Agregar Nuevo Animal</h2>
            </div>
            <form action="" method="POST" enctype="multipart/form-data" class="animal-form">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="nombre">Nombre</label>
                        <input type="text" id="nombre" name="nombre" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="especie">Especie</label>
                        <select id="especie" name="especie" required>
                            <option value="perro">Perro</option>
                            <option value="gato">Gato</option>
                            <option value="otro">Otro</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="raza">Raza</label>
                        <input type="text" id="raza" name="raza">
                    </div>
                    
                    <div class="form-group">
                        <label for="edad">Edad</label>
                        <input type="text" id="edad" name="edad" placeholder="Ej: 2 años">
                    </div>
                    
                    <div class="form-group">
                        <label for="sexo">Sexo</label>
                        <select id="sexo" name="sexo">
                            <option value="macho">Macho</option>
                            <option value="hembra">Hembra</option>
                        </select>
                    </div>
                    
                    <div class="form-group full-width">
                        <label for="foto">Foto del Animal</label>
                        <input type="file" id="foto" name="foto" accept="image/*">
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn-submit">
                        <span>➕ Agregar Animal</span>
                    </button>
                </div>
            </form>
        </div>

        <!-- Lista de Perros -->
        <div class="animals-section">
            <div class="section-header">
                <h2>🐕 Perros</h2>
                <span class="section-count"><?= count($listaPerros) ?> Perros Registrados</span>
            </div>
            
            <div class="table-container">
               <table id="tabla-perros" class="animals-table">
    <thead>
        <tr>
            <th class="photo-col">Foto</th>
            <th>Nombre</th>
            <th>Raza</th>
            <th>Edad</th>
            <th>Sexo</th>
            <th>Estado</th>
            <th class="actions-col">Cambiar Estado a</th>
            <th class="actions-col">Editar</th>
        </tr>
    </thead>
    <tbody>
    <?php if ($listaPerros && count($listaPerros) > 0): ?>
        <?php foreach ($listaPerros as $perro): ?>
            <tr>
                <td class="animal-photo">
                    <?php if ($perro->getFotoPerro()): ?>
                        <img src="./Fotoss/<?= htmlspecialchars($perro->getFotoPerro()); ?>" 
                             alt="Foto de <?= htmlspecialchars($perro->getNombrePerro()); ?>"
                             class="animal-img">
                    <?php else: ?>
                        <div class="photo-placeholder">🐕</div>
                    <?php endif; ?>
                </td>
                <td class="animal-name"><?= htmlspecialchars($perro->getNombrePerro()); ?></td>
                <td><?= htmlspecialchars($perro->getRazaPerro()); ?></td>
                <td><?= htmlspecialchars($perro->getEdadPerro()); ?></td>
                <td>
                    <span class="sex-badge <?= htmlspecialchars($perro->getSexoPerro()); ?>">
                        <?= htmlspecialchars($perro->getSexoPerro()); ?>
                    </span>
                </td>
                <td>
                    <span class="status-badge <?= htmlspecialchars($perro->getEstadoPerro()); ?>">
                        <?= htmlspecialchars($perro->getEstadoPerro()); ?>
                    </span>
                </td>
                <td class="animal-actions" data-tipo="acciones">
                    <?php if ($perro->getEstadoPerro() == "adoptado"): ?>
                        <button type="button" 
                                data-accion="btn-reincorporar-perros" 
                                data-id="<?= htmlspecialchars($perro->getIdPerro()); ?>" 
                                class="btn-admin btn-activar"
                                title="Marcar como disponible">
                            ✅ Disponible
                        </button>
                    <?php else: ?>
                        <button type="button" 
                                data-accion="btn-inhabilitar-perros" 
                                data-id="<?= htmlspecialchars($perro->getIdPerro()); ?>" 
                                class="btn-admin btn-inhabilitar"
                                title="Marcar como adoptado">
                            🏠 Adoptado
                        </button>
                    <?php endif; ?>
                </td>
                <td class="animal-actions">
                    <!-- Botón Editar (siempre visible) -->
                    <button type="button" 
                            class="btn-admin btn-editar"
                            data-id="<?= htmlspecialchars($perro->getIdPerro()); ?>"
                            data-tipo="perro"
                            data-nombre="<?= htmlspecialchars($perro->getNombrePerro()); ?>"
                            data-raza="<?= htmlspecialchars($perro->getRazaPerro()); ?>"
                            data-edad="<?= htmlspecialchars($perro->getEdadPerro()); ?>"
                            data-sexo="<?= htmlspecialchars($perro->getSexoPerro()); ?>"
                            data-estado="<?= htmlspecialchars($perro->getEstadoPerro()); ?>"
                            data-foto="<?= htmlspecialchars($perro->getFotoPerro()); ?>"
                            title="Editar animal">
                        ✏️ Editar
                    </button>
                </td>
            </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr class="no-data">
            <td colspan="8">
                <div class="empty-state">
                    <div class="empty-icon">🐕</div>
                    <h3>No hay perros registrados</h3>
                    <p>Agrega el primer perro usando el formulario superior.</p>
                </div>
            </td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
            </div>
        </div>

        <!-- Lista de Gatos -->
        <div class="animals-section">
            <div class="section-header">
                <h2>🐈 Gatos</h2>
                <span class="section-count"><?= count($listaGatos) ?> Gatos Registrados</span>
            </div>
            
            <div class="table-container">
               <table id="tabla-gatos" class="animals-table">
    <thead>
        <tr>
            <th class="photo-col">Foto</th>
            <th>Nombre</th>
            <th>Raza</th>
            <th>Edad</th>
            <th>Sexo</th>
            <th>Estado</th>
            <th class="actions-col">Cambiar Estado a</th>
            <th class="actions-col">Editar</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($listaGatos)): ?>
            <?php foreach ($listaGatos as $gatos): ?>
                <tr>
                    <td class="animal-photo">
                        <?php if ($gatos->getFotoGatos()): ?>
                            <img src="./Fotoss/<?= htmlspecialchars($gatos->getFotoGatos()); ?>" 
                                 alt="Foto de <?= htmlspecialchars($gatos->getNombreGatos()); ?>"
                                 class="animal-img">
                        <?php else: ?>
                            <div class="photo-placeholder">🐈</div>
                        <?php endif; ?>
                    </td>
                    <td class="animal-name"><?= htmlspecialchars($gatos->getNombreGatos()); ?></td>
                    <td><?= htmlspecialchars($gatos->getRazaGatos()); ?></td>
                    <td><?= htmlspecialchars($gatos->getEdadGatos()); ?></td>
                    <td>
                        <span class="sex-badge <?= htmlspecialchars($gatos->getSexoGatos()); ?>">
                            <?= htmlspecialchars($gatos->getSexoGatos()); ?>
                        </span>
                    </td>
                    <td>
                        <span class="status-badge <?= htmlspecialchars($gatos->getEstadoGatos()); ?>">
                            <?= htmlspecialchars($gatos->getEstadoGatos()); ?>
                        </span>
                    </td>
                    <td class="animal-actions">
                        <?php if ($gatos->getEstadoGatos() == "adoptado"): ?>
                            <button type="button" 
                                    data-accion="btn-reincorporar-gato" 
                                    data-id="<?= htmlspecialchars($gatos->getIdGatos()); ?>" 
                                    class="btn-admin btn-activar"
                                    title="Marcar como disponible">
                                ✅ Disponible
                            </button>
                        <?php else: ?>
                            <button type="button" 
                                    data-accion="btn-inhabilitar-gato" 
                                    data-id="<?= htmlspecialchars($gatos->getIdGatos()); ?>" 
                                    class="btn-admin btn-inhabilitar"
                                    title="Marcar como adoptado">
                                🏠 Adoptado
                            </button>
                        <?php endif; ?>
                    </td>
                    <td class="animal-actions">
                        <!-- Botón Editar -->
                        <button type="button" 
                                class="btn-admin btn-editar"
                                data-id="<?= htmlspecialchars($gatos->getIdGatos()); ?>"
                                data-tipo="gato"
                                data-nombre="<?= htmlspecialchars($gatos->getNombreGatos()); ?>"
                                data-raza="<?= htmlspecialchars($gatos->getRazaGatos()); ?>"
                                data-edad="<?= htmlspecialchars($gatos->getEdadGatos()); ?>"
                                data-sexo="<?= htmlspecialchars($gatos->getSexoGatos()); ?>"
                                data-estado="<?= htmlspecialchars($gatos->getEstadoGatos()); ?>"
                                data-foto="<?= htmlspecialchars($gatos->getFotoGatos()); ?>"
                                title="Editar animal">
                            ✏️ Editar
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr class="no-data">
                <td colspan="8">
                    <div class="empty-state">
                        <div class="empty-icon">🐈</div>
                        <h3>No hay gatos registrados</h3>
                        <p>Agrega el primer gato usando el formulario superior.</p>
                    </div>
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
            </div>
        </div>

        <!-- Lista de Otros Animales -->
        <div class="animals-section">
            <div class="section-header">
                <h2>🐾 Otros Animales</h2>
                <span class="section-count"><?= count($listaOtros) ?> Otros Animales Registrados</span>
            </div>
            
            <div class="table-container">
                <table id="tabla-otros" class="animals-table">
    <thead>
        <tr>
            <th class="photo-col">Foto</th>
            <th>Nombre</th>
            <th>Raza</th>
            <th>Edad</th>
            <th>Sexo</th>
            <th>Estado</th>
            <th class="actions-col">Cambiar Estado a</th>
            <th class="actions-col">Editar</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($listaOtros && count($listaOtros) > 0): ?>
            <?php foreach ($listaOtros as $otro): ?>
                <tr>
                    <td class="animal-photo">
                        <?php if ($otro->getFotoOtros()): ?>
                            <img src="./Fotoss/<?= htmlspecialchars($otro->getFotoOtros()); ?>" 
                                 alt="Foto de <?= htmlspecialchars($otro->getNombreOtros()); ?>"
                                 class="animal-img">
                        <?php else: ?>
                            <div class="photo-placeholder">🐾</div>
                        <?php endif; ?>
                    </td>
                    <td class="animal-name"><?= htmlspecialchars($otro->getNombreOtros()); ?></td>
                    <td><?= htmlspecialchars($otro->getRazaOtros()); ?></td>
                    <td><?= htmlspecialchars($otro->getEdadOtros()); ?></td>
                    <td>
                        <span class="sex-badge <?= htmlspecialchars($otro->getSexoOtros()); ?>">
                            <?= htmlspecialchars($otro->getSexoOtros()); ?>
                        </span>
                    </td>
                    <td>
                        <span class="status-badge <?= htmlspecialchars($otro->getEstadoOtros()); ?>">
                            <?= htmlspecialchars($otro->getEstadoOtros()); ?>
                        </span>
                    </td>
                    <td class="animal-actions">
                        <?php if ($otro->getEstadoOtros() == "adoptado"): ?>
                            <button type="button" 
                                    data-accion="btn-reincorporar-otros" 
                                    data-id="<?= htmlspecialchars($otro->getIdOtros()); ?>" 
                                    class="btn-admin btn-activar"
                                    title="Marcar como disponible">
                                ✅ Disponible
                            </button>
                        <?php else: ?>
                            <button type="button" 
                                    data-accion="btn-inhabilitar-otros" 
                                    data-id="<?= htmlspecialchars($otro->getIdOtros()); ?>" 
                                    class="btn-admin btn-inhabilitar"
                                    title="Marcar como adoptado">
                                🏠 Adoptado
                            </button>
                        <?php endif; ?>
                    </td>
                    <td class="animal-actions">
                        <!-- Botón Editar -->
                        <button type="button" 
                                class="btn-admin btn-editar"
                                data-id="<?= htmlspecialchars($otro->getIdOtros()); ?>"
                                data-tipo="otro"
                                data-nombre="<?= htmlspecialchars($otro->getNombreOtros()); ?>"
                                data-raza="<?= htmlspecialchars($otro->getRazaOtros()); ?>"
                                data-edad="<?= htmlspecialchars($otro->getEdadOtros()); ?>"
                                data-sexo="<?= htmlspecialchars($otro->getSexoOtros()); ?>"
                                data-estado="<?= htmlspecialchars($otro->getEstadoOtros()); ?>"
                                data-foto="<?= htmlspecialchars($otro->getFotoOtros()); ?>"
                                title="Editar animal">
                            ✏️ Editar
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr class="no-data">
                <td colspan="8">
                    <div class="empty-state">
                        <div class="empty-icon">🐾</div>
                        <h3>No hay otros animales</h3>
                        <p>Agrega otros animales usando el formulario superior.</p>
                    </div>
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
            </div>
        </div>
    </div>

    <!-- MODAL MEJORADO -->
    <div id="modalEditarAnimal" class="modal-animal">
        <div class="modal-animal-content">
            <div class="modal-animal-header">
                <div class="modal-animal-title">
                    <i class="modal-icon">✏️</i>
                    <h3>Editar Animal</h3>
                </div>
                <button type="button" class="modal-animal-close">&times;</button>
            </div>
            
            <form id="formEditarAnimal" class="modal-animal-form" enctype="multipart/form-data">
                <input type="hidden" name="id" id="edit_animal_id">
                <input type="hidden" name="tipo" id="edit_animal_tipo">
                <input type="hidden" name="foto_actual" id="edit_foto_actual">
                
                <div class="modal-animal-body">
                    <div class="form-grid-modal">
                        <div class="form-group-modal">
                            <label for="edit_nombre" class="form-label-modal">
                                
                                Nombre *
                            </label>
                            <input type="text" id="edit_nombre" name="nombre" class="form-input-modal" required>
                        </div>
                        
                        <div class="form-group-modal">
                            <label for="edit_especie" class="form-label-modal">
                                Especie *
                            </label>
                            <select id="edit_especie" name="especie" class="form-select-modal" required>
                                <option value="perro">Perro</option>
                                <option value="gato">Gato</option>
                                <option value="otro">Otro</option>
                            </select>
                        </div>
                        
                        <div class="form-group-modal">
                            <label for="edit_raza" class="form-label-modal">
                                Raza
                            </label>
                            <input type="text" id="edit_raza" name="raza" class="form-input-modal">
                        </div>
                        
                        <div class="form-group-modal">
                            <label for="edit_edad" class="form-label-modal">
                                Edad
                            </label>
                            <input type="text" id="edit_edad" name="edad" class="form-input-modal" placeholder="Ej: 2 años">
                        </div>
                        
                        <div class="form-group-modal">
                            <label for="edit_sexo" class="form-label-modal">
                                Sexo
                            </label>
                            <select id="edit_sexo" name="sexo" class="form-select-modal">
                                <option value="macho">Macho</option>
                                <option value="hembra">Hembra</option>
                            </select>
                        </div>
                        
                        <div class="form-group-modal">
                            <label for="edit_estado" class="form-label-modal">
                                Estado
                            </label>
                            <select id="edit_estado" name="estado" class="form-select-modal">
                                <option value="disponible">Disponible</option>
                                <option value="adoptado">Adoptado</option>
                            </select>
                        </div>
                        
                        <div class="form-group-modal full-width">
                            <label for="edit_foto" class="form-label-modal">
                                Foto del Animal
                            </label>
                            <div class="file-upload-container">
                                <input type="file" id="edit_foto" name="foto" class="file-input-modal" accept="image/*">
                                <label for="edit_foto" class="file-upload-label">
                                    <span>Seleccionar archivo</span>
                                </label>
                            </div>
                            <div class="foto-actual-modal">
                                <div class="foto-actual-header">
                                    <span>Foto actual:</span>
                                </div>
                                <div class="foto-preview-container">
                                    <img id="preview_foto_actual" src="" alt="Foto actual" class="foto-preview">
                                    <span id="texto_foto_actual" class="foto-texto">No hay foto disponible</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="modal-animal-footer">
                    <button type="button" class="btn-modal btn-modal-secondary" id="btnCancelar">
                        <i class="btn-icon">❌</i>
                        Cancelar
                    </button>
                    <button type="submit" class="btn-modal btn-modal-primary" id="btnGuardar">
                        <i class="btn-icon">💾</i>
                        <span class="btn-text">Guardar Cambios</span>
                        <div class="loading-spinner" style="display: none;"></div>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script src="JavaScript/modal-animales.js?v=<?= time() ?>"></script>
</body>
</html>