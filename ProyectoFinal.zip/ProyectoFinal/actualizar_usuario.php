<?php
session_start();

// Verificar permisos de administrador
if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Acceso no autorizado']);
    exit;
}

// Incluir dependencias
include_once "./Logica/Usuarios.php";
include_once "./Persistencia/usuariosbd.php";
include_once "./Presentacion/funcionImagen.php";

header('Content-Type: application/json');

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido');
    }

    // Obtener datos del formulario
    $ci = $_POST['ci'] ?? null;
    $nombre = $_POST['nombre'] ?? null;
    $email = $_POST['email'] ?? null;
    $telefono = $_POST['telefono'] ?? null;
    $tipo = $_POST['tipo'] ?? null;
    $estado = $_POST['estado'] ?? null;
    $password = $_POST['password'] ?? null;

    // Validar campos obligatorios
    if (!$ci || !$nombre || !$email) {
        throw new Exception('Datos incompletos');
    }

    // Procesar archivo de foto si se subió
    $foto = null;
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $foto = CargarImagenUsuario($_FILES['foto']);
        if (!$foto) {
            throw new Exception('Error al procesar la imagen');
        }
    }

    if ($foto) {
    error_log("Foto guardada: " . $foto);
    error_log("Ruta destino: " . "./Formulario/Fotoss/" . $foto);
    error_log("¿Existe archivo?: " . (file_exists("./Formulario/Fotoss/" . $foto) ? "Sí" : "No"));
}

    // Actualizar usuario en la base de datos
    $usuarioBD = new UsuarioBD();
    
    // Primero obtener el usuario actual para saber el email actual
    $usuarios = $usuarioBD->MostrarUsuarios();
    $email_actual = null;
    
    foreach ($usuarios as $usuario) {
        if ($usuario->getCi() == $ci) {
            $email_actual = $usuario->getEmail();
            break;
        }
    }
    
    if (!$email_actual) {
        throw new Exception('Usuario no encontrado');
    }

    // Actualizar usuario
    $success = $usuarioBD->ActualizarUsuarioConFoto(
        $email_actual,
        $nombre,
        $telefono,
        $password ?: null,
        $foto ?: null,
        $email,
        $tipo,
        $estado
    );

    if ($success) {
        // Obtener datos actualizados del usuario
        $usuarioActualizado = $usuarioBD->ObtenerUsuarioPorCorreo($email);
        
        echo json_encode([
            'success' => true,
            'message' => 'Usuario actualizado correctamente',
            'datos' => [
                'ci' => $ci,
                'nombre' => $nombre,
                'email' => $email,
                'telefono' => $telefono,
                'tipo' => $tipo,
                'estado' => $estado,
                'foto' => $foto ?: ($usuarioActualizado ? $usuarioActualizado->getFoto() : null)
            ]
        ]);
    } else {
        throw new Exception('Error al actualizar el usuario en la base de datos');
    }

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>