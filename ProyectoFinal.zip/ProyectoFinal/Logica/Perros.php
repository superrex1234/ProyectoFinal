<?php
class Perros
{

    //Perros//
    private $IdPerro;
    private $NombrePerro;
    private $Especie;
    private $Raza;
    private $EdadPerro;
    private $SexoPerro;
    private $FotoPerro;
    private $EstadoPerro;
    private $CaracteristicasPerros;
    //otros//
    private $IdOtros;
    private $NombreOtros;
    private $EspecieOtros;
    private $RazaOtros;
    private $EdadOtros;
    private $SexoOtros;
    private $FotoOtros;
    private $EstadoOtros;
    private $CaracteristicasOtros;
    //Gatos//
    private $IdGatos;
    private $NombreGatos;
    private $EspecieGatos;
    private $RazaGatos;
    private $EdadGatos;
    private $SexoGatos;
    private $FotoGatos;
    private $EstadoGatos;
    private $CaracteristicasGatos;
    //Gatos//
    public function getIdGatos()
    {
        return $this->IdGatos;
    }
    public function setIdGatos($IdGatos)
    {
        $this->IdGatos = $IdGatos;
    }

    public function getNombreGatos()
    {
        return $this->NombreGatos;
    }
    public function setNombreGatos($NombreGatos)
    {
        $this->NombreGatos = $NombreGatos;
    }

    public function getEspecieGatos()
    {
        return $this->EspecieGatos;
    }
    public function setEspecieGatos($EspecieGatos)
    {
        $this->EspecieGatos = $EspecieGatos;
    }

    public function getRazaGatos()
    {
        return $this->RazaGatos;
    }
    public function setRazaGatos($RazaGatos)
    {
        $this->RazaGatos = $RazaGatos;
    }

    public function getEdadGatos()
    {
        return $this->EdadGatos;
    }
    public function setEdadGatos($EdadGatos)
    {
        $this->EdadGatos = $EdadGatos;
    }

    public function getSexoGatos()
    {
        return $this->SexoGatos;
    }
    public function setSexoGatos($SexoGatos)
    {
        $this->SexoGatos = $SexoGatos;
    }

    public function getFotoGatos()
    {
        return $this->FotoGatos;
    }
    public function setFotoGatos($FotoGatos)
    {
        $this->FotoGatos = $FotoGatos;
    }

    public function getEstadoGatos()
    {
        return $this->EstadoGatos;
    }
    public function setEstadoGatos($EstadoGatos)
    {
        $this->EstadoGatos = $EstadoGatos;
    }
public function getCaracteristicasGatos()
{
    return $this->CaracteristicasGatos;
}
public function setCaracteristicasGatos($CaracteristicasGatos)
{
    $this->CaracteristicasGatos = $CaracteristicasGatos;
}

    //Perros//
    public function getIdPerro()
    {
        return $this->IdPerro;
    }
    public function setIdPerro($IdPerro)
    {
        $this->IdPerro = $IdPerro;
    }

    public function getNombrePerro()
    {
        return $this->NombrePerro;
    }
    public function setNombrePerro($NombrePerro)
    {
        $this->NombrePerro = $NombrePerro;
    }

    public function getEspeciePerro()
    {
        return $this->Especie;
    }
    public function setEspeciePerro($Especie)
    {
        $this->Especie = $Especie;
    }

    public function getRazaPerro()
    {
        return $this->Raza;
    }
    public function setRazaPerro($Raza)
    {
        $this->Raza = $Raza;
    }

    public function getEdadPerro()
    {
        return $this->EdadPerro;
    }
    public function setEdadPerro($EdadPerro)
    {
        $this->EdadPerro = $EdadPerro;
    }

    public function getSexoPerro()
    {
        return $this->SexoPerro;
    }
    public function setSexoPerro($SexoPerro)
    {
        $this->SexoPerro = $SexoPerro;
    }

    public function getFotoPerro()
    {
        return $this->FotoPerro;
    }
    public function setFotoPerro($FotoPerro)
    {
        $this->FotoPerro = $FotoPerro;
    }

    public function getEstadoPerro()
    {
        return $this->EstadoPerro;
    }
    public function setEstadoPerro($EstadoPerro)
    {
        $this->EstadoPerro = $EstadoPerro;
    }

    public function getCaracteristicasPerros()
    {
        return $this->CaracteristicasPerros;
    }
    public function setCaracteristicasPerros($CaracteristicasPerros)
    {
        $this->CaracteristicasPerros = $CaracteristicasPerros;
    }
//Perros

    // Otros

    public function getIdOtros()
    {
        return $this->IdOtros;
    }
    public function setIdOtros($IdOtros)
    {
        $this->IdOtros = $IdOtros;
    }

    public function getNombreOtros()
    {
        return $this->NombreOtros;
    }
    public function setNombreOtros($NombreOtros)
    {
        $this->NombreOtros = $NombreOtros;
    }
    public function getEspecieOtros()
    {
        return $this->EspecieOtros;
    }
    public function setEspecieOtros($EspecieOtros)
    {
        $this->EspecieOtros = $EspecieOtros;
    }
    public function getRazaOtros()
    {
        return $this->RazaOtros;
    }
    public function setRazaOtros($RazaOtros)
    {
        $this->RazaOtros = $RazaOtros;
    }
    public function getEdadOtros()
    {
        return $this->EdadOtros;
    }
    public function setEdadOtros($EdadOtros)
    {
        $this->EdadOtros = $EdadOtros;
    }
    public function getSexoOtros()
    {
        return $this->SexoOtros;
    }
    public function setSexoOtros($SexoOtros)
    {
        $this->SexoOtros = $SexoOtros;
    }
    public function getFotoOtros()
    {
        return $this->FotoOtros;
    }
    public function setFotoOtros($FotoOtros)
    {
        $this->FotoOtros = $FotoOtros;
    }
    public function getEstadoOtros()
    {
        return $this->EstadoOtros;
    }
    public function setEstadoOtros($EstadoOtros)
    {
        $this->EstadoOtros = $EstadoOtros;
    }
    public function getCaracteristicasOtros()
    {
        return $this->CaracteristicasOtros;
    }
    public function setCaracteristicasOtros($CaracteristicasOtros)
    {
        $this->CaracteristicasOtros = $CaracteristicasOtros;
    }


    // MÉTODOS PARA INTERACTUAR CON LA BD
    public function AgregarPerro()
    {
        include_once "../Persistencia/perrosbd.php";
        $perrosBD = new perrosBD();
        return $perrosBD->AgregarPerro(
            $this->NombrePerro,
            $this->Especie,
            $this->Raza,
            $this->EdadPerro,
            $this->SexoPerro,
            $this->FotoPerro
        );
    }

    public function MostrarPerros()
    {
        include_once "../Persistencia/perrosbd.php";
        $perrosBD = new perrosBD();
        return $perrosBD->MostrarPerros();
    }



    //Perros//
    public function AgregarGatos()
    {
        include_once "../Persistencia/perrosbd.php";
        $perrosBD = new perrosBD();
        return $perrosBD->AgregarGato(
            $this->NombreGatos,
            $this->EspecieGatos,
            $this->RazaGatos,
            $this->EdadGatos,
            $this->SexoGatos,
            $this->FotoGatos
        );
    }

    public function MostrarGatos()
    {
        include_once "../Persistencia/perrosbd.php";
        $gatosBD = new perrosBD();
        return $gatosBD->MostrarGatos();
    }

    public function MostrarOtros() {
        include_once "../Persistencia/perrosbd.php";
        $otrosBD = new perrosBD();
        return $otrosBD->MostrarOtros();
    }

    public function CambiarEstadoAnimales($id) {
    include_once __DIR__ . "/../Persistencia/perrosbd.php";
    $perrosbd = new perrosBD();
    return $perrosbd->CambiarEstadoAnimales($id, 'adoptado');  // Usa el método de BD con estado
}

public function CambiarEstadoActivoAnimales($id) {
    include_once __DIR__ . "/../Persistencia/perrosbd.php";
    $perrosbd = new perrosBD();
    return $perrosbd->CambiarEstadoActivoAnimales($id, 'disponible');  // Usa el método de BD con estado
}


// Método para obtener mascota por ID
public function ObtenerMascotaPorId($id) {
    include_once "../Persistencia/perrosbd.php";
    $perrosBD = new perrosBD();
    return $perrosBD->ObtenerMascotaPorId($id);
}


// En Perros.php - AGREGAR ESTOS MÉTODOS

public function ActualizarInfoPerros($IdPerro, $NombrePerro, $RazaPerro, $EdadPerro, $SexoPerro, $CaracteristicasPerros, $FotoPerro = null) {
    include_once "../Persistencia/perrosbd.php";
    $perrosBD = new perrosBD();
    return $perrosBD->ActualizarInfoPerros($IdPerro, $NombrePerro, $RazaPerro, $EdadPerro, $SexoPerro, $CaracteristicasPerros, $FotoPerro);
}

public function ActualizarInfoGatos($IdGatos, $NombreGatos, $RazaGatos, $EdadGatos, $SexoGatos, $CaracteristicasGatos, $FotoGatos = null) {
    include_once "../Persistencia/perrosbd.php";
    $perrosBD = new perrosBD();
    return $perrosBD->ActualizarInfoGatos($IdGatos, $NombreGatos, $RazaGatos, $EdadGatos, $SexoGatos, $CaracteristicasGatos, $FotoGatos);
}

public function ActualizarInfoOtros($IdOtros, $NombreOtros, $RazaOtros, $EdadOtros, $SexoOtros, $CaracteristicasOtros, $FotoOtros = null) {
    include_once "../Persistencia/perrosbd.php";
    $perrosBD = new perrosBD();
    return $perrosBD->ActualizarInfoOtros($IdOtros, $NombreOtros, $RazaOtros, $EdadOtros, $SexoOtros, $CaracteristicasOtros, $FotoOtros);
}



}