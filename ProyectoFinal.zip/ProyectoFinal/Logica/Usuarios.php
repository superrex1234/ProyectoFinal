<?php
class Usuarios
{
    private $ci;
    private $nombre;
    private $email;
    private $password;
    private $tipo;
    private $telefono;
    private $Foto;
    private $estado;

    public function getCi()
    {
        return $this->ci;
    }
    public function setCi($ci)
    {
        $this->ci = $ci;
    }

    public function getNombre()
    {
        return $this->nombre;
    }
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
    }

    public function getEmail()
    {
        return $this->email;
    }
    public function setEmail($email)
    {
        $this->email = $email;
    }

    public function getPassword()
    {
        return $this->password;
    }
    public function setPassword($password)
    {
        $this->password = $password;
    }

    public function getTipo()
    {
        return $this->tipo;
    }
    public function setTipo($tipo)
    {
        $this->tipo = $tipo;
    }

    public function getTelefono()
    {
        return $this->telefono;
    }
    public function setTelefono($telefono)
    {
        $this->telefono = $telefono;
    }

    public function getFoto()
    {
        return $this->Foto;
    }
    public function setFoto($Foto)
    {
        $this->Foto = $Foto;
    }

    public function getEstado()
    {
        return $this->estado;
    }
    public function setEstado($estado)
    {
        $this->estado = $estado;
    }

    public function Login()
    {
        include_once "../Persistencia/usuariosbd.php";
        $usuariobd = new UsuarioBD();
        return $usuariobd->Login($this->ci, $this->password);
    }

    public function Registro()
    {
        include_once "../Persistencia/usuariosbd.php";
        $usuariobd = new UsuarioBD();
        return $usuariobd->Registro($this->ci, $this->nombre, $this->email, $this->telefono, $this->password);
    }

    
public function CambiarEstado() {
    include_once __DIR__ . "/../Persistencia/usuariosbd.php";
    $usuariobd = new UsuarioBD();
    return $usuariobd->CambiarEstado($this->ci); // Usa $this->ci
}

public function CambiarEstadoActivo() {
    include_once __DIR__ . "/../Persistencia/usuariosbd.php";
    $usuariobd = new UsuarioBD();
    return $usuariobd->CambiarEstadoActivo($this->ci); // Usa $this->ci
}

}

