<?php
session_start();
include_once "../Persistencia/usuariosbd.php";
include_once "../Presentacion/funcionImagen.php";

if (!isset($_SESSION['correo'])) {
    header("Location: ./FormularioLogin.php");
    exit;
}

$correo_usuario = $_SESSION['correo'];
$usuarioBD = new UsuarioBD();
$usuario = $usuarioBD->ObtenerUsuarioPorCorreo($correo_usuario);

$mensaje = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'] ?? '';
    $telefono = $_POST['telefono'] ?? '';
    $nuevo_correo = $_POST['direccion'] ?? '';
    
    // Campos para cambio de contraseña (vienen del modal)
    $password_actual = $_POST['password_actual'] ?? '';
    $password_nueva = $_POST['password_nueva'] ?? '';
    $password_confirmar = $_POST['password_confirmar'] ?? '';
    $password = null;

    // Validaciones básicas
    if (empty($nombre) || empty($telefono) || empty($nuevo_correo)) {
        $error = "Nombre, teléfono y correo electrónico son obligatorios.";
    } elseif (strlen($telefono) > 9) {
        $error = "Error: El teléfono no puede tener más de 9 dígitos.";
    } else {
        // Verificar si el nuevo correo ya existe (solo si es diferente al actual)
        if ($nuevo_correo !== $correo_usuario) {
            $usuarioExistente = $usuarioBD->ObtenerUsuarioPorCorreo($nuevo_correo);
            if ($usuarioExistente) {
                $error = "El correo electrónico ya está en uso por otro usuario.";
            }
        }

        // Validar cambio de contraseña si se proporcionaron campos de contraseña
        $cambiarPassword = !empty($password_actual) || !empty($password_nueva) || !empty($password_confirmar);
        
        if ($cambiarPassword) {
            // Verificar que todos los campos de contraseña estén completos
            if (empty($password_actual) || empty($password_nueva) || empty($password_confirmar)) {
                $error = "Todos los campos de contraseña son obligatorios para cambiar la contraseña.";
            }
            // Verificar que la contraseña actual sea correcta
            elseif (!$usuarioBD->VerificarPassword($correo_usuario, $password_actual)) {
                $error = "La contraseña actual es incorrecta.";
            }
            // Verificar que las nuevas contraseñas coincidan
            elseif ($password_nueva !== $password_confirmar) {
                $error = "Las nuevas contraseñas no coinciden.";
            }
            // Verificar que la nueva contraseña sea diferente a la actual
            elseif ($password_nueva === $password_actual) {
                $error = "La nueva contraseña debe ser diferente a la actual.";
            }
            // Verificar longitud mínima
            elseif (strlen($password_nueva) < 6) {
                $error = "La nueva contraseña debe tener al menos 6 caracteres.";
            }
            // Si todas las validaciones son correctas, proceder con el cambio
            else {
                $password = $password_nueva;
            }
        }

        if (!$error) {
            // Subir foto si se proporcionó
            $foto = null;
            if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
                $foto = CargarImagen($_FILES['foto']);
                if (!$foto) {
                    $error = "Error al subir la imagen. Asegúrate de que sea un formato válido (JPG, PNG, GIF, WEBP).";
                }
            }

            if (!$error) {
                // Actualizar usuario
                $exito = $usuarioBD->ActualizarUsuarioConFoto($correo_usuario, $nombre, $telefono, $password, $foto, $nuevo_correo);
                
                if ($exito) {
                    $mensaje = "Perfil actualizado correctamente." . ($password ? " Contraseña cambiada correctamente." : "");
                    // Actualizar la sesión si el correo cambió
                    if ($nuevo_correo !== $correo_usuario) {
                        $_SESSION['correo'] = $nuevo_correo;
                        $correo_usuario = $nuevo_correo;
                    }
                    // Actualizar el objeto usuario con los nuevos datos
                    $usuario = $usuarioBD->ObtenerUsuarioPorCorreo($correo_usuario);
                } else {
                    $error = "Error al actualizar el perfil. Inténtalo de nuevo.";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Perfil - Patitas Unidas</title>
    <link rel="stylesheet" href="../Estilos/EditarPerfil.css">
</head>

<body>
    <header>
        <div class="header-top">
            <h1>Patitas Unidas</h1>
            <a href="PerfilUsuario.php" class="btn-volver">← Volver al Perfil</a>
        </div>
    </header>

    <main>
        <div class="perfil-container">
            <div class="avatar">
                <img src="../Formulario/Fotoss/<?= htmlspecialchars($usuario->getFoto() ?? 'default.png') ?>" alt="Avatar Usuario">
            </div>
            <h2>Editar Perfil</h2>

            <?php if ($mensaje): ?>
                <p class="mensaje-exito"><?= htmlspecialchars($mensaje) ?></p>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <p class="mensaje-error"><?= htmlspecialchars($error) ?></p>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" class="form-editar" id="formEditar">
                <label for="foto">Foto de perfil</label>
                <input type="file" id="foto" name="foto" accept="image/*">

                <label for="nombre">Nombre *</label>
                <input type="text" id="nombre" name="nombre" value="<?= htmlspecialchars($usuario->getNombre()) ?>"
                    required maxlength="30">
                
                <label for="telefono">Teléfono *</label>
                <input type="text" id="telefono" name="telefono"
                    value="<?= htmlspecialchars($usuario->getTelefono()) ?>" required maxlength="9"
                    pattern="[0-9]{8,9}" title="El teléfono debe tener 8 o 9 dígitos numéricos"
                    oninput="validarTelefono(this)">
                
                <label for="direccion">Correo Electrónico *</label>
                <input type="email" id="direccion" name="direccion"
                    value="<?= htmlspecialchars($usuario->getEmail()) ?>" required maxlength="25">

                <!-- Botón para abrir modal de cambio de contraseña -->
                <button type="button" class="btn-cambiar-password" id="btnAbrirModal">
                    🔒 Cambiar Contraseña
                </button>

                <input type="submit" value="Guardar Cambios" class="btn-editar" id="btnGuardar">
            </form>
        </div>
    </main>

    <!-- Modal para cambio de contraseña -->
    <div id="modalPassword" class="modal">
        <div class="modal-contenido">
            <button class="cerrar-modal" id="cerrarModal">&times;</button>
            <h3>Cambiar Contraseña</h3>
            
            <div class="password-container">
                <label for="modal_password_actual">Contraseña Actual</label>
                <input type="password" id="modal_password_actual" 
                       placeholder="Ingresa tu contraseña actual">
                <button type="button" class="toggle-password" data-target="modal_password_actual">👁️</button>
            </div>

            <div class="password-container">
                <label for="modal_password_nueva">Contraseña Nueva</label>
                <input type="password" id="modal_password_nueva" 
                       placeholder="Mínimo 6 caracteres" minlength="6">
                <button type="button" class="toggle-password" data-target="modal_password_nueva">👁️</button>
            </div>
            <div id="modal-password-strength" class="password-strength"></div>

            <div class="password-container">
                <label for="modal_password_confirmar">Repetir Contraseña Nueva</label>
                <input type="password" id="modal_password_confirmar" 
                       placeholder="Repite la nueva contraseña">
                <button type="button" class="toggle-password" data-target="modal_password_confirmar">👁️</button>
            </div>
            <div id="modal-password-match" class="password-match"></div>

            <div class="botones-modal">
                <button type="button" class="btn-modal secondary" id="btnCancelarModal">Cancelar</button>
                <button type="button" class="btn-modal primary" id="btnAplicarCambios">Aplicar Cambios</button>
            </div>
        </div>
    </div>

    <script>
        // Elementos del modal
        const modal = document.getElementById('modalPassword');
        const btnAbrirModal = document.getElementById('btnAbrirModal');
        const btnCerrarModal = document.getElementById('cerrarModal');
        const btnCancelarModal = document.getElementById('btnCancelarModal');
        const btnAplicarCambios = document.getElementById('btnAplicarCambios');

        // Funciones para abrir/cerrar modal
        btnAbrirModal.addEventListener('click', () => {
            modal.style.display = 'block';
            // Limpiar campos al abrir
            document.getElementById('modal_password_actual').value = '';
            document.getElementById('modal_password_nueva').value = '';
            document.getElementById('modal_password_confirmar').value = '';
            document.getElementById('modal-password-strength').textContent = '';
            document.getElementById('modal-password-match').textContent = '';
        });

        btnCerrarModal.addEventListener('click', () => {
            modal.style.display = 'none';
        });

        btnCancelarModal.addEventListener('click', () => {
            modal.style.display = 'none';
        });

        // Cerrar modal al hacer clic fuera del contenido
        window.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });

        // Aplicar cambios de contraseña
        btnAplicarCambios.addEventListener('click', () => {
            const passwordActual = document.getElementById('modal_password_actual').value;
            const passwordNueva = document.getElementById('modal_password_nueva').value;
            const passwordConfirmar = document.getElementById('modal_password_confirmar').value;

            // Validaciones
            if (!passwordActual || !passwordNueva || !passwordConfirmar) {
                mostrarMensaje('Todos los campos de contraseña son obligatorios.', 'error');
                return;
            }

            if (passwordNueva !== passwordConfirmar) {
                mostrarMensaje('Las nuevas contraseñas no coinciden.', 'error');
                return;
            }

            if (passwordNueva.length < 6) {
                mostrarMensaje('La nueva contraseña debe tener al menos 6 caracteres.', 'error');
                return;
            }

            // Crear campos ocultos en el formulario principal con los valores
            crearCampoOculto('password_actual', passwordActual);
            crearCampoOculto('password_nueva', passwordNueva);
            crearCampoOculto('password_confirmar', passwordConfirmar);

            // Cerrar modal y mostrar mensaje de éxito
            modal.style.display = 'none';
            mostrarMensaje('Contraseña configurada para cambiar. Guarda los cambios del perfil.', 'exito');
        });

        function crearCampoOculto(nombre, valor) {
            // Eliminar campo existente si existe
            const campoExistente = document.querySelector(`input[name="${nombre}"]`);
            if (campoExistente) {
                campoExistente.remove();
            }

            // Crear nuevo campo oculto
            const campoOculto = document.createElement('input');
            campoOculto.type = 'hidden';
            campoOculto.name = nombre;
            campoOculto.value = valor;
            document.getElementById('formEditar').appendChild(campoOculto);
        }

        // Validación de teléfono en edición
        function validarTelefono(input) {
            const valor = input.value.replace(/\D/g, ''); // Solo números
            input.value = valor; // Remover caracteres no numéricos
            
            if (valor.length > 9) {
                input.classList.add('input-error');
                return false;
            } else {
                input.classList.remove('input-error');
                return true;
            }
        }
        
        // Validación del formulario de edición
        document.getElementById('formEditar').addEventListener('submit', function(e) {
            const telefono = document.getElementById('telefono').value;
            
            if (telefono.length > 9) {
                e.preventDefault();
                mostrarMensaje('Error: El teléfono no puede tener más de 9 dígitos.', 'error');
                document.getElementById('telefono').focus();
                return false;
            }
            
            return true;
        });
        
        // Función para mostrar mensajes
        function mostrarMensaje(mensaje, tipo) {
            // Remover mensajes existentes
            const mensajesExistentes = document.querySelectorAll('.mensaje-dinamico');
            mensajesExistentes.forEach(msg => msg.remove());
            
            // Crear nuevo mensaje
            const divMensaje = document.createElement('div');
            divMensaje.className = `mensaje-${tipo} mensaje-dinamico`;
            divMensaje.style.cssText = 'padding: 10px; border-radius: 6px; text-align: center; margin-bottom: 20px;';
            divMensaje.style.background = tipo === 'error' ? '#c62828' : '#2e7d32';
            divMensaje.style.color = 'white';
            divMensaje.textContent = mensaje;
            
            // Insertar después del h2
            const h2 = document.querySelector('h2');
            h2.parentNode.insertBefore(divMensaje, h2.nextSibling);
            
            // Auto-remover después de 5 segundos
            setTimeout(() => {
                divMensaje.remove();
            }, 5000);
        }
        
        // Funcionalidad para mostrar/ocultar contraseña
        document.querySelectorAll('.toggle-password').forEach(button => {
            button.addEventListener('click', function() {
                const targetId = this.getAttribute('data-target');
                const passwordInput = document.getElementById(targetId);
                
                if (passwordInput.type === 'password') {
                    passwordInput.type = 'text';
                    this.textContent = '🙈';
                } else {
                    passwordInput.type = 'password';
                    this.textContent = '👁️';
                }
            });
        });

        // Validación de fortaleza de contraseña en el modal
        const modalPasswordNueva = document.getElementById('modal_password_nueva');
        const modalPasswordConfirmar = document.getElementById('modal_password_confirmar');
        const modalStrengthIndicator = document.getElementById('modal-password-strength');
        const modalMatchIndicator = document.getElementById('modal-password-match');

        modalPasswordNueva.addEventListener('input', function() {
            const password = this.value;
            let strength = 'weak';
            let message = 'Débil';
            
            if (password.length >= 6) {
                if (/[a-z]/.test(password) && /[A-Z]/.test(password) && /\d/.test(password) && /[^a-zA-Z\d]/.test(password)) {
                    strength = 'strong';
                    message = 'Fuerte';
                } else if ((/[a-z]/.test(password) || /[A-Z]/.test(password)) && /\d/.test(password)) {
                    strength = 'medium';
                    message = 'Media';
                }
            }
            
            modalStrengthIndicator.textContent = message;
            modalStrengthIndicator.className = 'password-strength ' + strength;
            
            // Verificar coincidencia
            checkModalPasswordMatch();
        });

        modalPasswordConfirmar.addEventListener('input', checkModalPasswordMatch);

        function checkModalPasswordMatch() {
            if (modalPasswordNueva.value && modalPasswordConfirmar.value) {
                if (modalPasswordNueva.value === modalPasswordConfirmar.value) {
                    modalMatchIndicator.textContent = '✓ Las contraseñas coinciden';
                    modalMatchIndicator.className = 'password-match valid';
                } else {
                    modalMatchIndicator.textContent = '✗ Las contraseñas no coinciden';
                    modalMatchIndicator.className = 'password-match invalid';
                }
            } else {
                modalMatchIndicator.textContent = '';
            }
        }
        
        // Inicializar validación
        document.addEventListener('DOMContentLoaded', function() {
            validarTelefono(document.getElementById('telefono'));
        });
    </script>
</body>
</html>