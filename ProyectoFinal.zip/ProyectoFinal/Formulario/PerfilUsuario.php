<?php
session_start();
include_once "../Persistencia/usuariosbd.php";

if (!isset($_SESSION['correo'])) {
    header("Location: ./FormularioLogin.php");
    exit;
}

// Verificar si el usuario está inactivo
if (isset($_SESSION['estado']) && $_SESSION['estado'] === 'inactivo') {
    session_destroy();
    header("Location: ./FormularioLogin.php?error=inactivo");
    exit;
}

$correo_usuario = $_SESSION['correo'];
$usuarioBD = new UsuarioBD();
$usuario = $usuarioBD->ObtenerUsuarioPorCorreo($correo_usuario);

$nombre_usuario = $usuario->getNombre();
$rol_usuario = $usuario->getTipo();
$telefono_usuario = $usuario->getTelefono();
$ci_usuario = $usuario->getCi();
$foto_usuario = $usuario->getFoto() ?? 'default.png';
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil - Patitas Unidas</title>
    <link rel="stylesheet" href="../Estilos/PerfilUsuario.css">
    
</head>

<body>
    <header class="navbar">
        <div class="navbar-container">
            <span class="logo">Patitas Unidas</span>
            <a href="../index.php" class="btn-volver">← Volver al Inicio</a>
        </div>
    </header>

    <main>
        <div class="perfil-container">
            <div class="avatar">
                <div class="avatar-border">
                    <img src="../Formulario/Fotoss/<?= htmlspecialchars($foto_usuario)  ?>" alt="Avatar Usuario" >
                    
                </div>
            </div>
            <h1><?= htmlspecialchars($nombre_usuario) ?></h1>
            <div class="perfil-info">
                <p><strong>Correo:</strong> <?= htmlspecialchars($correo_usuario) ?></p>
                <p><strong>Teléfono:</strong> <?= htmlspecialchars($telefono_usuario) ?></p>
                <p><strong>Cédula:</strong> <?= htmlspecialchars($ci_usuario) ?></p>
                <p><strong>Tpo de Usuario:</strong> <?= htmlspecialchars($rol_usuario) ?></p>
            </div>
            <a href="editarPerfil.php" class="btn-editar">Editar Perfil</a>
        </div>
    </main>
</body>

</html>