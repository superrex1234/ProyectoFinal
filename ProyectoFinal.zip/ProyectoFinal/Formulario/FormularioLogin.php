<?php
include_once "../Logica/Usuarios.php";
session_start();

$mensaje = '';
$tipoMensaje = '';

if (isset($_POST['enviar'])) {
    $usuario = new Usuarios();
    $usuario->setCi($_POST['ci']);
    $usuario->setPassword($_POST['password']);
    $u = $usuario->Login();

    if ($u != null) {
        // VERIFICAR ESTADO DEL USUARIO
        if ($u->getEstado() === 'inactivo') {
            $mensaje = "No se puede iniciar sesión <br>
            su cuenta está inactiva.";
            $tipoMensaje = "error";
        } else {
            // Guardar datos en sesión
            $_SESSION['ci'] = $u->getCi();
            $_SESSION['tipo'] = $u->getTipo(); // admin o adoptante
            $_SESSION['correo'] = $u->getEmail();
            $_SESSION['estado'] = $u->getEstado(); // Guardar estado en sesión

            // Redirigir según tipo
            if ($u->getTipo() === "admin") {
                header("Location: ../index.php"); 
                exit;
            } else {
                header("Location: ../index.php"); 
                exit;
            }
        }
    } else {
        $mensaje = "Usuario o contraseña incorrectos";
        $tipoMensaje = "error";
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <script src="../JavaScript/mostrarContra.js"></script>
    <link rel="stylesheet" href="../Estilos/estilos.css">
    <!-- SweetAlert2 para alertas bonitas -->
    
    <?php
// Mostrar alerta si viene por parámetro de error
if (isset($_GET['error']) && $_GET['error'] === 'inactivo') {
    echo '
    <script>
        Swal.fire({
            icon: "error",
            title: "Cuenta Inactiva",
            text: "Su cuenta está inactiva. Contacte al administrador.",
            confirmButtonText: "Entendido",
            confirmButtonColor: "#ffa200ff"
        });
    </script>
    ';
}
?>
</head>

<body class="body">
    <div class="container">
        <!-- Botón para volver al inicio -->
        <a href="../index.php" class="volver-btn">Volver</a>
        <h2>Iniciar Sesión</h2>

        <!-- Mensaje de error -->
        <?php if (!empty($mensaje)): ?>
            <div class="mensaje mensaje-<?php echo $tipoMensaje; ?>">
                <?php echo $mensaje; ?>
            </div>
            
            <script>
                // Mostrar alerta bonita con SweetAlert
                Swal.fire({
                    icon: '<?php echo $tipoMensaje === "error" ? "error" : "success"; ?>',
                    title: 'Error de inicio de sesión',
                    text: '<?php echo $mensaje; ?>',
                    confirmButtonText: 'Entendido',
                    confirmButtonColor: '#c5a46d'
                });
            </script>
        <?php endif; ?>

        <!-- Formulario de inicio de sesión -->
        <form method="POST" class="formulario">
            <div class="form-group">
                <label for="ci">Cédula</label>
                <input type="text" id="ci" name="ci" required   maxlength="8">
            </div>
            <div class="form-group">
                <label for="password">Contraseña</label>
                <div class="password-container">
                    <input type="password" id="password" name="password" required>
                    <button type="button" class="password-toggle" id="toggle-password">Mostrar</button>
                </div>
            </div>
            <button type="submit" name="enviar">Iniciar Sesión</button>
        </form>

        <!-- Enlace para registrarse si aún no tiene cuenta -->
        <p class="registro">
            ¿No tienes cuenta? <a href="./FormularioRegistro.php">Regístrate</a>
        </p>
    </div>

    <script>
        // Inicializar el botón de mostrar/ocultar contraseña
        document.addEventListener('DOMContentLoaded', function() {
            const toggleButton = document.getElementById('toggle-password');
            const passwordInput = document.getElementById('password');
            
            if (toggleButton && passwordInput) {
                toggleButton.addEventListener('click', function() {
                    if (passwordInput.type === 'password') {
                        passwordInput.type = 'text';
                        toggleButton.textContent = 'Ocultar';
                        toggleButton.classList.add('active');
                    } else {
                        passwordInput.type = 'password';
                        toggleButton.textContent = 'Mostrar';
                        toggleButton.classList.remove('active');
                    }
                });
            }
        });
    </script>
</body>

</html>