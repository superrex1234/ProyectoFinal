<?php
include_once "../Logica/Usuarios.php";

session_start();

$mensaje = '';
$tipoMensaje = '';

// Procesar el formulario
if (isset($_POST['btn'])) {
    $ci = $_POST['ci'];
    $telefono = $_POST['tel'];
    
    // Validaciones antes de procesar
    if (strlen($ci) > 8) {
        $mensaje = "Error: La cédula no puede tener más de 8 dígitos.";
        $tipoMensaje = "error";
    } elseif (strlen($telefono) > 9) {
        $mensaje = "Error: El teléfono no puede tener más de 9 dígitos.";
        $tipoMensaje = "error";
    } else {
        $usuario = new Usuarios();
        $usuario->setCi($ci);
        $usuario->setNombre($_POST['name']);
        $usuario->setEmail($_POST['email']);
        $usuario->setTelefono($telefono);
        $usuario->setPassword($_POST['password']);
        $usuario->setTipo('adoptante'); 

        if ($usuario->Registro()) {
            $_SESSION['correo'] = $usuario->getEmail();
            header("Location: ../Formulario/FormularioLogin.php");
            exit;
        } else {
            $mensaje = "Error: Las credenciales ingresadas (cédula, teléfono o correo electrónico) 
            ya están en uso o hubo un error.";
            $tipoMensaje = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrarse</title>
    <script src="../JavaScript/mostrarContra.js"></script>
    <link rel="stylesheet" href="../Estilos/estilos.css">
    <style>
        
        
        .caracteres-restantes {
            font-size: 0.8rem;
            color: #969595ff;
            margin-top: 5px;
        }
        
        .caracteres-excedidos {
            color: #c33;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="container">
        
        <a href="../index.php" class="volver-btn">Volver</a>

        <h2>Crear Cuenta</h2>
        
        <!-- Mensaje de error/éxito -->
        <?php if (!empty($mensaje)): ?>
            <div class="mensaje mensaje-<?php echo $tipoMensaje; ?>">
                <?php echo $mensaje; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" class="formulario" id="formRegistro">

 <div class="form-group">
                <label for="ci">Cédula *</label>
                <input type="text" id="ci" name="ci" required
                       maxlength="8" minlength="8">


            </div>

            <div class="form-group">
                <label for="name">Nombre *</label>
                <input type="text" id="name" name="name" required maxlength="25">
                
            </div>

            <div class="form-group">
                <label for="email">Correo Electrónico *</label>
                <input type="email" id="email" name="email" required maxlength="25">
                
            </div>

            <div class="form-group">
                <label for="tel">Teléfono *</label>
                <input type="text" id="tel" name="tel" required maxlength="9"
                       pattern="[0-9]{8,9}" title="El teléfono debe tener 8 o 9 dígitos numéricos"
                       oninput="validarTelefono(this)">
                
            </div>

            <div class="form-group">
                <label for="password">Contraseña *</label>
                <div class="password-container">
                    <input type="password" id="password" name="password" required minlength="6" maxlength="25">
                    <button type="button" class="password-toggle" id="toggle-password">Mostrar</button>
                </div>
                <div class="caracteres-restantes">Mínimo 6 caracteres</div>
            </div>

            <button type="submit" name="btn" id="btnRegistrar">Registrarse</button>
        </form>
        <p class="registro">
            ¿Ya tienes cuenta? <a href="FormularioLogin.php">Inicia Sesión</a>
        </p>
    </div>
    
    <script>
        // Validación de cédula
        function validarCedula(input) {
            const contador = document.getElementById('contador-ci');
            const valor = input.value.replace(/\D/g, ''); // Solo números
            input.value = valor; // Remover caracteres no numéricos
            
            if (valor.length > 8) {
                input.classList.add('input-error');
                contador.innerHTML = '<span class="caracteres-excedidos">❌ Máximo 8 dígitos</span>';
                return false;
            } 
        }
        
        // Validación de teléfono
        function validarTelefono(input) {
            const contador = document.getElementById('contador-tel');
            const valor = input.value.replace(/\D/g, ''); // Solo números
            input.value = valor; // Remover caracteres no numéricos
            
            if (valor.length > 9) {
                input.classList.add('input-error');
                contador.innerHTML = '<span class="caracteres-excedidos">❌ Máximo 9 dígitos</span>';
                return false;
            } else {
                input.classList.remove('input-error');
                contador.innerHTML = `${valor.length}/9 dígitos`;
                return true;
            }
        }
        
        // Validación del formulario completo
        document.getElementById('formRegistro').addEventListener('submit', function(e) {
            const ci = document.getElementById('ci').value;
            const telefono = document.getElementById('tel').value;
            
            if (ci.length > 8) {
                e.preventDefault();
                mostrarMensaje('Error: La cédula no puede tener más de 8 dígitos.', 'error');
                document.getElementById('ci').focus();
                return false;
            }
            
            if (telefono.length > 9) {
                e.preventDefault();
                mostrarMensaje('Error: El teléfono no puede tener más de 9 dígitos.', 'error');
                document.getElementById('tel').focus();
                return false;
            }
            
            return true;
        });
        
        // Función para mostrar mensajes
        function mostrarMensaje(mensaje, tipo) {
            // Remover mensajes existentes
            const mensajesExistentes = document.querySelectorAll('.mensaje-dinamico');
            mensajesExistentes.forEach(msg => msg.remove());
            
            // Crear nuevo mensaje
            const divMensaje = document.createElement('div');
            divMensaje.className = `mensaje mensaje-${tipo} mensaje-dinamico`;
            divMensaje.textContent = mensaje;
            
            // Insertar después del h2
            const h2 = document.querySelector('h2');
            h2.parentNode.insertBefore(divMensaje, h2.nextSibling);
            
            // Auto-remover después de 5 segundos
            setTimeout(() => {
                divMensaje.remove();
            }, 5000);
        }
        
        // Inicializar el botón de mostrar/ocultar contraseña
        document.addEventListener('DOMContentLoaded', function() {
            const toggleButton = document.getElementById('toggle-password');
            const passwordInput = document.getElementById('password');
            
            if (toggleButton && passwordInput) {
                toggleButton.addEventListener('click', function() {
                    if (passwordInput.type === 'password') {
                        passwordInput.type = 'text';
                        toggleButton.textContent = 'Ocultar';
                        toggleButton.classList.add('active');
                    } else {
                        passwordInput.type = 'password';
                        toggleButton.textContent = 'Mostrar';
                        toggleButton.classList.remove('active');
                    }
                });
            }
            
            // Inicializar contadores
            validarCedula(document.getElementById('ci'));
            validarTelefono(document.getElementById('tel'));
        });
    </script>
</body>
</html>