<?php
session_start();

// Verificar si el usuario es admin
if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: Formulario/FormularioLogin.php");
    exit;
}

// Conexión a la BD
include_once __DIR__ . "/Persistencia/perrosbd.php";
$animalesBD = new perrosBD();

// Procesar cambio de estado
if (isset($_POST['cambiar_estado'])) {
    $solicitud_id = $_POST['solicitud_id'];
    $nuevo_estado = $_POST['nuevo_estado'];
    
    if ($animalesBD->cambiarEstadoSolicitud($solicitud_id, $nuevo_estado)) {
        $mensaje = "Estado actualizado correctamente";
    } else {
        $error = "Error al actualizar el estado";
    }
}

// Procesar eliminación
if (isset($_POST['eliminar_solicitud'])) {
    $solicitud_id = $_POST['solicitud_id'];
    
    if ($animalesBD->eliminarSolicitud($solicitud_id)) {
        $mensaje = "Solicitud eliminada correctamente";
    } else {
        $error = "Error al eliminar la solicitud";
    }
}

// Traer solicitudes
$con = $animalesBD->getConexion();
$sql = "SELECT s.id, u.nombre AS usuario, u.correo, u.tel, m.nombre AS mascota, m.especie, 
        s.telefono AS telefono_solicitud, s.razon, s.fecha_solicitud, s.estado,
        s.contacto_realizado, s.notas_contacto, s.fecha_contacto, s.fecha_aprobacion
        FROM solicitudes s
        JOIN usuarios u ON s.usuario_ci = u.ci
        JOIN mascotas m ON s.mascota_id = m.id
        ORDER BY s.fecha_solicitud DESC";

$resultado = $con->query($sql);
$solicitudes = $animalesBD->ObtenerTodasLasSolicitudes();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solicitudes de Adopción - Panel Admin</title>
    
    <link href="./Estilos/Solicitud.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="./JavaScript/menu.js"></script>

</head>

<body>
    <!-- Header elegante -->
    <header class="admin-header">
        <div class="header-container">
            <div class="header-title">
                <h1>Panel de Administración</h1>
                <p class="subtitle">Solicitudes de Adopción</p>
            </div>

            <!-- Menú desplegable mejorado -->
            <div class="menu-desplegable">
                <button id="menuBtn" class="menu-toggle">
                    <span class="menu-icon">&#9776;</span>
                    <span class="menu-text">Menú</span>
                </button>

                <div id="menuContent" class="menu-content">
                    <div class="menu-header">
                        <h3>Menú Principal</h3>
                    </div>
                    <ul class="menu-list">
                        <li class="menu-item">
                            <a href="index.php" class="menu-link">
                                <span class="menu-icon">🏠</span>
                                <span class="menu-text">Inicio</span>
                            </a>
                        </li>

                        <li class="menu-item">
                            <a href="PanelAdmin.php" class="menu-link">
                                <span class="menu-icon">🐾</span>
                                <span class="menu-text">Animales</span>
                            </a>
                        </li>

                        <li class="menu-item">
                            <a href="PanelAdminUsuario.php" class="menu-link">
                                <span class="menu-icon">👥</span>
                                <span class="menu-text">Usuarios</span>
                            </a>
                        </li>

                        <li class="menu-divider"></li>

                        <li class="menu-item">
                            <a href="Registro.php" class="menu-link">
                                <span class="menu-icon">📋</span>
                                <span class="menu-text">Registros de Adopciones</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </header>

    <div class="admin-container">
        <!-- Panel de estadísticas -->
        <div class="stats-panel">
            <?php
            // Calcular estadísticas
            $totalSolicitudes = $resultado->num_rows;
            $solicitudesPendientes = 0;
            $solicitudesAprobadas = 0;
            $solicitudesRechazadas = 0;
            $solicitudesContactadas = 0;
            
            if ($totalSolicitudes > 0) {
                $resultado->data_seek(0); // Reiniciar el puntero
                while ($fila = $resultado->fetch_assoc()) {
                    switch ($fila['estado']) {
                        case 'pendiente': $solicitudesPendientes++; break;
                        case 'aprobada': 
                            $solicitudesAprobadas++; 
                            if ($fila['contacto_realizado']) {
                                $solicitudesContactadas++;
                            }
                            break;
                        case 'rechazada': $solicitudesRechazadas++; break;
                    }
                }
                $resultado->data_seek(0); // Volver al inicio para mostrar los datos
            }
            ?>
            
            <div class="stat-card">
                <div class="stat-icon total">📋</div>
                <div class="stat-info">
                    <h3><?= $totalSolicitudes ?></h3>
                    <p>Total Solicitudes</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon pending">⏳</div>
                <div class="stat-info">
                    <h3><?= $solicitudesPendientes ?></h3>
                    <p>Pendientes</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon approved">✅</div>
                <div class="stat-info">
                    <h3><?= $solicitudesAprobadas ?></h3>
                    <p>Aprobadas</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon rejected">❌</div>
                <div class="stat-info">
                    <h3><?= $solicitudesRechazadas ?></h3>
                    <p>Rechazadas</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon approved">📞</div>
                <div class="stat-info">
                    <h3><?= $solicitudesContactadas ?></h3>
                    <p>Contactadas</p>
                </div>
            </div>
        </div>

        <main class="main-content">
            <div class="content-header">
                <h2>Gestión de Solicitudes</h2>
                <div class="search-bar">
                    <input type="text" id="searchInput" placeholder="Buscar solicitud...">
                    <span class="search-icon">🔍</span>
                </div>
            </div>

            <!-- Mensajes de éxito/error -->
            <?php if (isset($mensaje)): ?>
                <div class="mensaje-exito"><?= $mensaje ?></div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="mensaje-error"><?= $error ?></div>
            <?php endif; ?>

            <div class="table-container">
                <table class="solicitudes-table">
                    <thead>
                        <tr>
                            <th class="solicitud-info">Solicitud</th>
                            <th>Usuario</th>
                            <th>Contacto</th>
                            <th>Mascota</th>
                            <th>Razón</th>
                            <th>Fecha</th>
                            <th>Estado</th>
                            <th class="actions">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($resultado->num_rows > 0): ?>
                            <?php while ($fila = $resultado->fetch_assoc()): ?>
                                <tr class="solicitud-row" data-search="<?= strtolower(htmlspecialchars($fila['usuario'] . ' ' . $fila['mascota'] . ' ' . $fila['especie'])) ?>">
                                    <td class="solicitud-info">
                                        <div class="solicitud-details">
                                            <strong>#<?= $fila['id'] ?></strong>
                                            <span class="solicitud-telefono"><?= htmlspecialchars($fila['telefono_solicitud']) ?></span>
                                        </div>
                                    </td>
                                    <td class="user-info">
                                        <strong><?= htmlspecialchars($fila['usuario']) ?></strong>
                                        <span class="user-email"><?= htmlspecialchars($fila['correo']) ?></span>
                                    </td>
                                    <td class="contact-info">
                                        <span class="contact-phone"><?= htmlspecialchars($fila['tel']) ?></span>
                                    </td>
                                    <td class="mascota-info">
                                        <strong><?= htmlspecialchars($fila['mascota']) ?></strong>
                                        <span class="mascota-especie"><?= htmlspecialchars($fila['especie']) ?></span>
                                    </td>
                                    <td class="razon-text">
                                        <div class="razon-preview">
                                            <?= strlen($fila['razon']) > 50 ? htmlspecialchars(substr($fila['razon'], 0, 50)) . '...' : htmlspecialchars($fila['razon']) ?>
                                        </div>
                                    </td>
                                    <td class="fecha-solicitud">
                                        <?= date("d/m/Y", strtotime($fila['fecha_solicitud'])) ?>
                                        <span class="hora-solicitud"><?= date("H:i", strtotime($fila['fecha_solicitud'])) ?></span>
                                        <?php if ($fila['fecha_aprobacion']): ?>
                                            <br>
                                            <small style="color: #4CAF50;">
                                                Aprobada: <?= date("d/m/Y", strtotime($fila['fecha_aprobacion'])) ?>
                                            </small>
                                        <?php endif; ?>
                                    </td>
                                    <td class="solicitud-status">
                                        <span class="status-badge estado-<?= strtolower($fila['estado']) ?>">
                                            <?= ucfirst($fila['estado']) ?>
                                        </span>
                                        <?php if ($fila['contacto_realizado']): ?>
                                            <div class="contact-badge contactado">
                                                Contactado
                                            </div>
                                            <?php if ($fila['fecha_contacto']): ?>
                                                <small style="display: block; color: #4CAF50; font-size: 0.7rem;">
                                                    <?= date("d/m/Y", strtotime($fila['fecha_contacto'])) ?>
                                                </small>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td class="solicitud-actions">
                                        <div class="action-buttons">
                                            <!-- Select para cambiar estado -->
                                            <select name="nuevo_estado" class="select-estado" 
                                                    data-solicitud-id="<?= $fila['id'] ?>">
                                                <option value="pendiente" <?= $fila['estado'] == 'pendiente' ? 'selected' : '' ?>>Pendiente</option>
                                                <option value="aprobada" <?= $fila['estado'] == 'aprobada' ? 'selected' : '' ?>>Aprobada</option>
                                                <option value="rechazada" <?= $fila['estado'] == 'rechazada' ? 'selected' : '' ?>>Rechazada</option>
                                            </select>
                                            
                                            <!-- Botón para contactar (solo visible si está aprobada) -->
                                            <?php if ($fila['estado'] == 'aprobada'): ?>
                                                <button type="button" 
                                                        class="btn-contactar <?= $fila['contacto_realizado'] ? 'contactado' : '' ?>" 
                                                        data-solicitud-id="<?= $fila['id'] ?>"
                                                        <?= $fila['contacto_realizado'] ? 'disabled' : '' ?>
                                                        title="Contactar usuario para coordinar visita">
                                                    <?= $fila['contacto_realizado'] ? '✅ Contactado' : '📞 Contactar' ?>
                                                </button>
                                            <?php endif; ?>
                                            
                                            <!-- Botón para eliminar -->
                                            <button type="button" 
                                                    class="btn-eliminar" 
                                                    data-solicitud-id="<?= $fila['id'] ?>"
                                                    title="Eliminar solicitud">
                                                🗑️ Eliminar
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr class="no-solicitudes">
                                <td colspan="8">
                                    <div class="empty-state">
                                        <div class="empty-icon">📋</div>
                                        <h3>No hay solicitudes aún</h3>
                                        <p>No se han recibido solicitudes de adopción.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <script>
        // Búsqueda en tiempo real
        document.getElementById('searchInput').addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('.solicitud-row');
            
            rows.forEach(row => {
                const searchData = row.getAttribute('data-search');
                if (searchData.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    </script>
    <script src="./JavaScript/solicitudesAjax.js"></script>
</body>

</html>