<?php
session_start();

// Verificar si el usuario está inactivo
if (isset($_SESSION['estado']) && $_SESSION['estado'] === 'inactivo') {
    session_destroy();
    header("Location: ./Formulario/FormularioLogin.php?error=inactivo");
    exit;
}

$correo_usuario = $_SESSION['correo'] ?? null;
$rol_usuario = $_SESSION['tipo'] ?? null;
?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Patitas Unidas</title>
  <link rel="stylesheet" href="./Estilos/indexs.css">
  <script src="./JavaScript/menu.js" rel="script"></script>
  <link
    href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500&family=Roboto:wght@400;500&display=swap"
    rel="stylesheet">
</head>

<body>

  <!-- Header elegante -->
  <header>
    <div class="header-container">
      <a href="index.php" class="logo">Patitas Unidas</a>
      
      <!-- Información del usuario en el lado derecho -->
      <div class="user-info">
        <?php if ($correo_usuario): ?>
          <span class="user-details">
            <span class="user-email"><?= htmlspecialchars($correo_usuario) ?></span>
            <span class="user-role"><?= htmlspecialchars($rol_usuario) ?></span>
          </span>
        <?php endif; ?>
      </div>

      <!-- Menú desplegable mejorado -->
      <div class="menu-desplegable">
        <button id="menuBtn" class="menu-toggle">
          <span class="menu-icon">&#9776;</span>
          <span class="menu-text">Menú</span>
        </button>
        <div id="menuContent" class="menu-content">
          <div class="menu-header">
            <h3>Menú Principal</h3>
          </div>
          <ul class="menu-list">
            <li class="menu-item">
              <a href="./Presentacion/Nosotros.php" class="menu-link">
                <span class="menu-icon">👥</span>
                <span class="menu-text">Nosotros</span>
              </a>
            </li>
            
            <?php if ($rol_usuario === 'admin'): ?>
            <li class="menu-item menu-item-admin">
              <a href="./PanelAdmin.php" class="menu-link">
                <span class="menu-icon">⚙️</span>
                <span class="menu-text">Panel Admin</span>
              </a>
            </li>
            <?php endif; ?>
            
            <li class="menu-item">
              <a href="./Formulario/PerfilUsuario.php" class="menu-link">
                <span class="menu-icon">👤</span>
                <span class="menu-text">Mi Perfil</span>
              </a>
            </li>

            <?php if (isset($_SESSION['ci'])): ?>
   <li class="menu-item">
              <a href="./mis_solicitudes.php" class="menu-link">
                <span class="menu-icon">📋</span>
                <span class="menu-text">Mis Solicitudes</span>
              </a>
            </li>
<?php endif; ?>
            
            <?php if ($correo_usuario): ?>
            <li class="menu-item menu-item-logout">
              <a href="./Formulario/cerrar_sesion.php" class="menu-link">
                <span class="menu-icon">🚪</span>
                <span class="menu-text">Cerrar Sesión</span>
              </a>
            </li>
            <?php else: ?>
            <li class="menu-item menu-item-login">
              <a href="./Formulario/FormularioLogin.php" class="menu-link">
                <span class="menu-icon">🔐</span>
                <span class="menu-text">Iniciar Sesión</span>
              </a>
            </li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </div>
  </header>

  <!-- Carátula -->
  <div class="CaratulaPagina">
    <a href="index.php">
      <img src="./Fotoss/CaratulaPagina.png" alt="Carátula Patitas Unidas">
    </a>
  </div>

  <!-- Bienvenida -->
  <section class="Bienvenida">
    <h1>Bienvenido a Patitas Unidas</h1>
    <p>
      Tu hogar favorito para mascotas.<br>
      Explora nuestros perros y gatos, cada uno con su propia personalidad.<br>
      Encuentra a tu compañero ideal y bríndale un hogar lleno de amor.
    </p>
  </section>

  <!-- Sección Mascotas -->
  <section class="mascotas">
    <div class="animal">
      <div class="Perro-Caratula">
        <a href="./Presentacion/perro.php">
          <img src="./Fotoss/PerroCaratula.webp" alt="Perros">
        </a>
        <h2>Perros</h2>
      </div>
      <p>Leales, protectores y compañeros de vida. Descubre todos nuestros perros listos para ser adoptados.</p>
    </div>
    <div class="animal">
      <div class="Gato-Caratula">
        <a href="./Presentacion/gatos.php">
          <img src="./Fotoss/GatoCaratula.webp" alt="Gatos">
        </a>
        <h2>Gatos</h2>
      </div>
      <p>Independientes, tiernos y elegantes. Conoce a nuestros gatos que esperan un hogar lleno de cariño.</p>
    </div>
    <div class="animal">
      <div class="Adopta-Caratula">
        <a href="./Presentacion/Otros.php">
          <img src="./Fotoss/Otros.png" alt="Otros"  width="200px" height="225px">
        </a>
        <h2>Otros</h2>
      </div>
      <p>Animales diversos en busca de un hogar. Descubre nuestras historias y cómo puedes ayudar.</p>
    </div>
  </section>

  <footer>
    <div class="footer-container">
        <p>&copy; 2025 Patitas Unidas. Todos los derechos reservados.</p>
    </div>
  </footer>

</body>

</html>