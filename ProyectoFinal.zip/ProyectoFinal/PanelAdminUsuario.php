<?php
session_start();

// Verificar permisos de administrador
if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: index.php");
    exit;
}

// Incluir dependencias
include_once __DIR__ . "/Logica/Usuarios.php";
include_once __DIR__ . "/Persistencia/usuariosbd.php";

$usuarioBD = new UsuarioBD();
$listaUsuario = $usuarioBD->MostrarUsuarios();
$rol_usuario = $_SESSION['tipo'] ?? null;

// Estadísticas
$totalUsuarios = count($listaUsuario);
$usuariosActivos = count(array_filter($listaUsuario, fn($u) => $u->getEstado() === 'activo'));
$usuariosInactivos = $totalUsuarios - $usuariosActivos;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Usuarios - Panel Admin</title>
    <link rel="stylesheet" href="./Estilos/PanelUsuario.css?v=<?= time() ?>">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    
    <!--JavaScript!-->
    <script src="./JavaScript/main.js" defer></script>
    <script src="./JavaScript/menu.js" defer></script>
    
</head>
<body>
    <!-- Header -->
    <header class="admin-header">
        <div class="header-container">
            <div class="header-title">
                <h1>Panel de Administración</h1>
                <p class="subtitle">Gestión de Usuarios</p>
            </div>

            <!-- Menú desplegable -->
            <div class="menu-desplegable">
                <button id="menuBtn" class="menu-toggle">
                    <span class="menu-icon">&#9776;</span>
                    <span class="menu-text">Menú</span>
                </button>
                <div id="menuContent" class="menu-content">
                    <div class="menu-header">
                        <h3>Menú Principal</h3>
                    </div>
                    <ul class="menu-list">
                        <li class="menu-item">
                            <a href="index.php" class="menu-link">
                                <span class="menu-icon">🏠</span>
                                <span class="menu-text">Inicio</span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="PanelAdmin.php" class="menu-link">
                                <span class="menu-icon">🐾</span>
                                <span class="menu-text">Animales</span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="Solicitudes.php" class="menu-link">
                                <span class="menu-icon">📋</span>
                                <span class="menu-text">Solicitudes</span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="Registro.php" class="menu-link">
                                <span class="menu-icon">🚪</span>
                                <span class="menu-text">Registros de Adopciones</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </header>

    <div class="admin-container">
        <!-- Panel de estadísticas -->
        <div class="stats-panel">
            <div class="stat-card">
                <div class="stat-icon total">👥</div>
                <div class="stat-info">
                    <h3><?= $totalUsuarios ?></h3>
                    <p>Total Usuarios</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon active">✅</div>
                <div class="stat-info">
                    <h3><?= $usuariosActivos ?></h3>
                    <p>Usuarios Activos</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon inactive">⏸️</div>
                <div class="stat-info">
                    <h3><?= $usuariosInactivos ?></h3>
                    <p>Usuarios Inactivos</p>
                </div>
            </div>
        </div>

        <main class="main-content">
            <div class="content-header">
                <h2>Gestión de Usuarios</h2>
                <div class="search-bar">
                    <input type="text" id="searchInput" placeholder="Buscar usuario...">
                    <span class="search-icon">🔍</span>
                </div>
            </div>

            <div class="table-container">
    <table class="users-table">
        <thead>
            <tr>
                <th class="user-info">Usuario</th>
                <th>Correo</th>
                <th>Cédula</th>
                <th>Tipo</th>
                <th>Foto</th>
                <th>Estado</th>
                <th class="actions-col">Cambiar Estado</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($listaUsuario)): ?>
                <?php foreach ($listaUsuario as $usuario): ?>
                    <tr class="user-row" data-search="<?= strtolower(htmlspecialchars($usuario->getNombre() . ' ' . $usuario->getEmail())) ?>">
                        <td class="user-info">
                            <div class="user-details">
                                <strong><?= htmlspecialchars($usuario->getNombre()) ?></strong>
                                <span class="user-phone"><?= htmlspecialchars($usuario->getTelefono()) ?></span>
                            </div>
                        </td>
                        <td class="user-email"><?= htmlspecialchars($usuario->getEmail()) ?></td>
                        <td class="user-ci"><?= htmlspecialchars($usuario->getCi()) ?></td>
                        <td class="user-type">
                            <span class="type-badge <?= htmlspecialchars($usuario->getTipo()) ?>">
                                <?= htmlspecialchars($usuario->getTipo()) ?>
                            </span>
                        </td>
                        <td class="user-photo-cell">
    <div class="photo-container">
        <?php if ($usuario->getFoto()): ?>
            <img src="./Formulario/Fotoss/<?= htmlspecialchars($usuario->getFoto()) ?>" 
                 alt="Foto de <?= htmlspecialchars($usuario->getNombre()) ?>" 
                 class="user-photo"
                 onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
            <div class="photo-placeholder" style="display: none;">👤</div>
        <?php else: ?>
            <div class="photo-placeholder">👤</div>
        <?php endif; ?>
    </div>
</td>
                        <td class="user-status" data-tipo="estado">
                            <span class="status-badge <?= htmlspecialchars($usuario->getEstado()) ?>">
                                <?= htmlspecialchars($usuario->getEstado()) ?>
                            </span>
                        </td>
                        <td class="user-actions" data-tipo="acciones">
                            <?php if ($usuario->getEstado() == "activo"): ?>
                                <button type="button"
                                        data-accion="inhabilitar-usuario"
                                        data-id="<?= htmlspecialchars($usuario->getCi()); ?>"
                                        class="btn-admin btn-inhabilitar"
                                        title="Inhabilitar usuario">
                                    🚫 Inhabilitar
                                </button>
                            <?php else: ?>
                                <button type="button"
                                        data-accion="activar-usuario"
                                        data-id="<?= htmlspecialchars($usuario->getCi()); ?>"
                                        class="btn-admin btn-activar"
                                        title="Activar usuario">
                                    ✅ Activar
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr class="no-users">
                    <td colspan="8">
                        <div class="empty-state">
                            <div class="empty-icon">👥</div>
                            <h3>No hay usuarios registrados</h3>
                            <p>No se encontraron usuarios en el sistema.</p>
                        </div>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
        </main>
    </div>


   <script>
// =====================
// GESTIÓN COMPLETA DE USUARIOS - AJAX
// =====================

class GestorUsuarios {
    constructor() {
        this.modal = document.getElementById('modalEditarUsuario');
        this.form = document.getElementById('formEditarUsuario');
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupSearch();
        this.setupModal();
    }

    setupEventListeners() {
        // Escuchar clicks en botones de acción
        document.body.addEventListener("click", async (e) => {
            const boton = e.target.closest("[data-accion]");
            if (boton) {
                e.preventDefault();
                const accion = boton.dataset.accion;
                const id = boton.dataset.id;

                if (this.esAccionUsuario(accion)) {
                    await this.ejecutarAccionUsuario(accion, id, boton);
                }
                return;
            }

            // Manejar botones editar
            const botonEditar = e.target.closest('.btn-editar-usuario');
            if (botonEditar) {
                e.preventDefault();
                this.abrirModalEdicion(botonEditar);
            }
        });
    }

    setupModal() {
        // Cerrar modal
        this.modal.querySelector('.close').addEventListener('click', () => this.cerrarModal());
        this.modal.querySelector('.btn-cancelar').addEventListener('click', () => this.cerrarModal());
        this.modal.addEventListener('click', (e) => {
            if (e.target === this.modal) this.cerrarModal();
        });

        // Enviar formulario
        this.form.addEventListener('submit', (e) => this.enviarFormularioEdicion(e));
    }

    abrirModalEdicion(boton) {
        const datos = {
            ci: boton.dataset.ci,
            nombre: boton.dataset.nombre,
            email: boton.dataset.email,
            telefono: boton.dataset.telefono,
            estado: boton.dataset.estado,
            foto: boton.dataset.foto
        };

        document.getElementById('edit_usuario_ci').value = datos.ci;
        document.getElementById('edit_nombre_usuario').value = datos.nombre;
        document.getElementById('edit_email').value = datos.email;
        document.getElementById('edit_telefono').value = datos.telefono;
        document.getElementById('edit_estado_usuario').value = datos.estado;
        
        this.mostrarFotoActual(datos.foto);
        this.modal.style.display = 'block';
    }

    mostrarFotoActual(foto) {
    const preview = document.getElementById('preview_foto_usuario_actual');
    const texto = document.getElementById('texto_foto_usuario_actual');
    
    if (foto) {
        preview.src = `./Formulario/Fotoss/${foto}`;
        preview.style.display = 'block';
        texto.textContent = foto;
        texto.style.display = 'none';
    } else {
        preview.style.display = 'none';
        texto.textContent = 'No hay foto';
        texto.style.display = 'inline';
    }
}

    cerrarModal() {
        this.modal.style.display = 'none';
        this.form.reset();
    }

    async enviarFormularioEdicion(e) {
        e.preventDefault();
        e.stopPropagation();
        
        const formData = new FormData(this.form);
        const botonGuardar = this.form.querySelector('.btn-guardar');
        const textoOriginal = botonGuardar.innerHTML;
        const usuarioCi = document.getElementById('edit_usuario_ci').value;
        
        try {
            botonGuardar.innerHTML = '⏳ Guardando...';
            botonGuardar.disabled = true;

            const respuesta = await fetch('./actualizar_usuario.php', {
                method: 'POST',
                body: formData
            });

            if (!respuesta.ok) {
                throw new Error(`Error HTTP: ${respuesta.status}`);
            }

            const resultado = await respuesta.json();

            if (resultado.success) {
                this.mostrarAlerta('✅ ' + resultado.message, 'success');
                this.cerrarModal();
                
                // Actualizar la fila sin recargar
                await this.actualizarFilaUsuario(usuarioCi, resultado.datos);
                
            } else {
                this.mostrarAlerta('❌ ' + resultado.message, 'error');
            }
        } catch (error) {
            console.error('Error:', error);
            this.mostrarAlerta('❌ Error de conexión: ' + error.message, 'error');
        } finally {
            botonGuardar.innerHTML = textoOriginal;
            botonGuardar.disabled = false;
        }
        
        return false;
    }

    async actualizarFilaUsuario(usuarioCi, datosUsuario) {
        console.log('Actualizando fila para usuario CI:', usuarioCi);
        
        // Buscar la fila
        const botonesEditar = document.querySelectorAll('.btn-editar-usuario');
        let fila = null;
        
        for (let boton of botonesEditar) {
            if (boton.dataset.ci === usuarioCi) {
                fila = boton.closest('tr');
                break;
            }
        }
        
        if (!fila) {
            console.error('No se encontró la fila para el usuario CI:', usuarioCi);
            return;
        }
        
        const cells = fila.querySelectorAll('td');
        
        // Actualizar nombre
        const userDetails = cells[0].querySelector('.user-details');
        if (userDetails) {
            const nombreElement = userDetails.querySelector('strong');
            if (nombreElement) {
                nombreElement.textContent = datosUsuario.nombre;
            }
        }
        
        // Actualizar email
        cells[1].textContent = datosUsuario.email;
        
        // Actualizar teléfono
        if (userDetails) {
            const telefonoElement = userDetails.querySelector('.user-phone');
            if (telefonoElement) {
                telefonoElement.textContent = datosUsuario.telefono;
            }
        }
        
        
        // Actualizar estado
        const estadoBadge = cells[5].querySelector('.status-badge');
        if (estadoBadge) {
            estadoBadge.textContent = datosUsuario.estado;
            estadoBadge.className = `status-badge ${datosUsuario.estado}`;
        }
        
        // Actualizar botones de estado
        const celdaAcciones = cells[6];
        if (celdaAcciones) {
            if (datosUsuario.estado === 'activo') {
                celdaAcciones.innerHTML = `
                    <button type="button"
                            data-accion="inhabilitar-usuario"
                            data-id="${datosUsuario.ci}"
                            class="btn-admin btn-inhabilitar"
                            title="Inhabilitar usuario">
                        🚫 Inhabilitar
                    </button>
                `;
            } else {
                celdaAcciones.innerHTML = `
                    <button type="button"
                            data-accion="activar-usuario"
                            data-id="${datosUsuario.ci}"
                            class="btn-admin btn-activar"
                            title="Activar usuario">
                        ✅ Activar
                    </button>
                `;
            }
        }
        
        // Actualizar botón editar con nuevos datos
        const botonEditar = cells[7].querySelector('.btn-editar-usuario');
        if (botonEditar) {
            botonEditar.dataset.nombre = datosUsuario.nombre;
            botonEditar.dataset.email = datosUsuario.email;
            botonEditar.dataset.telefono = datosUsuario.telefono;
            botonEditar.dataset.estado = datosUsuario.estado;
            botonEditar.dataset.foto = datosUsuario.foto;
        }
        
        // Actualizar foto
if (datosUsuario.foto) {
    const imgContainer = cells[4];
    const existingImg = imgContainer.querySelector('.user-photo');
    const placeholder = imgContainer.querySelector('.photo-placeholder');
    
    if (existingImg) {
        existingImg.src = `./Formulario/Fotoss/${datosUsuario.foto}`;
        existingImg.alt = `Foto de ${datosUsuario.nombre}`;
    } else if (placeholder) {
        placeholder.outerHTML = `<img src="./Formulario/Fotoss/${datosUsuario.foto}" 
                                     alt="Foto de ${datosUsuario.nombre}" 
                                     class="user-photo">`;
    }
}
        
        // Re-aplicar event listeners
        this.reaplicarEventListeners(fila);
        
        // Efecto visual
        fila.style.transition = 'background-color 0.5s ease';
        fila.style.backgroundColor = 'rgba(76, 175, 80, 0.2)';
        setTimeout(() => {
            fila.style.backgroundColor = '';
        }, 1000);
    }

    reaplicarEventListeners(fila) {
        // Re-aplicar event listener al botón de estado
        const botonEstado = fila.querySelector('[data-accion]');
        if (botonEstado) {
            botonEstado.addEventListener('click', async (e) => {
                e.preventDefault();
                await this.ejecutarAccionUsuario(
                    botonEstado.dataset.accion, 
                    botonEstado.dataset.id, 
                    botonEstado
                );
            });
        }

        // Re-aplicar event listener al botón editar
        const botonEditar = fila.querySelector('.btn-editar-usuario');
        if (botonEditar) {
            botonEditar.addEventListener('click', (e) => {
                e.preventDefault();
                this.abrirModalEdicion(botonEditar);
            });
        }
    }

    // ========== MÉTODOS PARA CAMBIAR ESTADO ==========

    esAccionUsuario(accion) {
        return ["inhabilitar-usuario", "activar-usuario"].includes(accion);
    }

    async ejecutarAccionUsuario(accion, id, boton) {
        const url = this.obtenerUrlAccion(accion);
        
        if (!url) {
            this.mostrarAlerta("Acción no válida", "error");
            return;
        }

        console.log("🔍 Enviando petición:", { accion, url, id });

        try {
            // Mostrar loading en el botón
            const textoOriginal = boton.innerHTML;
            boton.innerHTML = '⏳ Procesando...';
            boton.disabled = true;
            boton.classList.add('processing');

            const response = await this.enviarPeticion(url, id);
            const data = await this.procesarRespuesta(response);

            if (data.exito) {
                this.actualizarInterfazEstado(data, boton, id);
                this.mostrarAlerta(data.mensaje, "success");
            } else {
                this.mostrarAlerta(data.mensaje || "Error en la operación", "error");
            }

        } catch (error) {
            console.error("❌ Error completo:", error);
            this.mostrarAlerta(`Error: ${error.message}`, "error");
        } finally {
            // Restaurar botón
            boton.innerHTML = textoOriginal;
            boton.disabled = false;
            boton.classList.remove('processing');
        }
    }

    obtenerUrlAccion(accion) {
        const urls = {
            'inhabilitar-usuario': './Presentacion/CambiarEstados/InhabilitarUsuario.php',
            'activar-usuario': './Presentacion/CambiarEstados/ActivarUsuario.php'
        };
        return urls[accion];
    }

    async enviarPeticion(url, id) {
        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: new URLSearchParams({ id: id })
        });

        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status} ${response.statusText}`);
        }

        return response;
    }

    async procesarRespuesta(response) {
        const responseText = await response.text();
        console.log("📝 Respuesta completa:", responseText);

        // Limpiar respuesta
        let cleanResponse = this.limpiarRespuesta(responseText);
        console.log("🧹 Respuesta limpia:", cleanResponse);

        try {
            return JSON.parse(cleanResponse);
        } catch (jsonError) {
            console.error("❌ Error parseando JSON:", jsonError);
            const jsonMatch = cleanResponse.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                return JSON.parse(jsonMatch[0]);
            } else {
                throw new Error("No se pudo extraer JSON válido de la respuesta");
            }
        }
    }

    limpiarRespuesta(texto) {
        let clean = texto.trim();
        
        // Eliminar backticks
        if (clean.startsWith('`')) clean = clean.substring(1);
        if (clean.endsWith('`')) clean = clean.substring(0, clean.length - 1);
        
        // Eliminar caracteres no JSON al inicio
        clean = clean.replace(/^[^\{]*/, '');
        
        return clean;
    }

    actualizarInterfazEstado(data, boton, id) {
        console.log("🔍 DEBUG - Datos recibidos:", data);
        
        const fila = boton.closest("tr");
        if (!fila) {
            console.error("No se encontró la fila del usuario");
            return;
        }

        const tdEstado = fila.querySelector("[data-tipo='estado']");
        const tdAcciones = fila.querySelector("[data-tipo='acciones']");

        // Actualizar estado
        if (tdEstado) {
            tdEstado.innerHTML = this.crearBadgeEstado(data.nuevoEstado);
            console.log("✅ Estado actualizado a:", data.nuevoEstado);
        }

        // Actualizar botones
        if (tdAcciones) {
            tdAcciones.innerHTML = this.crearBotonAccion(data.nuevoEstado, id);
            console.log("🔄 Botón actualizado");
        }

        // Actualizar botón editar
        const botonEditar = fila.querySelector('.btn-editar-usuario');
        if (botonEditar) {
            botonEditar.dataset.estado = data.nuevoEstado;
        }

        this.reaplicarEventListeners(fila);
    }

    crearBadgeEstado(estado) {
        return `<span class="status-badge ${estado}">${estado}</span>`;
    }

    crearBotonAccion(estado, id) {
        if (estado === "activo") {
            return `
                <button type="button"
                        data-accion="inhabilitar-usuario"
                        data-id="${id}"
                        class="btn-admin btn-inhabilitar"
                        title="Inhabilitar usuario">
                    🚫 Inhabilitar
                </button>
            `;
        } else {
            return `
                <button type="button"
                        data-accion="activar-usuario"
                        data-id="${id}"
                        class="btn-admin btn-activar"
                        title="Activar usuario">
                    ✅ Activar
                </button>
            `;
        }
    }

    // ========== BÚSQUEDA ==========

    setupSearch() {
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.filtrarUsuarios(e.target.value.toLowerCase());
            });
        }
    }

    filtrarUsuarios(termino) {
        const rows = document.querySelectorAll('.user-row');
        
        rows.forEach(row => {
            const searchData = row.getAttribute('data-search');
            if (searchData.includes(termino)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    // ========== ALERTAS ==========

    mostrarAlerta(mensaje, tipo) {
        // Eliminar alertas existentes
        const alertasExistentes = document.querySelectorAll('.alerta-temporal');
        alertasExistentes.forEach(alerta => alerta.remove());

        // Crear nueva alerta
        const alerta = document.createElement("div");
        alerta.className = `alerta-temporal ${tipo}`;
        alerta.textContent = mensaje;
        
        alerta.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            z-index: 10000;
            background-color: ${tipo === 'success' ? '#4CAF50' : '#f44336'};
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        `;
        
        document.body.appendChild(alerta);
        
        // Auto-eliminar después de 4 segundos
        setTimeout(() => {
            if (alerta.parentElement) {
                alerta.parentElement.removeChild(alerta);
            }
        }, 4000);
    }
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    new GestorUsuarios();
});
</script>
</body>
</html>