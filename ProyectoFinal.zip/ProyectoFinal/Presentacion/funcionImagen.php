<?php
function CargarImagen($archivo) {
    error_log("🔄 Iniciando CargarImagen...");
    
    $directorio = "./Fotoss/";
    
    // Verificar si el directorio existe
    if (!file_exists($directorio)) {
        error_log("📁 Creando directorio: " . $directorio);
        if (!mkdir($directorio, 0755, true)) {
            error_log("❌ No se pudo crear directorio");
            return null;
        }
    }
    
    // Verificar permisos de escritura
    if (!is_writable($directorio)) {
        error_log("❌ Directorio sin permisos de escritura");
        return null;
    }
    
    $nombre_original = $archivo['name'];
    $tipo_archivo = $archivo['type'];
    $tamaño_archivo = $archivo['size'];
    $archivo_temporal = $archivo['tmp_name'];
    $error = $archivo['error'];
    
    error_log("📄 Archivo: " . $nombre_original);
    error_log("📏 Tamaño: " . $tamaño_archivo);
    error_log("🔧 Tipo: " . $tipo_archivo);
    error_log("📍 Temporal: " . $archivo_temporal);
    error_log("❓ Error: " . $error);
    
    if ($error !== UPLOAD_ERR_OK) {
        error_log("❌ Error al subir archivo: " . $error);
        return null;
    }
    
    // Verificar que sea una imagen
    $permitidos = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    if (!in_array($tipo_archivo, $permitidos)) {
        error_log("❌ Tipo de archivo no permitido: " . $tipo_archivo);
        return null;
    }
    
    // Verificar tamaño (máximo 5MB)
    if ($tamaño_archivo > 5 * 1024 * 1024) {
        error_log("❌ Archivo demasiado grande: " . $tamaño_archivo);
        return null;
    }
    
    // Generar nombre único
    $extension = strtolower(pathinfo($nombre_original, PATHINFO_EXTENSION));
    $nombre_unico = uniqid() . '_' . time() . '.' . $extension;
    $ruta_destino = $directorio . $nombre_unico;
    
    error_log("💾 Guardando como: " . $nombre_unico);
    error_log("🎯 Ruta destino: " . $ruta_destino);
    
    // Mover el archivo
    if (move_uploaded_file($archivo_temporal, $ruta_destino)) {
        error_log("✅ Imagen movida correctamente a: " . $ruta_destino);
        
        // Verificar que el archivo existe
        if (file_exists($ruta_destino)) {
            error_log("✅ Archivo verificado en destino");
            return $nombre_unico;
        } else {
            error_log("❌ Archivo no encontrado en destino");
            return null;
        }
    } else {
        error_log("❌ Error al mover archivo");
        return null;
    }
}


/**
 * Función específica para imágenes de usuarios
 */
function CargarImagenUsuario($archivo)
{
    // Validar archivo
    if (!isset($archivo) || $archivo['error'] !== UPLOAD_ERR_OK) {
        return null;
    }

    $carpetaDestino = "../Formulario/Fotoss/"; // Ruta corregida
    
    // Crear carpeta si no existe
    if (!file_exists($carpetaDestino)) {
        mkdir($carpetaDestino, 0777, true);
    }

    // Validar tipo de archivo
    $extension = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));
    $extensionesPermitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    
    if (!in_array($extension, $extensionesPermitidas)) {
        return null;
    }

    // Validar tamaño (máximo 5MB)
    if ($archivo['size'] > 5 * 1024 * 1024) {
        return null;
    }

    // Generar nombre único
    $nombreArchivo = time() . "_" . uniqid() . "." . $extension;
    $rutaDestino = $carpetaDestino . $nombreArchivo;

    // Mover el archivo
    if (move_uploaded_file($archivo['tmp_name'], $rutaDestino)) {
        return $nombreArchivo;
    }
    
    return null;
}

/**
 * Obtener ruta de imagen de usuario
 */
function obtenerRutaImagenUsuario($nombreArchivo) {
    if (!$nombreArchivo) return null;
    
    $ruta = "../Formulario/Fotoss/" . $nombreArchivo;
    return file_exists($ruta) ? $ruta : null;
}
?>
