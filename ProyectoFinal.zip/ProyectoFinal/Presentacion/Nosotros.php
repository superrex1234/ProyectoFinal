<?php
session_start();

$correo_usuario = $_SESSION['correo'] ?? null;
$rol_usuario = $_SESSION['tipo'] ?? null;
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Estilos/Nosotro.css">
    <title>Nosotros</title>
</head>

<body>
 
    <!-- Header simplificado -->
    <header>
        <div class="header-container">
            <a href="../index.php" class="logo">Patitas Unidas</a>
            
           
            <!-- Botón Volver al Inicio -->
            <a href="../index.php" class="btn-volver">← Volver al Inicio</a>
        </div>
    </header>
   
    <!-- Contenido de la página Nosotros -->
    <div class="container">
        <h1>¿Quiénes somos?</h1>
        <p>
            Somos Patitas Unidas, un albergue dedicado a rescatar y encontrar hogares para perros y gatos abandonados o
            maltratados.
            Ofrecemos atención veterinaria, alimentación y un refugio seguro, trabajando con amor para darles una
            segunda oportunidad.
        </p>
        <p>Visítanos y descubre cómo puedes adoptar a tu nuevo mejor amigo.</p>
    </div>

    <footer>
        <div class="footer-container">
            <p>&copy; 2025 Patitas Unidas. Todos los derechos reservados.</p>
        </div>
    </footer>
</body>
</html>