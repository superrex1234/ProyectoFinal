<?php
session_start();
require_once "../Persistencia/perrosbd.php";
require_once "../Logica/Perros.php";
require_once "../Presentacion/funcionImagen.php";

$perrosBD = new perrosbd();
$listaOtros = $perrosBD->MostrarOtrosDisponibles();
$es_admin = isset($_SESSION['tipo']) && $_SESSION['tipo'] === 'admin';

// Procesar actualización vía AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar_otros'])) {
    if (!$es_admin) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'No tienes permisos para realizar esta acción']);
        exit;
    }
    
    $mascota = new Perros();
    $resultado = $mascota->ActualizarInfoOtros(
        $_POST['id'],
        $_POST['nombre'],
        $_POST['raza'],
        $_POST['edad'],
        $_POST['sexo'],
        $_POST['caracteristicas'],
        $_POST['foto_actual']
    );
    
    if ($resultado) {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => 'Mascota actualizada correctamente']);
        exit;
    } else {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Error al actualizar la mascota']);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Estilos/Otros.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Adopta una Mascota</title>
</head>
<body>
    <header>
        <div class="header-container">
            <a href="../index.php" class="logo">Patitas Unidas</a>
            <a href="../index.php" class="btn-volver">← Volver al Inicio</a>
        </div>
    </header>

    <main class="catalogo">
        <?php if ($listaOtros && count($listaOtros) > 0): ?>
            <?php foreach ($listaOtros as $otros): ?>
                <?php
                $mascotaCompleta = $perrosBD->ObtenerMascotaPorId($otros->getIdOtros());
                $caracteristicas = $mascotaCompleta['caracteristicas'] ?? 'Sin características definidas';
                $fotoSrc = $otros->getFotoOtros() ?: 'default.png';
                ?>
                
                <div class="mascota" 
     data-bs-toggle="modal" 
     data-bs-target="#modalInfoOtros"
     data-id="<?= $otros->getIdOtros() ?>"
     data-nombre="<?= htmlspecialchars($otros->getNombreOtros()) ?>"
     data-raza="<?= htmlspecialchars($otros->getRazaOtros()) ?>"
     data-edad="<?= htmlspecialchars($otros->getEdadOtros()) ?>"
     data-sexo="<?= htmlspecialchars($otros->getSexoOtros()) ?>"
     data-caracteristicas="<?= htmlspecialchars($caracteristicas) ?>"
     data-foto="<?= htmlspecialchars($fotoSrc) ?>">
    
    <div class="mascota-image-container">
        <img src="../Fotoss/<?= $fotoSrc ?>" alt="Foto de <?= htmlspecialchars($otros->getNombreOtros()) ?>">
        <span class="click-message">🖱️ Click para Ver Información</span>
    </div>
    
    <div class="mascota-content">
        <h3><?= htmlspecialchars($otros->getNombreOtros()) ?></h3>
        <p>Sexo: <?= htmlspecialchars($otros->getSexoOtros()) ?></p>
        <p>Edad: <?= htmlspecialchars($otros->getEdadOtros()) ?></p>
        <p>Raza: <?= htmlspecialchars($otros->getRazaOtros()) ?></p>
        
        <?php if ($es_admin): ?>
            <div class="botones-container">
                <button class="btn-editar" 
                        onclick="event.stopPropagation()" 
                        data-bs-toggle="modal" 
                        data-bs-target="#modalEditarOtros"
                        data-id="<?= $otros->getIdOtros() ?>"
                        data-nombre="<?= htmlspecialchars($otros->getNombreOtros()) ?>"
                        data-raza="<?= htmlspecialchars($otros->getRazaOtros()) ?>"
                        data-edad="<?= htmlspecialchars($otros->getEdadOtros()) ?>"
                        data-sexo="<?= htmlspecialchars($otros->getSexoOtros()) ?>"
                        data-caracteristicas="<?= htmlspecialchars($caracteristicas) ?>"
                        data-foto="<?= htmlspecialchars($fotoSrc) ?>">
                    Editar
                </button>
            </div>
        <?php endif; ?>
    </div>
</div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="no-mascotas">No hay mascotas disponibles por el momento 🐾.</p>
        <?php endif; ?>
    </main>

    <!-- Modal Información Otros -->
    <div class="modal fade" id="modalInfoOtros" tabindex="-1" aria-labelledby="modalInfoOtrosLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Información de la Mascota</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                
                <div class="modal-body">
                    <div class="modal-grid">
                        <div class="modal-image">
                            <img id="info_foto_otros" src="" alt="Foto de la mascota">
                        </div>
                        
                        <div class="modal-info">
                            <h2 id="info_nombre_otros"></h2>
                            
                            <div class="info-grid">
                                <div class="info-item">
                                    <span class="info-label">Raza:</span>
                                    <span id="info_raza_otros" class="info-value"></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Edad:</span>
                                    <span id="info_edad_otros" class="info-value"></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Sexo:</span>
                                    <span id="info_sexo_otros" class="info-value"></span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="modal-description">
                            <h3 class="section-title">Descripción</h3>
                            <div id="info_caracteristicas_otros" class="description-content"></div>
                        </div>
                        
                        <div class="modal-solicitud">
                            <h3 class="section-title">Solicitar Adopción</h3>
                            <?php if (isset($_SESSION['ci'])): ?>
                                <?php $solicitud_existente = $perrosBD->VerificarSolicitudExistente($_SESSION['ci'], $otros->getIdOtros()); ?>
                                
                                <?php if (!$solicitud_existente): ?>
                                    <form method="POST" action="../Presentacion/procesar_solicitud.php" class="solicitud-form">
                                        <input type="hidden" name="mascota_id" id="solicitud_mascota_id_otros">
                                        <input type="hidden" name="especie" value="otro">
                                        
                                        <div class="form-group">
                                            <label for="telefono_solicitud_otros">Teléfono de Contacto *</label>
                                            <input type="tel" id="telefono_solicitud_otros" name="telefono" required placeholder="Ej: 0981234567">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="razon_solicitud_otros">¿Por qué quieres adoptar a <span id="nombre_mascota_solicitud_otros"></span>? *</label>
                                            <textarea id="razon_solicitud_otros" name="razon" rows="4" required 
                                                      placeholder="Cuéntanos sobre tu experiencia con mascotas, tu hogar, y por qué serías un buen dueño..."></textarea>
                                        </div>
                                        
                                        <button type="submit" class="btn-solicitud">
                                            🐾 Enviar Solicitud de Adopción
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <div class="alert-info">
                                        <strong>✅ Ya has enviado una solicitud para esta mascota</strong>
                                        <p>Revisa el estado en <a href="../mis_solicitudes.php">Mis Solicitudes</a></p>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="alert-warning">
                                    <strong>⚠️ Debes iniciar sesión para enviar una solicitud</strong>
                                    <div class="auth-buttons">
                                        <a href="../Formulario/FormularioLogin.php" class="btn-login">Iniciar Sesión</a>
                                        <a href="../Formulario/FormularioRegistro.php" class="btn-register">Registrarse</a>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Editar Otros -->
    <?php if ($es_admin): ?>
    <div class="modal fade" id="modalEditarOtros" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content modal-animal-content">
                <div class="modal-animal-header">
                    <div class="modal-animal-title">
                        <i class="modal-icon">✏️</i>
                        <h3>Editar Mascota</h3>
                    </div>
                    <button type="button" class="modal-animal-close" data-bs-dismiss="modal">&times;</button>
                </div>
                
                <form id="formEditarOtros" class="modal-animal-form">
                    <input type="hidden" name="id" id="edit_id_otros">
                    <input type="hidden" name="actualizar_otros" value="1">
                    <input type="hidden" name="foto_actual" id="edit_foto_actual_otros">
                    
                    <div class="modal-animal-body">
                        <div class="form-grid-modal">
                            <div class="form-group-modal">
                                <label for="edit_nombre_otros" class="form-label-modal">
                                    Nombre de la Mascota *
                                </label>
                                <input type="text" id="edit_nombre_otros" name="nombre" class="form-input-modal" required>
                            </div>
                            
                            <div class="form-group-modal">
                                <label for="edit_raza_otros" class="form-label-modal">
                                    Raza/Especie *
                                </label>
                                <input type="text" id="edit_raza_otros" name="raza" class="form-input-modal" required>
                            </div>
                            
                            <div class="form-group-modal">
                                <label for="edit_edad_otros" class="form-label-modal">
                                    Edad *
                                </label>
                                <input type="text" id="edit_edad_otros" name="edad" class="form-input-modal" required>
                            </div>
                            
                            <div class="form-group-modal">
                                <label for="edit_sexo_otros" class="form-label-modal">
                                    Sexo *
                                </label>
                                <select id="edit_sexo_otros" name="sexo" class="form-select-modal" required>
                                    <option value="">Seleccionar sexo</option>
                                    <option value="Macho">Macho</option>
                                    <option value="Hembra">Hembra</option>
                                </select>
                            </div>
                            
                            <div class="form-group-modal full-width">
                                <label for="edit_caracteristicas_otros" class="form-label-modal">
                                    Descripción de la Mascota
                                </label>
                                <textarea id="edit_caracteristicas_otros" name="caracteristicas" class="form-input-modal" rows="4" 
                                          placeholder="Describe las características de la mascota..."></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-animal-footer">
                        <button type="button" class="btn-modal btn-modal-secondary" data-bs-dismiss="modal">
                            <i class="btn-icon">❌</i>
                            Cancelar
                        </button>
                        <button type="submit" class="btn-modal btn-modal-primary">
                            <i class="btn-icon">💾</i>
                            <span class="btn-text">Guardar Cambios</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Modal Información
            const modalInfo = document.getElementById('modalInfoOtros');
            modalInfo.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                const fotoSrc = '../Fotoss/' + (button.getAttribute('data-foto') || 'default.png');
                
                document.getElementById('info_nombre_otros').textContent = button.getAttribute('data-nombre');
                document.getElementById('info_raza_otros').textContent = button.getAttribute('data-raza');
                document.getElementById('info_edad_otros').textContent = button.getAttribute('data-edad');
                document.getElementById('info_sexo_otros').textContent = button.getAttribute('data-sexo');
                document.getElementById('info_caracteristicas_otros').textContent = button.getAttribute('data-caracteristicas');
                document.getElementById('info_foto_otros').src = fotoSrc;
                
                // Datos formulario solicitud
                document.getElementById('solicitud_mascota_id_otros').value = button.getAttribute('data-id');
                document.getElementById('nombre_mascota_solicitud_otros').textContent = button.getAttribute('data-nombre');
            });

            // Modal Editar Otros con AJAX
            const modalEditarOtros = document.getElementById('modalEditarOtros');
            if (modalEditarOtros) {
                modalEditarOtros.addEventListener('show.bs.modal', function(event) {
                    const button = event.relatedTarget;
                    
                    document.getElementById('edit_id_otros').value = button.getAttribute('data-id');
                    document.getElementById('edit_nombre_otros').value = button.getAttribute('data-nombre');
                    document.getElementById('edit_raza_otros').value = button.getAttribute('data-raza');
                    document.getElementById('edit_edad_otros').value = button.getAttribute('data-edad');
                    document.getElementById('edit_sexo_otros').value = button.getAttribute('data-sexo');
                    document.getElementById('edit_caracteristicas_otros').value = button.getAttribute('data-caracteristicas');
                    document.getElementById('edit_foto_actual_otros').value = button.getAttribute('data-foto');
                });

                // Manejar envío del formulario con AJAX
                const formEditarOtros = document.getElementById('formEditarOtros');
                formEditarOtros.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    const formData = new FormData(this);
                    const submitBtn = this.querySelector('.btn-modal-primary');
                    const originalText = submitBtn.innerHTML;
                    
                    // Mostrar loading
                    submitBtn.innerHTML = '⏳ Guardando...';
                    submitBtn.disabled = true;
                    
                    fetch('Otros.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Mostrar mensaje de éxito
                            mostrarAlerta('✅ ' + data.message, 'success');
                            
                            // Cerrar modal
                            const modal = bootstrap.Modal.getInstance(modalEditarOtros);
                            modal.hide();
                            
                            // Actualizar la tarjeta en la interfaz
                            actualizarTarjetaOtros(formData.get('id'), {
                                nombre: formData.get('nombre'),
                                raza: formData.get('raza'),
                                edad: formData.get('edad'),
                                sexo: formData.get('sexo'),
                                caracteristicas: formData.get('caracteristicas')
                            });
                            
                        } else {
                            mostrarAlerta('❌ ' + data.message, 'error');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        mostrarAlerta('❌ Error de conexión', 'error');
                    })
                    .finally(() => {
                        // Restaurar botón
                        submitBtn.innerHTML = originalText;
                        submitBtn.disabled = false;
                    });
                });
            }

            function actualizarTarjetaOtros(id, datos) {
                // Buscar la tarjeta correspondiente
                const tarjeta = document.querySelector(`.mascota[data-id="${id}"]`);
                if (tarjeta) {
                    // Actualizar datos en la tarjeta
                    tarjeta.setAttribute('data-nombre', datos.nombre);
                    tarjeta.setAttribute('data-raza', datos.raza);
                    tarjeta.setAttribute('data-edad', datos.edad);
                    tarjeta.setAttribute('data-sexo', datos.sexo);
                    tarjeta.setAttribute('data-caracteristicas', datos.caracteristicas);
                    
                    // Actualizar contenido visible
                    const contenido = tarjeta.querySelector('.mascota-content');
                    contenido.querySelector('h3').textContent = datos.nombre;
                    contenido.querySelector('p:nth-child(2)').textContent = 'Sexo: ' + datos.sexo;
                    contenido.querySelector('p:nth-child(3)').textContent = 'Edad: ' + datos.edad;
                    contenido.querySelector('p:nth-child(4)').textContent = 'Raza: ' + datos.raza;
                    
                    // Actualizar botón editar
                    const botonEditar = contenido.querySelector('.btn-editar');
                    botonEditar.setAttribute('data-nombre', datos.nombre);
                    botonEditar.setAttribute('data-raza', datos.raza);
                    botonEditar.setAttribute('data-edad', datos.edad);
                    botonEditar.setAttribute('data-sexo', datos.sexo);
                    botonEditar.setAttribute('data-caracteristicas', datos.caracteristicas);
                    
                    // Efecto visual de actualización
                    tarjeta.style.transform = 'scale(1.05)';
                    setTimeout(() => {
                        tarjeta.style.transform = 'scale(1)';
                    }, 300);
                }
            }

            function mostrarAlerta(mensaje, tipo) {
                // Eliminar alertas existentes
                const alertasExistentes = document.querySelectorAll('.alerta-temporal');
                alertasExistentes.forEach(alerta => alerta.remove());

                // Crear nueva alerta
                const alerta = document.createElement("div");
                alerta.className = `alerta-temporal ${tipo}`;
                alerta.textContent = mensaje;
                
                alerta.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    padding: 15px 20px;
                    border-radius: 5px;
                    color: white;
                    font-weight: bold;
                    z-index: 10000;
                    background-color: ${tipo === 'success' ? '#4CAF50' : '#f44336'};
                    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                `;
                
                document.body.appendChild(alerta);
                
                // Auto-eliminar después de 4 segundos
                setTimeout(() => {
                    if (alerta.parentElement) {
                        alerta.parentElement.removeChild(alerta);
                    }
                }, 4000);
            }
        });
    </script>

    <footer>
        <div class="footer-container">
            <p>&copy; 2025 Patitas Unidas. Todos los derechos reservados.</p>
        </div>
    </footer>
</body>
</html>