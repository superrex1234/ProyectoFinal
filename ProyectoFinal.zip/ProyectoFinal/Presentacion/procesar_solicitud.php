<?php
session_start();

if (!isset($_SESSION['ci'])) {
    header("Location: ../Formulario/FormularioLogin.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include_once "../Persistencia/perrosbd.php";
    
    $usuario_ci = $_SESSION['ci'];
    $mascota_id = $_POST['mascota_id'];
    $telefono = $_POST['telefono'];
    $razon = $_POST['razon'];
    
    $perrosBD = new perrosbd();
    
    // Verificar si ya existe una solicitud
    if ($perrosBD->VerificarSolicitudExistente($usuario_ci, $mascota_id)) {
        $_SESSION['error'] = "Ya has enviado una solicitud para esta mascota";
        header("Location: " . $_SERVER['HTTP_REFERER']);
        exit;
    }
    
    // Agregar la solicitud
    if ($perrosBD->AgregarSolicitud($usuario_ci, $mascota_id, $telefono, $razon)) {
        $_SESSION['success'] = "¡Solicitud enviada correctamente! Revisa el estado en 'Mis Solicitudes'";
    } else {
        $_SESSION['error'] = "Error al enviar la solicitud. Intenta nuevamente.";
    }
    
    header("Location: " . $_SERVER['HTTP_REFERER']);
    exit;
}

?>

<style>
    .solicitud-form {
    background: rgba(30, 30, 30, 0.7);
    padding: 1.5rem;
    border-radius: 10px;
    border: 1px solid #444;
}

.solicitud-form .form-control {
    background: rgba(50, 50, 50, 0.8);
    border: 1px solid #666;
    color: #eaeaea;
}

.solicitud-form .form-control:focus {
    background: rgba(60, 60, 60, 0.8);
    border-color: #c5a46d;
    color: #eaeaea;
}

.solicitud-form .form-label {
    color: #c5a46d;
    font-weight: 600;
}

.alert {
    border: none;
    border-radius: 10px;
}

.alert-info {
    background: rgba(13, 110, 253, 0.1);
    color: #0dcaf0;
}

.alert-warning {
    background: rgba(255, 193, 7, 0.1);
    color: #ffc107;
}
</style>
