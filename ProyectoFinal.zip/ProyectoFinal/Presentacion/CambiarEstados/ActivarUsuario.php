<?php
// Limpiar cualquier salida anterior
if (ob_get_length()) ob_clean();

session_start();
include_once __DIR__ . "/../../Logica/Usuarios.php";

header('Content-Type: application/json');

// Verificar que sea una petición POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        "exito" => false,
        "mensaje" => "Método no permitido"
    ]);
    exit;
}

// Verificar permisos de administrador
if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'admin') {
    echo json_encode([
        "exito" => false,
        "mensaje" => "Acceso no autorizado"
    ]);
    exit;
}

if (isset($_POST["id"])) {
    $usuarios = new Usuarios();
    $usuarios->setCi($_POST["id"]); // CORREGIDO: setCi en lugar de setCI
    $resultado = $usuarios->CambiarEstadoActivo(); // CORREGIDO: Sin parámetro

    if ($resultado["ok"]) {
        echo json_encode([
            "exito" => true,
            "mensaje" => "Usuario marcado como activo ✅",
            "nuevoEstado" => "activo"
        ]);
    } else {
        echo json_encode([
            "exito" => false,
            "mensaje" => "Error al activar usuario: " . $resultado["error"]
        ]);
    }
} else {
    echo json_encode([
        "exito" => false,
        "mensaje" => "Datos inválidos para activar usuario."
    ]);
}
exit;
?>