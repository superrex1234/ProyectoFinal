<?php
session_start();
require_once __DIR__ . "/../../Persistencia/perrosbd.php";

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['exito' => false, 'mensaje' => 'Método no permitido']);
    exit;
}

if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'admin') {
    echo json_encode(['exito' => false, 'mensaje' => 'No autorizado']);
    exit;
}

$solicitud_id = $_POST['solicitud_id'] ?? '';
$notas_contacto = $_POST['notas_contacto'] ?? '';
$mensaje_admin = $_POST['mensaje_admin'] ?? '';

if (empty($solicitud_id)) {
    echo json_encode(['exito' => false, 'mensaje' => 'ID de solicitud requerido']);
    exit;
}

try {
    $animalesBD = new perrosBD();
    
    // Obtener información de contacto primero
    $info_solicitud = $animalesBD->obtenerInfoContactoSolicitud($solicitud_id);
    
    if (!$info_solicitud) {
        echo json_encode(['exito' => false, 'mensaje' => 'Solicitud no encontrada']);
        exit;
    }
    
    // Marcar como contactado con mensaje del admin
    if ($animalesBD->marcarContactoRealizado($solicitud_id, $notas_contacto, $mensaje_admin)) {
        echo json_encode([
            'exito' => true, 
            'mensaje' => 'Contacto registrado correctamente',
            'info_contacto' => [
                'usuario' => $info_solicitud['usuario_nombre'],
                'email' => $info_solicitud['correo'],
                'telefono' => $info_solicitud['telefono_usuario'],
                'mascota' => $info_solicitud['mascota_nombre']
            ]
        ]);
    } else {
        echo json_encode(['exito' => false, 'mensaje' => 'Error al registrar el contacto']);
    }
} catch (Exception $e) {
    echo json_encode(['exito' => false, 'mensaje' => 'Error: ' . $e->getMessage()]);
}
?>