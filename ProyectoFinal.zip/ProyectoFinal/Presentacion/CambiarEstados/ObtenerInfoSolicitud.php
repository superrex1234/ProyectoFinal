<?php
session_start();
require_once __DIR__ . "/../../Persistencia/perrosbd.php";

header('Content-Type: application/json');

if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'admin') {
    echo json_encode(['exito' => false, 'mensaje' => 'No autorizado']);
    exit;
}

$solicitud_id = $_GET['solicitud_id'] ?? '';

if (empty($solicitud_id)) {
    echo json_encode(['exito' => false, 'mensaje' => 'ID de solicitud requerido']);
    exit;
}

try {
    $animalesBD = new perrosBD();
    $info_solicitud = $animalesBD->obtenerInfoContactoSolicitud($solicitud_id);
    
    if ($info_solicitud) {
        echo json_encode([
            'exito' => true,
            'info' => [
                'usuario' => $info_solicitud['usuario_nombre'],
                'email' => $info_solicitud['correo'],
                'telefono' => $info_solicitud['telefono_usuario'],
                'mascota' => $info_solicitud['mascota_nombre'],
                'especie' => $info_solicitud['especie']
            ]
        ]);
    } else {
        echo json_encode(['exito' => false, 'mensaje' => 'Solicitud no encontrada']);
    }
} catch (Exception $e) {
    echo json_encode(['exito' => false, 'mensaje' => 'Error: ' . $e->getMessage()]);
}
?>