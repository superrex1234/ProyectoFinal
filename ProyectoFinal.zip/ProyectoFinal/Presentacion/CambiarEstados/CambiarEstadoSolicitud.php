<?php
session_start();
require_once __DIR__ . "/../../Persistencia/perrosbd.php";

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['exito' => false, 'mensaje' => 'Método no permitido']);
    exit;
}

if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'admin') {
    echo json_encode(['exito' => false, 'mensaje' => 'No autorizado']);
    exit;
}

$solicitud_id = $_POST['solicitud_id'] ?? '';
$nuevo_estado = $_POST['nuevo_estado'] ?? '';

if (empty($solicitud_id) || empty($nuevo_estado)) {
    echo json_encode(['exito' => false, 'mensaje' => 'Datos incompletos']);
    exit;
}

try {
    $animalesBD = new perrosBD();
    
    if ($animalesBD->cambiarEstadoSolicitud($solicitud_id, $nuevo_estado)) {
        echo json_encode([
            'exito' => true, 
            'mensaje' => 'Estado actualizado correctamente',
            'nuevoEstado' => $nuevo_estado
        ]);
    } else {
        echo json_encode(['exito' => false, 'mensaje' => 'Error al actualizar el estado']);
    }
} catch (Exception $e) {
    echo json_encode(['exito' => false, 'mensaje' => 'Error: ' . $e->getMessage()]);
}
?>