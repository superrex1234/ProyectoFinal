<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'admin') {
    echo json_encode(['exito' => false, 'mensaje' => 'No autorizado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['id'])) {
    echo json_encode(['exito' => false, 'mensaje' => 'Solicitud inválida']);
    exit;
}

include_once __DIR__ . '/../../Persistencia/perrosbd.php';

$perrosBD = new perrosBD();
$id = intval($_POST['id']);

try {
    $resultado = $perrosBD->CambiarEstadoAdoptado($id, 'otro');
    
    if ($resultado) {
        echo json_encode([
            'exito' => true, 
            'mensaje' => 'Animal marcado como adoptado correctamente',
            'nuevoEstado' => 'adoptado'
        ]);
    } else {
        echo json_encode(['exito' => false, 'mensaje' => 'Error al marcar como adoptado']);
    }
} catch (Exception $e) {
    echo json_encode(['exito' => false, 'mensaje' => 'Error: ' . $e->getMessage()]);
}
?>