<?php
session_start();
require_once "../Persistencia/perrosbd.php";
require_once "../Logica/Perros.php";
require_once "../Presentacion/funcionImagen.php";

$perrosBD = new perrosbd();
$listaGatos = $perrosBD->MostrarGatosDisponibles();
$es_admin = isset($_SESSION['tipo']) && $_SESSION['tipo'] === 'admin';

// Procesar actualización vía AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar_gato'])) {
    if (!$es_admin) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'No tienes permisos para realizar esta acción']);
        exit;
    }
    
    $mascota = new Perros();
    $resultado = $mascota->ActualizarInfoGatos(
        $_POST['id'],
        $_POST['nombre'],
        $_POST['raza'],
        $_POST['edad'],
        $_POST['sexo'],
        $_POST['caracteristicas'],
        $_POST['foto_actual']
    );
    
    if ($resultado) {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => 'Gato actualizado correctamente']);
        exit;
    } else {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Error al actualizar el gato']);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Estilos/Gatos.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Adopta un Gato</title>
</head>
<body>
    <header>
        <div class="header-container">
            <a href="../index.php" class="logo">Patitas Unidas</a>
            <a href="../index.php" class="btn-volver">← Volver al Inicio</a>
        </div>
    </header>

    <main class="catalogo">
        <?php if ($listaGatos && count($listaGatos) > 0): ?>
            <?php foreach ($listaGatos as $gato): ?>
                <?php
                $mascotaCompleta = $perrosBD->ObtenerMascotaPorId($gato->getIdGatos());
                $caracteristicas = $mascotaCompleta['caracteristicas'] ?? 'Sin características definidas';
                $fotoSrc = $gato->getFotoGatos() ?: 'default.png';
                ?>
                
               <div class="mascota" 
     data-bs-toggle="modal" 
     data-bs-target="#modalInfoGato"
     data-id="<?= $gato->getIdGatos() ?>"
     data-nombre="<?= htmlspecialchars($gato->getNombreGatos()) ?>"
     data-raza="<?= htmlspecialchars($gato->getRazaGatos()) ?>"
     data-edad="<?= htmlspecialchars($gato->getEdadGatos()) ?>"
     data-sexo="<?= htmlspecialchars($gato->getSexoGatos()) ?>"
     data-caracteristicas="<?= htmlspecialchars($caracteristicas) ?>"
     data-foto="<?= htmlspecialchars($fotoSrc) ?>">
    
    <div class="mascota-image-container">
        <img src="../Fotoss/<?= $fotoSrc ?>" alt="Foto de <?= htmlspecialchars($gato->getNombreGatos()) ?>">
        <span class="click-message">🖱️ Click para Ver Información</span>
    </div>
    
    <div class="mascota-content">
        <h3><?= htmlspecialchars($gato->getNombreGatos()) ?></h3>
        <p>Sexo: <?= htmlspecialchars($gato->getSexoGatos()) ?></p>
        <p>Edad: <?= htmlspecialchars($gato->getEdadGatos()) ?></p>
        <p>Raza: <?= htmlspecialchars($gato->getRazaGatos()) ?></p>
        
        <?php if ($es_admin): ?>
            <div class="botones-container">
                <button class="btn-editar" 
                        onclick="event.stopPropagation()" 
                        data-bs-toggle="modal" 
                        data-bs-target="#modalEditarGato"
                        data-id="<?= $gato->getIdGatos() ?>"
                        data-nombre="<?= htmlspecialchars($gato->getNombreGatos()) ?>"
                        data-raza="<?= htmlspecialchars($gato->getRazaGatos()) ?>"
                        data-edad="<?= htmlspecialchars($gato->getEdadGatos()) ?>"
                        data-sexo="<?= htmlspecialchars($gato->getSexoGatos()) ?>"
                        data-caracteristicas="<?= htmlspecialchars($caracteristicas) ?>"
                        data-foto="<?= htmlspecialchars($fotoSrc) ?>">
                    Editar
                </button>
            </div>
        <?php endif; ?>
    </div>
</div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="no-mascotas">No hay gatos disponibles por el momento 🐱.</p>
        <?php endif; ?>
    </main>

    <!-- Modal Información Gato -->
    <div class="modal fade" id="modalInfoGato" tabindex="-1" aria-labelledby="modalInfoGatoLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Información del Gato</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                
                <div class="modal-body">
                    <div class="modal-grid">
                        <div class="modal-image">
                            <img id="info_foto_gato" src="" alt="Foto del gato">
                        </div>
                        
                        <div class="modal-info">
                            <h2 id="info_nombre_gato"></h2>
                            
                            <div class="info-grid">
                                <div class="info-item">
                                    <span class="info-label">Raza:</span>
                                    <span id="info_raza_gato" class="info-value"></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Edad:</span>
                                    <span id="info_edad_gato" class="info-value"></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Sexo:</span>
                                    <span id="info_sexo_gato" class="info-value"></span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="modal-description">
                            <h3 class="section-title">Descripción</h3>
                            <div id="info_caracteristicas_gato" class="description-content"></div>
                        </div>
                        
                        <div class="modal-solicitud">
                            <h3 class="section-title">Solicitar Adopción</h3>
                            <?php if (isset($_SESSION['ci'])): ?>
                                <?php $solicitud_existente = $perrosBD->VerificarSolicitudExistente($_SESSION['ci'], $gato->getIdGatos()); ?>
                                
                                <?php if (!$solicitud_existente): ?>
                                    <form method="POST" action="../Presentacion/procesar_solicitud.php" class="solicitud-form">
                                        <input type="hidden" name="mascota_id" id="solicitud_mascota_id_gato">
                                        <input type="hidden" name="especie" value="gato">
                                        
                                        <div class="form-group">
                                            <label for="telefono_solicitud_gato">Teléfono de Contacto *</label>
                                            <input type="tel" id="telefono_solicitud_gato" name="telefono" required placeholder="Ej: 0981234567">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="razon_solicitud_gato">¿Por qué quieres adoptar a <span id="nombre_mascota_solicitud_gato"></span>? *</label>
                                            <textarea id="razon_solicitud_gato" name="razon" rows="4" required 
                                                      placeholder="Cuéntanos sobre tu experiencia con mascotas, tu hogar, y por qué serías un buen dueño..."></textarea>
                                        </div>
                                        
                                        <button type="submit" class="btn-solicitud">
                                            🐾 Enviar Solicitud de Adopción
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <div class="alert-info">
                                        <strong>✅ Ya has enviado una solicitud para esta mascota</strong>
                                        <p>Revisa el estado en <a href="../mis_solicitudes.php">Mis Solicitudes</a></p>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="alert-warning">
                                    <strong>⚠️ Debes iniciar sesión para enviar una solicitud</strong>
                                    <div class="auth-buttons">
                                        <a href="../Formulario/FormularioLogin.php" class="btn-login">Iniciar Sesión</a>
                                        <a href="../Formulario/FormularioRegistro.php" class="btn-register">Registrarse</a>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Editar Gato -->
    <?php if ($es_admin): ?>
    <div class="modal fade" id="modalEditarGato" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content modal-animal-content">
                <div class="modal-animal-header">
                    <div class="modal-animal-title">
                        <i class="modal-icon">✏️</i>
                        <h3>Editar Gato</h3>
                    </div>
                    <button type="button" class="modal-animal-close" data-bs-dismiss="modal">&times;</button>
                </div>
                
                <form id="formEditarGato" class="modal-animal-form">
                    <input type="hidden" name="id" id="edit_id_gato">
                    <input type="hidden" name="actualizar_gato" value="1">
                    <input type="hidden" name="foto_actual" id="edit_foto_actual_gato">
                    
                    <div class="modal-animal-body">
                        <div class="form-grid-modal">
                            <div class="form-group-modal">
                                <label for="edit_nombre_gato" class="form-label-modal">
                                    Nombre del Gato *
                                </label>
                                <input type="text" id="edit_nombre_gato" name="nombre" class="form-input-modal" required>
                            </div>
                            
                            <div class="form-group-modal">
                                <label for="edit_raza_gato" class="form-label-modal">
                                    Raza del Gato *
                                </label>
                                <input type="text" id="edit_raza_gato" name="raza" class="form-input-modal" required>
                            </div>
                            
                            <div class="form-group-modal">
                                <label for="edit_edad_gato" class="form-label-modal">
                                    Edad del Gato *
                                </label>
                                <input type="text" id="edit_edad_gato" name="edad" class="form-input-modal" required>
                            </div>
                            
                            <div class="form-group-modal">
                                <label for="edit_sexo_gato" class="form-label-modal">
                                    Sexo del Gato *
                                </label>
                                <select id="edit_sexo_gato" name="sexo" class="form-select-modal" required>
                                    <option value="">Seleccionar sexo</option>
                                    <option value="Macho">Macho</option>
                                    <option value="Hembra">Hembra</option>
                                </select>
                            </div>
                            
                            <div class="form-group-modal full-width">
                                <label for="edit_caracteristicas_gato" class="form-label-modal">
                                    Descripción del Gato
                                </label>
                                <textarea id="edit_caracteristicas_gato" name="caracteristicas" class="form-input-modal" rows="4" 
                                          placeholder="Describe las características del gato..."></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-animal-footer">
                        <button type="button" class="btn-modal btn-modal-secondary" data-bs-dismiss="modal">
                            <i class="btn-icon">❌</i>
                            Cancelar
                        </button>
                        <button type="submit" class="btn-modal btn-modal-primary">
                            <i class="btn-icon">💾</i>
                            <span class="btn-text">Guardar Cambios</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Modal Información
            const modalInfo = document.getElementById('modalInfoGato');
            modalInfo.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                const fotoSrc = '../Fotoss/' + (button.getAttribute('data-foto') || 'default.png');
                
                document.getElementById('info_nombre_gato').textContent = button.getAttribute('data-nombre');
                document.getElementById('info_raza_gato').textContent = button.getAttribute('data-raza');
                document.getElementById('info_edad_gato').textContent = button.getAttribute('data-edad');
                document.getElementById('info_sexo_gato').textContent = button.getAttribute('data-sexo');
                document.getElementById('info_caracteristicas_gato').textContent = button.getAttribute('data-caracteristicas');
                document.getElementById('info_foto_gato').src = fotoSrc;
                
                // Datos formulario solicitud
                document.getElementById('solicitud_mascota_id_gato').value = button.getAttribute('data-id');
                document.getElementById('nombre_mascota_solicitud_gato').textContent = button.getAttribute('data-nombre');
            });

            // Modal Editar Gato con AJAX
            const modalEditarGato = document.getElementById('modalEditarGato');
            if (modalEditarGato) {
                modalEditarGato.addEventListener('show.bs.modal', function(event) {
                    const button = event.relatedTarget;
                    
                    document.getElementById('edit_id_gato').value = button.getAttribute('data-id');
                    document.getElementById('edit_nombre_gato').value = button.getAttribute('data-nombre');
                    document.getElementById('edit_raza_gato').value = button.getAttribute('data-raza');
                    document.getElementById('edit_edad_gato').value = button.getAttribute('data-edad');
                    document.getElementById('edit_sexo_gato').value = button.getAttribute('data-sexo');
                    document.getElementById('edit_caracteristicas_gato').value = button.getAttribute('data-caracteristicas');
                    document.getElementById('edit_foto_actual_gato').value = button.getAttribute('data-foto');
                });

                // Manejar envío del formulario con AJAX
                const formEditarGato = document.getElementById('formEditarGato');
                formEditarGato.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    const formData = new FormData(this);
                    const submitBtn = this.querySelector('.btn-modal-primary');
                    const originalText = submitBtn.innerHTML;
                    
                    // Mostrar loading
                    submitBtn.innerHTML = '⏳ Guardando...';
                    submitBtn.disabled = true;
                    
                    fetch('gatos.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Mostrar mensaje de éxito
                            mostrarAlerta('✅ ' + data.message, 'success');
                            
                            // Cerrar modal
                            const modal = bootstrap.Modal.getInstance(modalEditarGato);
                            modal.hide();
                            
                            // Actualizar la tarjeta en la interfaz
                            actualizarTarjetaGato(formData.get('id'), {
                                nombre: formData.get('nombre'),
                                raza: formData.get('raza'),
                                edad: formData.get('edad'),
                                sexo: formData.get('sexo'),
                                caracteristicas: formData.get('caracteristicas')
                            });
                            
                        } else {
                            mostrarAlerta('❌ ' + data.message, 'error');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        mostrarAlerta('❌ Error de conexión', 'error');
                    })
                    .finally(() => {
                        // Restaurar botón
                        submitBtn.innerHTML = originalText;
                        submitBtn.disabled = false;
                    });
                });
            }

            function actualizarTarjetaGato(id, datos) {
                // Buscar la tarjeta correspondiente
                const tarjeta = document.querySelector(`.mascota[data-id="${id}"]`);
                if (tarjeta) {
                    // Actualizar datos en la tarjeta
                    tarjeta.setAttribute('data-nombre', datos.nombre);
                    tarjeta.setAttribute('data-raza', datos.raza);
                    tarjeta.setAttribute('data-edad', datos.edad);
                    tarjeta.setAttribute('data-sexo', datos.sexo);
                    tarjeta.setAttribute('data-caracteristicas', datos.caracteristicas);
                    
                    // Actualizar contenido visible
                    const contenido = tarjeta.querySelector('.mascota-content');
                    contenido.querySelector('h3').textContent = datos.nombre;
                    contenido.querySelector('p:nth-child(2)').textContent = 'Sexo: ' + datos.sexo;
                    contenido.querySelector('p:nth-child(3)').textContent = 'Edad: ' + datos.edad;
                    contenido.querySelector('p:nth-child(4)').textContent = 'Raza: ' + datos.raza;
                    
                    // Actualizar botón editar
                    const botonEditar = contenido.querySelector('.btn-editar');
                    botonEditar.setAttribute('data-nombre', datos.nombre);
                    botonEditar.setAttribute('data-raza', datos.raza);
                    botonEditar.setAttribute('data-edad', datos.edad);
                    botonEditar.setAttribute('data-sexo', datos.sexo);
                    botonEditar.setAttribute('data-caracteristicas', datos.caracteristicas);
                    
                    // Efecto visual de actualización
                    tarjeta.style.transform = 'scale(1.05)';
                    setTimeout(() => {
                        tarjeta.style.transform = 'scale(1)';
                    }, 300);
                }
            }

            function mostrarAlerta(mensaje, tipo) {
                // Eliminar alertas existentes
                const alertasExistentes = document.querySelectorAll('.alerta-temporal');
                alertasExistentes.forEach(alerta => alerta.remove());

                // Crear nueva alerta
                const alerta = document.createElement("div");
                alerta.className = `alerta-temporal ${tipo}`;
                alerta.textContent = mensaje;
                
                alerta.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    padding: 15px 20px;
                    border-radius: 5px;
                    color: white;
                    font-weight: bold;
                    z-index: 10000;
                    background-color: ${tipo === 'success' ? '#4CAF50' : '#f44336'};
                    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                `;
                
                document.body.appendChild(alerta);
                
                // Auto-eliminar después de 4 segundos
                setTimeout(() => {
                    if (alerta.parentElement) {
                        alerta.parentElement.removeChild(alerta);
                    }
                }, 4000);
            }
        });
    </script>

    <footer>
        <div class="footer-container">
            <p>&copy; 2025 Patitas Unidas. Todos los derechos reservados.</p>
        </div>
    </footer>
</body>
</html>