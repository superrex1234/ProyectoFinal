<?php
include_once "../Logica/Usuarios.php";
session_start();

if (isset($_POST['enviar'])) {
    $usuario = new Usuarios();
    $usuario->setCI($_POST['ci']);
    $usuario->setPassword($_POST['password']);
    $u = $usuario->Login();

    if ($u != null) {

        // Verificar si está activo
        if ($u->getEstado() !== 'activo') {
            $_SESSION['alerta'] = [
                "tipo" => "error",
                "mensaje" => "Usuario inactivo. No puede iniciar sesión."
            ];
            header("Location: ../index.php");
            exit;
        }

        // Usuario activo, iniciar sesión
        $_SESSION['ci'] = $u->getCI();  
        $_SESSION['nombrecompleto'] = $u->getNombreCompleto();   
        $_SESSION['foto'] = $u->getFoto();

        if ($u->getTipo() == "usuario") {
            header("Location: ../index.php");
            exit;
        } else if ($u->getTipo() == "admin") {
            header("Location: ../index.php");
            exit;
        }

    } else {
        $_SESSION['alerta'] = [
            "tipo" => "error", 
            "mensaje" => "Error. Documento de identidad o contraseña incorrecto"
        ];
        header("Location: ../index.php"); 
        exit;
    }
}
?>
