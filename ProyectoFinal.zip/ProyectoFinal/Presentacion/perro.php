<?php
session_start();
require_once "../Persistencia/perrosbd.php";
require_once "../Logica/Perros.php";
require_once "../Presentacion/funcionImagen.php";

$perrosBD = new perrosbd();
$listaPerros = $perrosBD->MostrarPerrosDisponibles();
$es_admin = isset($_SESSION['tipo']) && $_SESSION['tipo'] === 'admin';

// Procesar actualización vía AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar_perro'])) {
    if (!$es_admin) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'No tienes permisos para realizar esta acción']);
        exit;
    }
    
    $mascota = new Perros();
    $resultado = $mascota->ActualizarInfoPerros(
        $_POST['id'],
        $_POST['nombre'],
        $_POST['raza'],
        $_POST['edad'],
        $_POST['sexo'],
        $_POST['caracteristicas'],
        $_POST['foto_actual']
    );
    
    if ($resultado) {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => 'Perro actualizado correctamente']);
        exit;
    } else {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Error al actualizar el perro']);
        exit;
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Estilos/Perros.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="../JavaScript/menu.js" defer></script>
    <title>Adopta un Perro</title>
</head>
<body>
    <header>
        <div class="header-container">
            <a href="../index.php" class="logo">Patitas Unidas</a>
            <a href="../index.php" class="btn-volver">← Volver al Inicio</a>
        </div>
    </header>

    <main class="catalogo">
        <?php if ($listaPerros && count($listaPerros) > 0): ?>
            <?php foreach ($listaPerros as $perro): ?>
                <?php
                $mascotaCompleta = $perrosBD->ObtenerMascotaPorId($perro->getIdPerro());
                $caracteristicas = $mascotaCompleta['caracteristicas'] ?? 'Sin características definidas';
                $fotoSrc = $perro->getFotoPerro() ?: 'default.png';
                ?>
                
               <div class="mascota" 
     data-bs-toggle="modal" 
     data-bs-target="#modalInfoPerro"
     data-id="<?= $perro->getIdPerro() ?>"
     data-nombre="<?= htmlspecialchars($perro->getNombrePerro()) ?>"
     data-raza="<?= htmlspecialchars($perro->getRazaPerro()) ?>"
     data-edad="<?= htmlspecialchars($perro->getEdadPerro()) ?>"
     data-sexo="<?= htmlspecialchars($perro->getSexoPerro()) ?>"
     data-caracteristicas="<?= htmlspecialchars($caracteristicas) ?>"
     data-foto="<?= htmlspecialchars($fotoSrc) ?>">
    
    <div class="mascota-image-container">
        <img src="../Fotoss/<?= $fotoSrc ?>" alt="Foto de <?= htmlspecialchars($perro->getNombrePerro()) ?>">
        <span class="click-message">🖱️ Click para Ver Información</span>
    </div>
    
    <div class="mascota-content">
        <h3><?= htmlspecialchars($perro->getNombrePerro()) ?></h3>
        <p>Sexo: <?= htmlspecialchars($perro->getSexoPerro()) ?></p>
        <p>Edad: <?= htmlspecialchars($perro->getEdadPerro()) ?></p>
        <p>Raza: <?= htmlspecialchars($perro->getRazaPerro()) ?></p>
        
        <?php if ($es_admin): ?>
            <div class="botones-container">
                <button class="btn-editar" 
                        onclick="event.stopPropagation()" 
                        data-bs-toggle="modal" 
                        data-bs-target="#modalEditarPerro"
                        data-id="<?= $perro->getIdPerro() ?>"
                        data-nombre="<?= htmlspecialchars($perro->getNombrePerro()) ?>"
                        data-raza="<?= htmlspecialchars($perro->getRazaPerro()) ?>"
                        data-edad="<?= htmlspecialchars($perro->getEdadPerro()) ?>"
                        data-sexo="<?= htmlspecialchars($perro->getSexoPerro()) ?>"
                        data-caracteristicas="<?= htmlspecialchars($caracteristicas) ?>"
                        data-foto="<?= htmlspecialchars($fotoSrc) ?>">
                    Editar
                </button>
            </div>
        <?php endif; ?>
    </div>
</div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="no-mascotas">No hay perros disponibles por el momento 🐶.</p>
        <?php endif; ?>
    </main>

    <!-- Modal Información -->
    <div class="modal fade" id="modalInfoPerro" tabindex="-1" aria-labelledby="modalInfoPerroLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Información del Perro</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                
                <div class="modal-body">
                    <div class="modal-grid">
                        <div class="modal-image">
                            <img id="info_foto" src="" alt="Foto del perro">
                        </div>
                        
                        <div class="modal-info">
                            <h2 id="info_nombre"></h2>
                            
                            <div class="info-grid">
                                <div class="info-item">
                                    <span class="info-label">Raza:</span>
                                    <span id="info_raza" class="info-value"></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Edad:</span>
                                    <span id="info_edad" class="info-value"></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Sexo:</span>
                                    <span id="info_sexo" class="info-value"></span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="modal-description">
                            <h3 class="section-title">Descripción</h3>
                            <div id="info_caracteristicas" class="description-content"></div>
                        </div>
                        
                        <div class="modal-solicitud">
                            <h3 class="section-title">Solicitar Adopción</h3>
                            <?php if (isset($_SESSION['ci'])): ?>
                                <?php $solicitud_existente = $perrosBD->VerificarSolicitudExistente($_SESSION['ci'], $perro->getIdPerro()); ?>
                                
                                <?php if (!$solicitud_existente): ?>
                                    <form method="POST" action="../Presentacion/procesar_solicitud.php" class="solicitud-form">
                                        <input type="hidden" name="mascota_id" id="solicitud_mascota_id">
                                        <input type="hidden" name="especie" value="perro">
                                        
                                        <div class="form-group">
                                            <label for="telefono_solicitud">Teléfono de Contacto *</label>
                                            <input type="tel" id="telefono_solicitud" name="telefono" required placeholder="Ej: 0981234567"   maxlength="8" minlength="8">>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="razon_solicitud">¿Por qué quieres adoptar a <span id="nombre_mascota_solicitud"></span>? *</label>
                                            <textarea id="razon_solicitud" name="razon" rows="4" required 
                                                      placeholder="Cuéntanos sobre tu experiencia con mascotas, tu hogar, y por qué serías un buen dueño..."></textarea>
                                        </div>
                                        
                                        <button type="submit" class="btn-solicitud">
                                            🐾 Enviar Solicitud de Adopción
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <div class="alert-info">
                                        <strong>✅ Ya has enviado una solicitud para esta mascota</strong>
                                        <p>Revisa el estado en <a href="../mis_solicitudes.php">Mis Solicitudes</a></p>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="alert-warning">
                                    <strong>⚠️ Debes iniciar sesión para enviar una solicitud</strong>
                                    <div class="auth-buttons">
                                        <a href="../Formulario/FormularioLogin.php" class="btn-login">Iniciar Sesión</a>
                                        <a href="../Formulario/FormularioRegistro.php" class="btn-register">Registrarse</a>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

 <!-- Modal Editar Perro -->
<div class="modal fade" id="modalEditarPerro" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content modal-animal-content">
            <div class="modal-animal-header">
                <div class="modal-animal-title">
                    <i class="modal-icon">✏️</i>
                    <h3>Editar Perro</h3>
                </div>
                <button type="button" class="modal-animal-close" data-bs-dismiss="modal">&times;</button>
            </div>
            
            <form id="formEditarPerro" class="modal-animal-form">
                <input type="hidden" name="id" id="edit_id_perro">
                <input type="hidden" name="actualizar_perro" value="1">
                <input type="hidden" name="foto_actual" id="edit_foto_actual_perro">
                
                <div class="modal-animal-body">
                    <div class="form-grid-modal">
                        <div class="form-group-modal">
                            <label for="edit_nombre_perro" class="form-label-modal">
                                Nombre del Perro *
                            </label>
                            <input type="text" id="edit_nombre_perro" name="nombre" class="form-input-modal" required>
                        </div>
                        
                        <div class="form-group-modal">
                            <label for="edit_raza_perro" class="form-label-modal">
                                Raza del Perro *
                            </label>
                            <input type="text" id="edit_raza_perro" name="raza" class="form-input-modal" required>
                        </div>
                        
                        <div class="form-group-modal">
                            <label for="edit_edad_perro" class="form-label-modal">
                                Edad del Perro *
                            </label>
                            <input type="text" id="edit_edad_perro" name="edad" class="form-input-modal" required>
                        </div>
                        
                        <div class="form-group-modal">
                            <label for="edit_sexo_perro" class="form-label-modal">
                                Sexo del Perro *
                            </label>
                            <select id="edit_sexo_perro" name="sexo" class="form-select-modal" required>
                                <option value="">Seleccionar sexo</option>
                                <option value="Macho">Macho</option>
                                <option value="Hembra">Hembra</option>
                            </select>
                        </div>
                        
                        <div class="form-group-modal full-width">
                            <label for="edit_caracteristicas_perro" class="form-label-modal">
                                Descripción del Perro
                            </label>
                            <textarea id="edit_caracteristicas_perro" name="caracteristicas" class="form-input-modal" rows="4" 
                                      placeholder="Describe las características del perro..."></textarea>
                        </div>
                    </div>
                </div>
                
                <div class="modal-animal-footer">
                    <button type="button" class="btn-modal btn-modal-secondary" data-bs-dismiss="modal">
                        <i class="btn-icon">❌</i>
                        Cancelar
                    </button>
                    <button type="submit" class="btn-modal btn-modal-primary">
                        <i class="btn-icon">💾</i>
                        <span class="btn-text">Guardar Cambios</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Modal Información
        const modalInfo = document.getElementById('modalInfoPerro');
        modalInfo.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            const fotoSrc = '../Fotoss/' + (button.getAttribute('data-foto') || 'default.png');
            
            document.getElementById('info_nombre').textContent = button.getAttribute('data-nombre');
            document.getElementById('info_raza').textContent = button.getAttribute('data-raza');
            document.getElementById('info_edad').textContent = button.getAttribute('data-edad');
            document.getElementById('info_sexo').textContent = button.getAttribute('data-sexo');
            document.getElementById('info_caracteristicas').textContent = button.getAttribute('data-caracteristicas');
            document.getElementById('info_foto').src = fotoSrc;
            
            // Datos formulario solicitud
            document.getElementById('solicitud_mascota_id').value = button.getAttribute('data-id');
            document.getElementById('nombre_mascota_solicitud').textContent = button.getAttribute('data-nombre');
        });

        // Modal Editar Perro con AJAX
        const modalEditarPerro = document.getElementById('modalEditarPerro');
        if (modalEditarPerro) {
            modalEditarPerro.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                
                document.getElementById('edit_id_perro').value = button.getAttribute('data-id');
                document.getElementById('edit_nombre_perro').value = button.getAttribute('data-nombre');
                document.getElementById('edit_raza_perro').value = button.getAttribute('data-raza');
                document.getElementById('edit_edad_perro').value = button.getAttribute('data-edad');
                document.getElementById('edit_sexo_perro').value = button.getAttribute('data-sexo');
                document.getElementById('edit_caracteristicas_perro').value = button.getAttribute('data-caracteristicas');
                document.getElementById('edit_foto_actual_perro').value = button.getAttribute('data-foto');
            });

            // Manejar envío del formulario con AJAX
            const formEditarPerro = document.getElementById('formEditarPerro');
            formEditarPerro.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const formData = new FormData(this);
                const submitBtn = this.querySelector('.btn-modal-primary');
                const originalText = submitBtn.innerHTML;
                
                // Mostrar loading
                submitBtn.innerHTML = '⏳ Guardando...';
                submitBtn.disabled = true;
                
                fetch('perro.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Mostrar mensaje de éxito
                        mostrarAlerta('✅ ' + data.message, 'success');
                        
                        // Cerrar modal
                        const modal = bootstrap.Modal.getInstance(modalEditarPerro);
                        modal.hide();
                        
                        // Actualizar la tarjeta en la interfaz
                        actualizarTarjetaPerro(formData.get('id'), {
                            nombre: formData.get('nombre'),
                            raza: formData.get('raza'),
                            edad: formData.get('edad'),
                            sexo: formData.get('sexo'),
                            caracteristicas: formData.get('caracteristicas')
                        });
                        
                    } else {
                        mostrarAlerta('❌ ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    mostrarAlerta('❌ Error de conexión', 'error');
                })
                .finally(() => {
                    // Restaurar botón
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                });
            });
        }

        function actualizarTarjetaPerro(id, datos) {
            // Buscar la tarjeta correspondiente
            const tarjeta = document.querySelector(`.mascota[data-id="${id}"]`);
            if (tarjeta) {
                // Actualizar datos en la tarjeta
                tarjeta.setAttribute('data-nombre', datos.nombre);
                tarjeta.setAttribute('data-raza', datos.raza);
                tarjeta.setAttribute('data-edad', datos.edad);
                tarjeta.setAttribute('data-sexo', datos.sexo);
                tarjeta.setAttribute('data-caracteristicas', datos.caracteristicas);
                
                // Actualizar contenido visible
                const contenido = tarjeta.querySelector('.mascota-content');
                contenido.querySelector('h3').textContent = datos.nombre;
                contenido.querySelector('p:nth-child(2)').textContent = 'Sexo: ' + datos.sexo;
                contenido.querySelector('p:nth-child(3)').textContent = 'Edad: ' + datos.edad;
                contenido.querySelector('p:nth-child(4)').textContent = 'Raza: ' + datos.raza;
                
                // Actualizar botón editar
                const botonEditar = contenido.querySelector('.btn-editar');
                botonEditar.setAttribute('data-nombre', datos.nombre);
                botonEditar.setAttribute('data-raza', datos.raza);
                botonEditar.setAttribute('data-edad', datos.edad);
                botonEditar.setAttribute('data-sexo', datos.sexo);
                botonEditar.setAttribute('data-caracteristicas', datos.caracteristicas);
                
                // Efecto visual de actualización
                tarjeta.style.transform = 'scale(1.05)';
                setTimeout(() => {
                    tarjeta.style.transform = 'scale(1)';
                }, 300);
            }
        }

        function mostrarAlerta(mensaje, tipo) {
            // Eliminar alertas existentes
            const alertasExistentes = document.querySelectorAll('.alerta-temporal');
            alertasExistentes.forEach(alerta => alerta.remove());

            // Crear nueva alerta
            const alerta = document.createElement("div");
            alerta.className = `alerta-temporal ${tipo}`;
            alerta.textContent = mensaje;
            
            alerta.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 20px;
                border-radius: 5px;
                color: white;
                font-weight: bold;
                z-index: 10000;
                background-color: ${tipo === 'success' ? '#4CAF50' : '#f44336'};
                box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            `;
            
            document.body.appendChild(alerta);
            
            // Auto-eliminar después de 4 segundos
            setTimeout(() => {
                if (alerta.parentElement) {
                    alerta.parentElement.removeChild(alerta);
                }
            }, 4000);
        }
    });
</script>

    <footer>
        <div class="footer-container">
            <p>&copy; 2025 Patitas Unidas. Todos los derechos reservados.</p>
        </div>
    </footer>
</body>
</html>